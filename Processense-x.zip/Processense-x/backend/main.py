# ╔══════════════════════════════════════════════════════════════════╗
# ║   ProcessSense-X — FastAPI Backend                              ║
# ║   Accepts ESP32 sensor data, runs AI analysis, broadcasts       ║
# ║   via WebSocket to all connected dashboards                     ║
# ╚══════════════════════════════════════════════════════════════════╝
from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import Optional
import asyncio, json, math, time, random
from collections import deque

app = FastAPI(title="ProcessSense-X API", version="1.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

# ── Data Store ─────────────────────────────────────────────────────
MAX_HISTORY = 360
history: deque = deque(maxlen=MAX_HISTORY)
connected_clients: list[WebSocket] = []

# ── Normal fingerprint (defaults) ─────────────────────────────────
FINGERPRINT = {
    "temperature": {"mean": 72.5, "std": 1.2, "min": 70.0, "max": 75.0},
    "pressure":    {"mean": 101.5, "std": 0.8, "min": 100.0, "max": 103.0},
    "current":     {"mean": 1.75,  "std": 0.15, "min": 1.5, "max": 2.0},
}

# ── Models ─────────────────────────────────────────────────────────
class SensorPacket(BaseModel):
    device_id: Optional[str] = "ESP32-PSX-001"
    timestamp: Optional[int] = None
    temperature: float
    pressure: float
    current: float


class AIResult(BaseModel):
    status: str
    anomaly_score: float
    drift_score: float
    severity: int
    yield_risk: float
    confidence: int
    interpretation: str


# ── AI Analysis (Python port of the TypeScript engine) ─────────────
WEIGHTS = {"temperature": 0.45, "pressure": 0.30, "current": 0.25}

def _mean(values): return sum(values) / len(values) if values else 0
def _std(values):
    if len(values) < 2: return 0
    m = _mean(values)
    return math.sqrt(sum((v - m)**2 for v in values) / (len(values) - 1))

def ai_analyze(temp_h, press_h, curr_h):
    def sigma_dev(history, fp_key):
        if not history: return 0
        m = _mean(list(history)[-30:])
        return (m - FINGERPRINT[fp_key]["mean"]) / (FINGERPRINT[fp_key]["std"] or 0.01)

    def rate_of_change(history):
        recent = list(history)[-5:]
        if len(recent) < 2: return 0
        return (recent[-1] - recent[0]) / (len(recent) - 1)

    t_sig = abs(sigma_dev(temp_h,  "temperature"))
    p_sig = abs(sigma_dev(press_h, "pressure"))
    c_sig = abs(sigma_dev(curr_h,  "current"))

    raw_anomaly = WEIGHTS["temperature"] * t_sig + WEIGHTS["pressure"] * p_sig + WEIGHTS["current"] * c_sig
    anomaly_score = min(1.0, raw_anomaly / 4)

    t_drift = abs(rate_of_change(temp_h))  / (FINGERPRINT["temperature"]["std"] or 0.01)
    p_drift = abs(rate_of_change(press_h)) / (FINGERPRINT["pressure"]["std"]    or 0.01)
    c_drift = abs(rate_of_change(curr_h))  / (FINGERPRINT["current"]["std"]     or 0.01)
    drift_score = min(1.0, (WEIGHTS["temperature"]*t_drift + WEIGHTS["pressure"]*p_drift + WEIGHTS["current"]*c_drift) / 3)

    severity = round(min(100, (anomaly_score * 65 + drift_score * 35) * 100))

    if severity < 30:   yield_risk = severity * 0.15
    elif severity < 70: yield_risk = 4.5 + (severity - 30) * 0.45
    else:               yield_risk = 22.5 + (severity - 70) * 0.85

    confidence = round(min(98, max(60, 60 + len(temp_h) * 0.4)))

    if severity >= 71:   status = "CRITICAL"
    elif severity >= 31: status = "WARNING"
    else:                status = "NORMAL"

    total = t_sig + p_sig + c_sig or 1
    return {
        "status":        status,
        "anomaly_score": round(anomaly_score, 3),
        "drift_score":   round(drift_score,   3),
        "severity":      severity,
        "yield_risk":    round(yield_risk, 1),
        "confidence":    confidence,
    }


# ── WebSocket broadcast ────────────────────────────────────────────
async def broadcast(data: dict):
    msg = json.dumps(data)
    dead = []
    for ws in connected_clients:
        try:
            await ws.send_text(msg)
        except Exception:
            dead.append(ws)
    for ws in dead:
        connected_clients.remove(ws)


# ── REST Endpoints ─────────────────────────────────────────────────
@app.post("/api/sensor-data")
async def receive_sensor_data(packet: SensorPacket):
    """Accept sensor data from ESP32, run AI analysis, broadcast to dashboards."""
    reading = {
        "timestamp":   packet.timestamp or int(time.time() * 1000),
        "temperature": packet.temperature,
        "pressure":    packet.pressure,
        "current":     packet.current,
    }
    history.append(reading)

    temp_h  = [r["temperature"] for r in history]
    press_h = [r["pressure"]    for r in history]
    curr_h  = [r["current"]     for r in history]

    result = ai_analyze(temp_h, press_h, curr_h)
    result["reading"] = reading

    await broadcast(result)
    return result


@app.get("/api/history")
def get_history():
    return list(history)


@app.get("/api/status")
def get_status():
    return {
        "device_id":   "ESP32-PSX-001",
        "readings":     len(history),
        "clients":      len(connected_clients),
        "fingerprint":  FINGERPRINT,
    }


@app.get("/api/simulate")
async def simulate_reading(scenario: str = "normal"):
    """Generate a single simulated reading and ingest it."""
    t_base, p_base, c_base = 72.5, 101.5, 1.75

    def noise(amp): return (random.random() - 0.5) * 2 * amp

    if scenario == "thermal-drift":
        temp = t_base + len(history) * 0.12 + noise(0.3)
        press, current = p_base + noise(0.15), c_base + noise(0.04)
    elif scenario == "pressure-instability":
        temp = t_base + noise(0.25)
        press = p_base + math.sin(len(history) * 0.4) * 1.5 + noise(0.2)
        current = c_base + noise(0.04)
    elif scenario == "electrical-load":
        temp = t_base + noise(0.25)
        press = p_base + noise(0.15)
        current = c_base + len(history) * 0.06 + noise(0.08)
    elif scenario == "combined-drift":
        temp = t_base + len(history) * 0.14 + noise(0.4)
        press = p_base + math.sin(len(history) * 0.5) * 2.0 + noise(0.3)
        current = c_base + len(history) * 0.065 + noise(0.10)
    else:  # normal
        temp = t_base + noise(0.25)
        press = p_base + noise(0.15)
        current = c_base + noise(0.04)

    packet = SensorPacket(temperature=round(temp, 1), pressure=round(press, 2), current=round(current, 2))
    return await receive_sensor_data(packet)


# ── WebSocket for dashboard ────────────────────────────────────────
@app.websocket("/ws")
async def websocket_endpoint(ws: WebSocket):
    await ws.accept()
    connected_clients.append(ws)
    try:
        # Send current history on connect
        await ws.send_text(json.dumps({"type": "history", "data": list(history)}))
        while True:
            await ws.receive_text()   # keep alive
    except WebSocketDisconnect:
        if ws in connected_clients:
            connected_clients.remove(ws)
