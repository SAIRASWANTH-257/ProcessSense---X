import React, { useState } from 'react';
import { Sidebar } from './components/layout/Sidebar';
import { Header } from './components/layout/Header';
import LandingPage from './pages/LandingPage';
import Overview from './pages/Overview';
import LiveSensors from './pages/LiveSensors';
import AIAnalysis from './pages/AIAnalysis';
import ProcessFingerprint from './pages/ProcessFingerprint';
import DriftMonitor from './pages/DriftMonitor';
import YieldRisk from './pages/YieldRisk';
import DeviceHealth from './pages/DeviceHealth';
import DataExplorer from './pages/DataExplorer';
import Simulation from './pages/Simulation';
import Settings from './pages/Settings';
import type { PageId } from './types';
import { useSimulation } from './hooks/useSimulation';

export default function App() {
  const [showLanding, setShowLanding] = useState(true);
  const [activePage, setActivePage] = useState<PageId>('overview');

  // Activate the simulation engine globally
  useSimulation();

  function navigate(page: PageId) {
    setShowLanding(false);
    setActivePage(page);
  }

  if (showLanding) {
    return <LandingPage onEnter={(page) => navigate(page)} />;
  }

  const renderPage = () => {
    switch (activePage) {
      case 'overview':      return <Overview onNavigate={navigate} />;
      case 'live-sensors':  return <LiveSensors />;
      case 'ai-analysis':   return <AIAnalysis />;
      case 'fingerprint':   return <ProcessFingerprint />;
      case 'drift-monitor': return <DriftMonitor />;
      case 'yield-risk':    return <YieldRisk />;
      case 'device-health': return <DeviceHealth />;
      case 'data-explorer': return <DataExplorer />;
      case 'simulation':    return <Simulation onNavigate={navigate} />;
      case 'settings':      return <Settings />;
      default:              return <Overview onNavigate={navigate} />;
    }
  };

  return (
    <div className="flex h-screen bg-bg-primary overflow-hidden">
      {/* Sidebar */}
      <Sidebar activePage={activePage} onNavigate={setActivePage} />

      {/* Main content */}
      <div className="flex flex-col flex-1 min-w-0">
        <Header activePage={activePage} />
        <main className="flex-1 overflow-y-auto bg-bg-primary grid-bg">
          {renderPage()}
        </main>
      </div>
    </div>
  );
}
