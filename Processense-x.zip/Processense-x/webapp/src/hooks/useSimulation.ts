// ╔══════════════════════════════════════════════════════════════════╗
// ║   ProcessSense-X — Simulation Hook                              ║
// ║   Drives the simulation timer and demo story progression        ║
// ╚══════════════════════════════════════════════════════════════════╝

import { useEffect, useRef } from 'react';
import { useProcessStore } from '../store/processStore';
import {
  nextReading,
  resetSimulation,
  setScenario,
  getDemoPhase,
} from '../engine/simulationEngine';

export function useSimulation() {
  const {
    isSimulating,
    simScenario,
    simSpeed,
    addReading,
    setDemoPhase,
    setSimulating,
  } = useProcessStore();

  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null);

  useEffect(() => {
    if (isSimulating) {
      setScenario(simScenario);
      resetSimulation();
      setScenario(simScenario);

      intervalRef.current = setInterval(() => {
        const reading = nextReading();
        addReading(reading);
        // Sync demo phase from simulation engine
        const phase = getDemoPhase();
        setDemoPhase(phase);
      }, simSpeed);
    } else {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
        intervalRef.current = null;
      }
    }

    return () => {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
        intervalRef.current = null;
      }
    };
  }, [isSimulating, simScenario, simSpeed]);

  return { isSimulating, stop: () => setSimulating(false) };
}
