import React from 'react';
import { useProcessStore } from '../store/processStore';
import { RadarChart, Radar, PolarGrid, PolarAngleAxis, PolarRadiusAxis, ResponsiveContainer, Tooltip } from 'recharts';
import { Target, ArrowRight } from 'lucide-react';
import clsx from 'clsx';

function normalizeToPercent(value: number, min: number, max: number): number {
  const range = max - min;
  if (range === 0) return 50;
  return Math.round(((value - min) / range) * 100);
}

export default function ProcessFingerprint() {
  const { fingerprint, latestReading, analysis, readings, learnFingerprint } = useProcessStore();

  const fp = fingerprint;
  const current = latestReading;

  // Radar chart data — normalized to 0-100 within each sensor's min/max
  const radarData = [
    {
      axis: 'Temperature',
      normal: 50,
      current: current ? normalizeToPercent(current.temperature, fp.temperature.min - 2, fp.temperature.max + 2) : 50,
    },
    {
      axis: 'Pressure',
      normal: 50,
      current: current ? normalizeToPercent(current.pressure, fp.pressure.min - 2, fp.pressure.max + 2) : 50,
    },
    {
      axis: 'Current',
      normal: 50,
      current: current ? normalizeToPercent(current.current, fp.current.min - 0.5, fp.current.max + 0.5) : 50,
    },
    {
      axis: 'Stability',
      normal: 90,
      current: Math.round((analysis?.features.temperature.stability ?? 1) * 100),
    },
    {
      axis: 'Drift',
      normal: 5,
      current: Math.round((analysis?.driftScore ?? 0) * 100),
    },
  ];

  const sensorRows = [
    {
      label: 'Temperature', sensor: 'DS18B20', unit: '°C', color: '#00d4ff',
      normalMin: fp.temperature.min, normalMax: fp.temperature.max, normalMean: fp.temperature.mean,
      current: current?.temperature,
    },
    {
      label: 'Pressure', sensor: 'BMP280', unit: 'kPa', color: '#ff6b35',
      normalMin: fp.pressure.min, normalMax: fp.pressure.max, normalMean: fp.pressure.mean,
      current: current?.pressure,
    },
    {
      label: 'Current', sensor: 'ACS712', unit: 'A', color: '#ffd060',
      normalMin: fp.current.min, normalMax: fp.current.max, normalMean: fp.current.mean,
      current: current?.current,
    },
  ];

  return (
    <div className="p-6 space-y-5 animate-fade-in">

      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <div className="label-sm">NORMAL PROCESS FINGERPRINT</div>
          <div className="text-xs text-text-muted mt-0.5">
            Learned normal operating envelope — {fp.sampleCount} samples ·{' '}
            Learned {new Date(fp.learnedAt).toLocaleTimeString()}
          </div>
        </div>
        <button
          onClick={learnFingerprint}
          disabled={readings.length < 20}
          className={clsx('btn-outline text-xs py-2 px-4', readings.length < 20 && 'opacity-40 cursor-not-allowed')}
        >
          <Target size={13} /> Re-learn Fingerprint
        </button>
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-2 gap-5">

        {/* Radar Chart */}
        <div className="card">
          <div className="label-sm mb-4">PROCESS FINGERPRINT RADAR</div>
          <ResponsiveContainer width="100%" height={300}>
            <RadarChart data={radarData}>
              <PolarGrid stroke="rgba(0,212,255,0.1)" />
              <PolarAngleAxis dataKey="axis" tick={{ fill: '#7aa0c0', fontSize: 11, fontFamily: 'Inter' }} />
              <PolarRadiusAxis angle={30} domain={[0, 100]} tick={{ fill: '#3a5a78', fontSize: 9 }} />
              <Radar
                name="Normal Baseline"
                dataKey="normal"
                stroke="rgba(0,212,255,0.5)"
                fill="rgba(0,212,255,0.1)"
                strokeWidth={2}
              />
              <Radar
                name="Current Process"
                dataKey="current"
                stroke={analysis?.status === 'CRITICAL' ? '#ff3860' : analysis?.status === 'WARNING' ? '#ffd060' : '#00ff88'}
                fill={analysis?.status === 'CRITICAL' ? 'rgba(255,56,96,0.12)' : analysis?.status === 'WARNING' ? 'rgba(255,208,96,0.12)' : 'rgba(0,255,136,0.12)'}
                strokeWidth={2}
              />
              <Tooltip
                contentStyle={{ background: '#0a1c30', border: '1px solid rgba(0,212,255,0.2)', borderRadius: 8, fontSize: 11 }}
              />
            </RadarChart>
          </ResponsiveContainer>
          <div className="flex items-center gap-6 justify-center mt-2">
            <div className="flex items-center gap-2"><div className="w-3 h-0.5 bg-cyan" /><span className="text-[10px] text-text-muted">Normal Baseline</span></div>
            <div className="flex items-center gap-2">
              <div className="w-3 h-0.5" style={{ backgroundColor: analysis?.status === 'CRITICAL' ? '#ff3860' : analysis?.status === 'WARNING' ? '#ffd060' : '#00ff88' }} />
              <span className="text-[10px] text-text-muted">Current Process</span>
            </div>
          </div>
        </div>

        {/* Sensor Comparison Table */}
        <div className="space-y-4">
          <div className="card">
            <div className="label-sm mb-4">NORMAL BASELINE vs CURRENT PROCESS</div>
            <div className="space-y-4">
              {sensorRows.map(s => {
                const dev = s.current !== undefined ? ((s.current - s.normalMean) / s.normalMean) * 100 : null;
                const outOfRange = s.current !== undefined && (s.current < s.normalMin || s.current > s.normalMax);
                return (
                  <div key={s.label}>
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center gap-2">
                        <div className="w-2 h-2 rounded-full" style={{ backgroundColor: s.color }} />
                        <span className="label-sm" style={{ color: s.color }}>{s.label} · {s.sensor}</span>
                      </div>
                      {dev !== null && (
                        <span className={clsx('font-mono text-[10px] font-bold', outOfRange ? 'text-red' : 'text-green')}>
                          {dev > 0 ? '+' : ''}{dev.toFixed(1)}%
                        </span>
                      )}
                    </div>
                    <div className="grid grid-cols-2 gap-2">
                      <div className="bg-bg-surface rounded-lg p-2.5">
                        <div className="label-xs text-cyan mb-1">NORMAL BASELINE</div>
                        <div className="font-mono text-sm font-bold">{s.normalMin}–{s.normalMax} {s.unit}</div>
                        <div className="text-[10px] text-text-muted">μ = {s.normalMean.toFixed(2)}</div>
                      </div>
                      <div className={clsx('rounded-lg p-2.5', outOfRange ? 'bg-red/5 border border-red/20' : 'bg-bg-surface')}>
                        <div className={clsx('label-xs mb-1', outOfRange ? 'text-red' : 'text-green')}>CURRENT PROCESS</div>
                        <div className="font-mono text-sm font-bold">{s.current?.toFixed(2) ?? '--'} {s.unit}</div>
                        {outOfRange && <div className="text-[10px] text-red">⚠ Out of envelope</div>}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Fingerprint stats */}
          <div className="card">
            <div className="label-sm mb-3">FINGERPRINT STATISTICS</div>
            <div className="grid grid-cols-2 gap-3">
              {[
                { label: 'Sample Count', value: fp.sampleCount.toLocaleString() },
                { label: 'Temp σ', value: `${fp.temperature.std.toFixed(2)} °C` },
                { label: 'Press σ', value: `${fp.pressure.std.toFixed(2)} kPa` },
                { label: 'Current σ', value: `${fp.current.std.toFixed(3)} A` },
              ].map(s => (
                <div key={s.label} className="bg-bg-surface rounded-lg p-2.5">
                  <div className="label-xs">{s.label}</div>
                  <div className="font-mono text-xs font-bold text-cyan mt-0.5">{s.value}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
