import React from 'react';
import { useProcessStore } from '../store/processStore';
import {
  ComposedChart, Line, Bar, XAxis, YAxis, CartesianGrid, Tooltip,
  ResponsiveContainer, Legend,
} from 'recharts';
import { Cpu, ArrowRight, BarChart2 } from 'lucide-react';
import clsx from 'clsx';
import type { ProcessFeatures } from '../types';

export default function AIAnalysis() {
  const { analysis, readings } = useProcessStore();

  const PIPELINE = [
    { step: 'SENSOR DATA',         desc: 'Raw DS18B20 · BMP280 · ACS712 readings at ~2 Hz' },
    { step: 'CALIBRATION',         desc: 'Apply fixed sensor offset corrections' },
    { step: 'NOISE FILTERING',     desc: 'Reject readings beyond 3.5σ from moving average' },
    { step: 'MOVING AVERAGE',      desc: '8-sample rolling window per sensor' },
    { step: 'NORMALIZATION',       desc: 'Scale values relative to fingerprint min/max' },
    { step: 'FEATURE EXTRACTION',  desc: 'Mean · StdDev · Rate-of-Change · Stability · Cross-correlation' },
    { step: 'NORMAL FINGERPRINT',  desc: 'Compare against learned normal operating envelope' },
    { step: 'ANOMALY DETECTION',   desc: 'Weighted sigma-deviation from fingerprint centroid' },
    { step: 'DRIFT DETECTION',     desc: 'Rate-of-change slope relative to baseline σ' },
    { step: 'SEVERITY SCORE',      desc: 'Composite: 65% anomaly · 35% drift → 0–100 scale' },
    { step: 'YIELD-RISK ESTIMATE', desc: 'Non-linear heuristic mapping severity → risk %' },
  ];

  function formatFeature(v: number | undefined, decimals = 3): string {
    if (v === undefined) return '--';
    return v.toFixed(decimals);
  }

  const features: ProcessFeatures | undefined = analysis?.features;

  // Chart data — feature deviations
  const chartData = features
    ? [
        { name: 'Temp',  deviation: Math.abs(features.temperature.deviationPercent), stability: features.temperature.stability * 100 },
        { name: 'Press', deviation: Math.abs(features.pressure.deviationPercent),    stability: features.pressure.stability    * 100 },
        { name: 'Curr',  deviation: Math.abs(features.current.deviationPercent),     stability: features.current.stability     * 100 },
      ]
    : [];

  return (
    <div className="p-6 space-y-5 animate-fade-in">

      {/* Header */}
      <div>
        <div className="label-sm">PROCESSSENSE-X AI ENGINE</div>
        <div className="text-xs text-text-muted mt-0.5">
          Full processing pipeline · {readings.length} samples processed
        </div>
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-3 gap-5">

        {/* Pipeline visualization */}
        <div className="card xl:col-span-1">
          <div className="label-sm mb-4">PROCESSING PIPELINE</div>
          <div className="space-y-1.5">
            {PIPELINE.map((p, i) => (
              <div key={p.step}>
                <div className={clsx(
                  'flex items-start gap-2.5 p-2 rounded-lg',
                  analysis ? 'bg-bg-surface' : 'bg-bg-surface opacity-50'
                )}>
                  <div className="w-5 h-5 rounded-full bg-cyan/10 border border-cyan/30 flex items-center justify-center flex-shrink-0 mt-0.5">
                    <span className="text-[8px] font-bold text-cyan">{i + 1}</span>
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="text-[10px] font-bold text-text-primary tracking-wide">{p.step}</div>
                    <div className="text-[9px] text-text-muted mt-0.5 leading-snug">{p.desc}</div>
                  </div>
                  {analysis && <div className="text-green text-[10px] flex-shrink-0 mt-0.5">✓</div>}
                </div>
                {i < PIPELINE.length - 1 && (
                  <div className="ml-4 pl-[7px] border-l border-cyan/10 py-0.5">
                    <div className="text-[8px] text-text-muted">↓</div>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>

        {/* Results + Features */}
        <div className="xl:col-span-2 space-y-4">

          {/* AI output */}
          <div className="card">
            <div className="label-sm mb-4">AI ENGINE OUTPUT</div>
            {analysis ? (
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                {[
                  { label: 'Anomaly Score',  val: analysis.anomalyScore.toFixed(3), color: '#00d4ff',  desc: '0 = normal, 1 = full anomaly' },
                  { label: 'Drift Score',    val: analysis.driftScore.toFixed(3),   color: '#b060ff',  desc: 'Rate of parameter change' },
                  { label: 'Severity',       val: `${analysis.severityScore} / 100`,color: analysis.status === 'CRITICAL' ? '#ff3860' : analysis.status === 'WARNING' ? '#ffd060' : '#00ff88', desc: '0–30 Normal · 31–70 Warning · 71–100 Critical' },
                  { label: 'Yield Risk',     val: `${analysis.yieldRisk}%`,         color: '#ffd060',  desc: 'AI estimate · prototype' },
                  { label: 'Confidence',     val: `${analysis.confidence}%`,        color: '#00d4ff',  desc: 'Based on history depth' },
                  { label: 'Status',         val: analysis.status,                  color: analysis.status === 'CRITICAL' ? '#ff3860' : analysis.status === 'WARNING' ? '#ffd060' : '#00ff88', desc: 'NORMAL · WARNING · CRITICAL' },
                ].map(m => (
                  <div key={m.label} className="bg-bg-surface rounded-xl p-3">
                    <div className="label-xs mb-2">{m.label}</div>
                    <div className="font-mono font-bold text-base" style={{ color: m.color }}>{m.val}</div>
                    <div className="text-[9px] text-text-muted mt-1 leading-snug">{m.desc}</div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-8 text-xs text-text-muted">
                No analysis yet — start simulation to run the AI engine
              </div>
            )}
          </div>

          {/* Feature extraction table */}
          {features && (
            <div className="card">
              <div className="label-sm mb-4">EXTRACTED FEATURES</div>
              <div className="overflow-auto">
                <table className="w-full text-[11px]">
                  <thead>
                    <tr className="border-b border-border">
                      <th className="text-left py-2 px-2 label-xs">FEATURE</th>
                      <th className="text-right py-2 px-2 label-xs text-cyan">TEMPERATURE</th>
                      <th className="text-right py-2 px-2 label-xs text-orange-400">PRESSURE</th>
                      <th className="text-right py-2 px-2 label-xs text-yellow">CURRENT</th>
                    </tr>
                  </thead>
                  <tbody>
                    {[
                      { label: 'Moving Avg',     t: features.temperature.movingAverage,         p: features.pressure.movingAverage,    c: features.current.movingAverage,    d: 2 },
                      { label: 'Mean',           t: features.temperature.mean,                  p: features.pressure.mean,             c: features.current.mean,             d: 2 },
                      { label: 'Std Dev',        t: features.temperature.std,                   p: features.pressure.std,              c: features.current.std,              d: 3 },
                      { label: 'Rate of Change', t: features.temperature.rateOfChange,          p: features.pressure.rateOfChange,     c: features.current.rateOfChange,     d: 3 },
                      { label: 'Stability',      t: features.temperature.stability,             p: features.pressure.stability,        c: features.current.stability,        d: 3 },
                      { label: 'Dev (σ)',        t: features.temperature.deviationFromBaseline, p: features.pressure.deviationFromBaseline, c: features.current.deviationFromBaseline, d: 3 },
                      { label: 'Dev (%)',        t: features.temperature.deviationPercent,      p: features.pressure.deviationPercent, c: features.current.deviationPercent, d: 2 },
                    ].map(row => (
                      <tr key={row.label} className="border-b border-border/30 hover:bg-bg-hover transition-colors">
                        <td className="py-2 px-2 text-text-muted">{row.label}</td>
                        <td className="py-2 px-2 text-right font-mono text-cyan">{formatFeature(row.t, row.d)}</td>
                        <td className="py-2 px-2 text-right font-mono text-orange-400">{formatFeature(row.p, row.d)}</td>
                        <td className="py-2 px-2 text-right font-mono text-yellow">{formatFeature(row.c, row.d)}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              {/* Cross correlations */}
              <div className="mt-4 border-t border-border pt-4">
                <div className="label-xs mb-2">CROSS-SENSOR CORRELATION (Pearson r)</div>
                <div className="grid grid-cols-3 gap-2">
                  {[
                    { label: 'Temp ↔ Press', val: features.crossCorrelation.tempPressure },
                    { label: 'Temp ↔ Curr',  val: features.crossCorrelation.tempCurrent },
                    { label: 'Press ↔ Curr', val: features.crossCorrelation.pressureCurrent },
                  ].map(c => (
                    <div key={c.label} className="bg-bg-surface rounded-lg p-2 text-center">
                      <div className="label-xs">{c.label}</div>
                      <div className="font-mono text-xs font-bold text-cyan mt-1">{c.val.toFixed(3)}</div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* Feature chart */}
          {chartData.length > 0 && (
            <div className="card">
              <div className="label-sm mb-4">DEVIATION vs STABILITY BY SENSOR</div>
              <ResponsiveContainer width="100%" height={160}>
                <ComposedChart data={chartData} margin={{ top: 4, right: 8, bottom: 4, left: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="rgba(0,212,255,0.06)" />
                  <XAxis dataKey="name" tick={{ fill: '#7aa0c0', fontSize: 10 }} />
                  <YAxis tick={{ fill: '#3a5a78', fontSize: 9 }} />
                  <Tooltip contentStyle={{ background: '#0a1c30', border: '1px solid rgba(0,212,255,0.2)', borderRadius: 8, fontSize: 11 }} />
                  <Legend wrapperStyle={{ fontSize: 11, color: '#7aa0c0' }} />
                  <Bar dataKey="deviation" fill="rgba(0,212,255,0.4)" name="Deviation %" radius={[4,4,0,0]} />
                  <Line type="monotone" dataKey="stability" stroke="#00ff88" strokeWidth={2} dot={{ fill: '#00ff88', r: 4 }} name="Stability %" />
                </ComposedChart>
              </ResponsiveContainer>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
