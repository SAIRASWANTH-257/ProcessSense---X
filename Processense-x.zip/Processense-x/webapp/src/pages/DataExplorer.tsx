import React, { useState, useMemo } from 'react';
import { useProcessStore } from '../store/processStore';
import { Download, Filter, BarChart2 } from 'lucide-react';
import clsx from 'clsx';
import type { SensorReading } from '../types';

type SensorField = 'temperature' | 'pressure' | 'current';

function mean(arr: number[]) { return arr.length ? arr.reduce((s,v)=>s+v,0)/arr.length : 0; }
function stdDev(arr: number[]) {
  if (arr.length < 2) return 0;
  const m = mean(arr);
  return Math.sqrt(arr.reduce((s,v)=>s+(v-m)**2,0)/(arr.length-1));
}

export default function DataExplorer() {
  const { readings, driftEvents } = useProcessStore();
  const [selectedSensor, setSelectedSensor] = useState<SensorField>('temperature');
  const [showAnomalies, setShowAnomalies] = useState(false);

  const SENSOR_CONFIG = {
    temperature: { label: 'Temperature', unit: '°C',  color: '#00d4ff' },
    pressure:    { label: 'Pressure',    unit: 'kPa', color: '#ff6b35' },
    current:     { label: 'Current',     unit: 'A',   color: '#ffd060' },
  };

  const values = readings.map(r => r[selectedSensor]);
  const stats = useMemo(() => ({
    count:   values.length,
    mean:    mean(values),
    min:     values.length ? Math.min(...values) : 0,
    max:     values.length ? Math.max(...values) : 0,
    std:     stdDev(values),
    variance: stdDev(values) ** 2,
    anomalies: driftEvents.filter(e => e.status !== 'NORMAL').length,
    driftEvents: driftEvents.filter(e => e.status === 'CRITICAL').length,
  }), [values, driftEvents]);

  function exportCSV() {
    const header = 'timestamp,temperature_C,pressure_kPa,current_A\n';
    const rows = readings.map(r =>
      `${r.timestamp},${r.temperature},${r.pressure},${r.current}`
    ).join('\n');
    const blob = new Blob([header + rows], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = 'processsense-x-data.csv'; a.click();
    URL.revokeObjectURL(url);
  }

  function exportJSON() {
    const blob = new Blob([JSON.stringify(readings, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = 'processsense-x-data.json'; a.click();
    URL.revokeObjectURL(url);
  }

  const displayedReadings = showAnomalies
    ? readings.filter((_, i) => driftEvents[driftEvents.length - 1 - i]?.status !== 'NORMAL')
    : readings;

  const cfg = SENSOR_CONFIG[selectedSensor];

  return (
    <div className="p-6 space-y-5 animate-fade-in">

      {/* Header + controls */}
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <div className="label-sm">PROCESS DATA EXPLORER</div>
          <div className="text-xs text-text-muted mt-0.5">{readings.length} readings collected</div>
        </div>
        <div className="flex items-center gap-2">
          <button onClick={exportCSV} className="btn-outline text-xs py-2 px-3">
            <Download size={13} /> CSV
          </button>
          <button onClick={exportJSON} className="btn-outline text-xs py-2 px-3">
            <Download size={13} /> JSON
          </button>
        </div>
      </div>

      {/* Sensor selector */}
      <div className="flex items-center gap-2">
        <Filter size={13} className="text-text-muted" />
        <span className="label-xs mr-2">Sensor:</span>
        {(Object.keys(SENSOR_CONFIG) as SensorField[]).map(s => (
          <button
            key={s}
            onClick={() => setSelectedSensor(s)}
            className={clsx(
              'px-3 py-1.5 rounded-lg text-xs font-semibold transition-all border',
              selectedSensor === s
                ? 'border-cyan/50 bg-cyan/10 text-cyan'
                : 'border-border text-text-muted hover:text-text-secondary'
            )}
          >
            {SENSOR_CONFIG[s].label}
          </button>
        ))}
        <button
          onClick={() => setShowAnomalies(!showAnomalies)}
          className={clsx(
            'px-3 py-1.5 rounded-lg text-xs font-semibold transition-all border ml-2',
            showAnomalies ? 'border-yellow/50 bg-yellow/10 text-yellow' : 'border-border text-text-muted'
          )}
        >
          {showAnomalies ? '⚡ Anomalies Only' : 'All Data'}
        </button>
      </div>

      {/* Statistics */}
      <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-3">
        {[
          { label: 'COUNT',     val: stats.count.toLocaleString() },
          { label: 'MEAN',      val: `${stats.mean.toFixed(2)} ${cfg.unit}` },
          { label: 'MIN',       val: `${stats.min.toFixed(2)} ${cfg.unit}` },
          { label: 'MAX',       val: `${stats.max.toFixed(2)} ${cfg.unit}` },
          { label: 'STD DEV',   val: `±${stats.std.toFixed(3)}` },
          { label: 'ANOMALIES', val: `${stats.anomalies}`, color: stats.anomalies > 0 ? 'text-yellow' : 'text-green' },
          { label: 'DRIFT EVTS',val: `${stats.driftEvents}`, color: stats.driftEvents > 0 ? 'text-red' : 'text-green' },
        ].map(s => (
          <div key={s.label} className="card text-center py-3">
            <div className="label-xs">{s.label}</div>
            <div className={clsx('font-mono text-sm font-bold mt-1', s.color ?? 'text-text-primary')}>
              {s.val}
            </div>
          </div>
        ))}
      </div>

      {/* Data table */}
      <div className="card">
        <div className="flex items-center justify-between mb-4">
          <div className="label-sm">RAW READINGS</div>
          <span className="label-xs font-mono">Showing last {Math.min(displayedReadings.length, 100)} of {displayedReadings.length}</span>
        </div>
        <div className="overflow-auto max-h-96">
          <table className="w-full text-xs">
            <thead>
              <tr className="border-b border-border">
                {['#', 'Timestamp', 'Temperature (°C)', 'Pressure (kPa)', 'Current (A)'].map(col => (
                  <th key={col} className="text-left py-2 px-3 label-xs">{col}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {readings.slice(-100).reverse().map((r, i) => (
                <tr key={i} className="border-b border-border/50 hover:bg-bg-hover transition-colors">
                  <td className="py-2 px-3 font-mono text-text-muted">{readings.length - i}</td>
                  <td className="py-2 px-3 font-mono text-text-muted">
                    {new Date(r.timestamp).toLocaleTimeString('en-US', { hour12: false })}
                  </td>
                  <td className="py-2 px-3 font-mono text-cyan font-medium">{r.temperature.toFixed(1)}</td>
                  <td className="py-2 px-3 font-mono text-orange-400 font-medium">{r.pressure.toFixed(2)}</td>
                  <td className="py-2 px-3 font-mono text-yellow font-medium">{r.current.toFixed(2)}</td>
                </tr>
              ))}
              {readings.length === 0 && (
                <tr>
                  <td colSpan={5} className="text-center py-10 text-text-muted">No data — start simulation to collect readings</td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
