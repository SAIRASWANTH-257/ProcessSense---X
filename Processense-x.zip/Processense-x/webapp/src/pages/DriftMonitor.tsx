import React from 'react';
import { useProcessStore } from '../store/processStore';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { CheckCircle, AlertTriangle, AlertOctagon, Clock } from 'lucide-react';
import clsx from 'clsx';
import type { ProcessStatus } from '../types';

const STATUS_CONFIG: Record<ProcessStatus, { icon: React.ReactNode; color: string; bg: string; border: string }> = {
  NORMAL:   { icon: <CheckCircle size={13} />,    color: 'text-green',  bg: 'bg-green/5',  border: 'border-green/20' },
  WARNING:  { icon: <AlertTriangle size={13} />,  color: 'text-yellow', bg: 'bg-yellow/5', border: 'border-yellow/20' },
  CRITICAL: { icon: <AlertOctagon size={13} />,   color: 'text-red',    bg: 'bg-red/5',    border: 'border-red/20' },
};

export default function DriftMonitor() {
  const { driftEvents, analysis, fingerprint, readings, alerts, acknowledgeAlert } = useProcessStore();

  // Anomaly score chart
  const scoreData = driftEvents.slice(-60).reverse().map((e, i) => ({
    i,
    anomaly: Math.round(e.anomalyScore * 1000) / 10,
    drift:   Math.round(e.driftScore   * 1000) / 10,
    status:  e.status,
  }));

  const activeAlerts = alerts.filter(a => !a.acknowledged);

  return (
    <div className="p-6 space-y-5 animate-fade-in">

      {/* Header */}
      <div>
        <div className="label-sm">ANOMALY & DRIFT MONITOR</div>
        <div className="text-xs text-text-muted mt-0.5">
          Real-time process deviation detection · {driftEvents.length} events recorded
        </div>
      </div>

      {/* Current status banner */}
      {analysis && (
        <div className={clsx(
          'card flex items-center gap-4',
          analysis.status === 'CRITICAL' ? 'border-red/40 bg-red/5' :
          analysis.status === 'WARNING'  ? 'border-yellow/30 bg-yellow/5' :
                                           'border-green/30 bg-green/5'
        )}>
          <div className={clsx('text-2xl', {
            'text-green': analysis.status === 'NORMAL',
            'text-yellow': analysis.status === 'WARNING',
            'text-red': analysis.status === 'CRITICAL',
          })}>
            {analysis.status === 'NORMAL' ? '🟢' : analysis.status === 'WARNING' ? '🟡' : '🔴'}
          </div>
          <div className="flex-1">
            <div className={clsx('font-bold text-sm', {
              'text-green': analysis.status === 'NORMAL',
              'text-yellow': analysis.status === 'WARNING',
              'text-red': analysis.status === 'CRITICAL',
            })}>
              {analysis.status === 'NORMAL'
                ? 'PROCESS NORMAL — All parameters within normal operating envelope'
                : analysis.status === 'WARNING'
                ? 'WARNING — Process drift detected. Multi-parameter deviation from fingerprint.'
                : 'CRITICAL — Significant process deviation. Immediate review required.'}
            </div>
            <div className="text-xs text-text-muted mt-1">{analysis.interpretation}</div>
          </div>
          <div className="grid grid-cols-2 gap-3 text-right flex-shrink-0">
            <div>
              <div className="label-xs">ANOMALY</div>
              <div className="font-mono font-bold text-cyan">{analysis.anomalyScore.toFixed(3)}</div>
            </div>
            <div>
              <div className="label-xs">DRIFT</div>
              <div className="font-mono font-bold text-blue">{analysis.driftScore.toFixed(3)}</div>
            </div>
          </div>
        </div>
      )}

      {/* Charts + Timeline */}
      <div className="grid grid-cols-1 xl:grid-cols-2 gap-5">

        {/* Score chart */}
        <div className="card">
          <div className="label-sm mb-4">ANOMALY & DRIFT SCORE HISTORY</div>
          <ResponsiveContainer width="100%" height={200}>
            <LineChart data={scoreData} margin={{ top: 4, right: 8, bottom: 4, left: 0 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(0,212,255,0.06)" />
              <XAxis dataKey="i" hide />
              <YAxis domain={[0, 100]} tick={{ fill: '#3a5a78', fontSize: 9 }} />
              <Tooltip
                contentStyle={{ background: '#0a1c30', border: '1px solid rgba(0,212,255,0.2)', borderRadius: 8, fontSize: 11 }}
              />
              {/* Warning threshold at 30 */}
              <Line type="monotone" dataKey={() => 30} stroke="rgba(255,208,96,0.3)" strokeDasharray="4 4" dot={false} strokeWidth={1} name="Warn threshold" />
              {/* Critical threshold at 70 */}
              <Line type="monotone" dataKey={() => 70} stroke="rgba(255,56,96,0.3)" strokeDasharray="4 4" dot={false} strokeWidth={1} name="Crit threshold" />
              <Line type="monotone" dataKey="anomaly" stroke="#00d4ff" strokeWidth={2} dot={false} name="Anomaly %" isAnimationActive={false} />
              <Line type="monotone" dataKey="drift"   stroke="#b060ff" strokeWidth={2} dot={false} name="Drift %"   isAnimationActive={false} />
            </LineChart>
          </ResponsiveContainer>
        </div>

        {/* Contributing sensors when anomaly */}
        <div className="card">
          <div className="label-sm mb-4">DRIFT CONTRIBUTORS</div>
          {analysis && analysis.status !== 'NORMAL' ? (
            <div className="space-y-4">
              <div className="text-xs text-text-secondary">
                <strong className={clsx({ 'text-yellow': analysis.status === 'WARNING', 'text-red': analysis.status === 'CRITICAL' })}>
                  DETECTED PROCESS DRIFT
                </strong> — Multi-parameter deviation
              </div>
              {[
                { label: 'Temperature', pct: analysis.contributors.temperature, dev: analysis.featureDeviations.temperature, color: '#00d4ff' },
                { label: 'Pressure',    pct: analysis.contributors.pressure,    dev: analysis.featureDeviations.pressure,    color: '#ff6b35' },
                { label: 'Current',     pct: analysis.contributors.current,     dev: analysis.featureDeviations.current,     color: '#ffd060' },
              ].map(s => (
                <div key={s.label}>
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-xs font-medium" style={{ color: s.color }}>{s.label}</span>
                    <div className="flex items-center gap-3">
                      <span className="font-mono text-[10px] text-text-muted">+{s.dev.toFixed(1)}% dev</span>
                      <span className="font-mono text-xs font-bold text-text-primary">{s.pct}%</span>
                    </div>
                  </div>
                  <div className="h-2 bg-bg-surface rounded-full overflow-hidden">
                    <div
                      className="h-full rounded-full transition-all duration-500"
                      style={{ width: `${s.pct}%`, backgroundColor: s.color, opacity: 0.8 }}
                    />
                  </div>
                </div>
              ))}
              <div className="mt-4 p-3 bg-bg-surface rounded-lg">
                <div className="label-xs text-yellow mb-1">AI INTERPRETATION</div>
                <div className="text-xs text-text-secondary">{analysis.interpretation}</div>
              </div>
            </div>
          ) : (
            <div className="flex flex-col items-center justify-center py-10 text-center">
              <div className="text-3xl mb-3">🟢</div>
              <div className="text-sm font-bold text-green">No Drift Detected</div>
              <div className="text-xs text-text-muted mt-1">Process fingerprint nominal</div>
            </div>
          )}
        </div>
      </div>

      {/* Drift Event Timeline */}
      <div className="card">
        <div className="flex items-center justify-between mb-4">
          <div className="label-sm">PROCESS EVENT TIMELINE</div>
          <span className="label-xs font-mono">{driftEvents.length} events</span>
        </div>
        <div className="max-h-64 overflow-y-auto space-y-1 pr-1">
          {driftEvents.length === 0 ? (
            <div className="text-center py-8 text-xs text-text-muted">No events yet — start simulation to generate data</div>
          ) : (
            driftEvents.slice(0, 50).map(event => {
              const cfg = STATUS_CONFIG[event.status];
              return (
                <div key={event.id} className={clsx('flex items-center gap-3 px-3 py-2 rounded-lg border text-xs', cfg.bg, cfg.border)}>
                  <div className={cfg.color}>{cfg.icon}</div>
                  <span className="font-mono text-text-muted text-[10px] flex-shrink-0">
                    {new Date(event.timestamp).toLocaleTimeString('en-US', { hour12: false })}
                  </span>
                  <span className={clsx('font-semibold flex-1', cfg.color)}>— {event.message}</span>
                  {event.sensors.length > 0 && (
                    <span className="text-[9px] text-text-muted">{event.sensors.join(', ')}</span>
                  )}
                  <span className="font-mono text-[9px] text-text-muted">
                    A:{event.anomalyScore.toFixed(2)}
                  </span>
                </div>
              );
            })
          )}
        </div>
      </div>

      {/* Active Alerts */}
      {activeAlerts.length > 0 && (
        <div className="card border-red/30">
          <div className="flex items-center justify-between mb-4">
            <div className="label-sm text-red">ACTIVE PROCESS ALERTS</div>
            <span className="text-[10px] font-mono text-red">{activeAlerts.length} unresolved</span>
          </div>
          <div className="space-y-3">
            {activeAlerts.map(alert => (
              <div key={alert.id} className={clsx(
                'p-4 rounded-xl border',
                alert.level === 'CRITICAL' ? 'bg-red/5 border-red/40' : 'bg-yellow/5 border-yellow/30'
              )}>
                <div className="flex items-start justify-between gap-3">
                  <div className="flex-1">
                    <div className={clsx('text-sm font-bold mb-1', alert.level === 'CRITICAL' ? 'text-red' : 'text-yellow')}>
                      {alert.level === 'CRITICAL' ? '🔴' : '🟡'} {alert.level} — {alert.message}
                    </div>
                    {alert.sensors.length > 0 && (
                      <div className="text-xs text-text-muted mb-2">Detected: {alert.sensors.join(' · ')}</div>
                    )}
                    <div className="text-xs text-text-secondary">
                      <span className="font-semibold">Recommended: </span>{alert.recommendation}
                    </div>
                  </div>
                  <button
                    onClick={() => acknowledgeAlert(alert.id)}
                    className="btn-outline text-[10px] py-1.5 px-3 flex-shrink-0"
                  >
                    ACKNOWLEDGE
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
