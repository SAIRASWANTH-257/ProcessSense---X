import React, { useState } from 'react';
import { useProcessStore } from '../store/processStore';
import { GaugeChart } from '../components/common/GaugeChart';
import { Play, Square, RotateCcw, Zap, ChevronRight } from 'lucide-react';
import clsx from 'clsx';
import type { SimScenario, DemoPhase, PageId } from '../types';
import { DEMO_PHASES } from '../engine/simulationEngine';

const SCENARIOS: { id: SimScenario; label: string; desc: string; color: string }[] = [
  { id: 'normal',                label: 'NORMAL PROCESS',          desc: 'Stable temperature, pressure, and current within normal envelope.',       color: '#00ff88' },
  { id: 'thermal-drift',         label: 'THERMAL DRIFT',           desc: 'Temperature gradually climbs above the normal operating range.',            color: '#ffd060' },
  { id: 'pressure-instability',  label: 'PRESSURE INSTABILITY',    desc: 'Pressure oscillates with growing amplitude — potential pump fault.',        color: '#ff6b35' },
  { id: 'electrical-load',       label: 'ELECTRICAL LOAD INCREASE', desc: 'Current ramps up progressively — excess electrical draw detected.',        color: '#b060ff' },
  { id: 'combined-drift',        label: 'COMBINED PROCESS DRIFT',  desc: 'All three parameters drift simultaneously — full demo story (5 phases).',   color: '#ff3860' },
];

interface SimulationProps {
  onNavigate: (page: PageId) => void;
}

export default function Simulation({ onNavigate }: SimulationProps) {
  const {
    isSimulating, simScenario, simSpeed, demoPhase, analysis,
    setSimulating, setSimScenario, setSimSpeed, resetHistory,
  } = useProcessStore();
  const [speed, setSpeed] = useState(simSpeed);

  function startDemo() {
    resetHistory();
    setSimScenario('combined-drift');
    setSimSpeed(speed);
    setSimulating(true);
  }

  function startScenario(scenario: SimScenario) {
    resetHistory();
    setSimScenario(scenario);
    setSimSpeed(speed);
    setSimulating(true);
  }

  function stop() {
    setSimulating(false);
  }

  const currentPhaseInfo = DEMO_PHASES.find(p => p.phase === demoPhase) ?? DEMO_PHASES[0];
  const status = analysis?.status ?? 'NORMAL';

  return (
    <div className="p-6 space-y-5 animate-fade-in">

      {/* Header */}
      <div>
        <div className="label-sm">DEMO SIMULATION</div>
        <div className="text-xs text-text-muted mt-0.5">
          Full AI simulation without physical hardware — perfect for hackathon presentations
        </div>
      </div>

      {/* START DEMO hero */}
      <div className={clsx(
        'card py-8 text-center border-2',
        isSimulating
          ? status === 'CRITICAL' ? 'border-red/50 bg-red/5'
          : status === 'WARNING'  ? 'border-yellow/40 bg-yellow/5'
          : 'border-green/40 bg-green/5'
          : 'border-dashed border-cyan/30'
      )}>
        {!isSimulating ? (
          <div className="flex flex-col items-center gap-5">
            <div className="w-16 h-16 rounded-2xl bg-cyan/10 border border-cyan/30 flex items-center justify-center">
              <Zap size={28} className="text-cyan" />
            </div>
            <div>
              <div className="text-lg font-black text-text-primary tracking-wide">HACKATHON DEMO SIMULATION</div>
              <div className="text-sm text-text-secondary mt-2 max-w-lg mx-auto">
                Runs the full 5-phase demo story — NORMAL → THERMAL DRIFT → MULTI-SENSOR DRIFT → CRITICAL → EARLY WARNING
              </div>
            </div>
            <button onClick={startDemo} className="btn-primary text-base px-8 py-3">
              <Play size={18} /> START DEMO
            </button>
          </div>
        ) : (
          <div className="flex flex-col items-center gap-4">
            {/* Live gauge */}
            <GaugeChart
              value={analysis ? 100 - analysis.severityScore : 100}
              size={150}
              label={status}
              sublabel="/ 100"
              status={status}
            />
            {/* Phase indicator */}
            <div className="flex items-center gap-2 flex-wrap justify-center">
              {DEMO_PHASES.map(p => (
                <div key={p.phase} className={clsx(
                  'w-8 h-8 rounded-full border-2 flex items-center justify-center text-xs font-bold transition-all',
                  p.phase === demoPhase
                    ? 'border-cyan bg-cyan text-bg-primary scale-110'
                    : p.phase < demoPhase
                    ? 'border-green/50 bg-green/10 text-green'
                    : 'border-text-muted/20 text-text-muted'
                )}>
                  {p.phase}
                </div>
              ))}
            </div>
            <div className="text-sm font-bold text-text-primary">{currentPhaseInfo.title}</div>
            <div className="text-xs text-text-secondary max-w-md">{currentPhaseInfo.description}</div>
            <div className="flex items-center gap-3">
              <button onClick={stop} className="btn-danger">
                <Square size={14} /> STOP
              </button>
              <button onClick={() => { stop(); resetHistory(); }} className="btn-outline">
                <RotateCcw size={14} /> RESET
              </button>
              <button onClick={() => onNavigate('overview')} className="btn-outline">
                View Dashboard <ChevronRight size={14} />
              </button>
            </div>
          </div>
        )}
      </div>

      {/* 5-phase story */}
      <div className="card">
        <div className="label-sm mb-4">DEMO STORY — 5 PHASES</div>
        <div className="space-y-2">
          {DEMO_PHASES.map(p => {
            const isActive = isSimulating && demoPhase === p.phase;
            const isDone   = isSimulating && demoPhase > p.phase;
            return (
              <div key={p.phase} className={clsx(
                'flex items-start gap-3 p-3 rounded-lg border transition-all',
                isActive ? 'bg-cyan/5 border-cyan/30' :
                isDone   ? 'bg-green/5 border-green/20' :
                           'bg-bg-surface border-transparent'
              )}>
                <div className={clsx(
                  'w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold flex-shrink-0',
                  isActive ? 'bg-cyan text-bg-primary' :
                  isDone   ? 'bg-green/20 text-green' :
                             'bg-bg-hover text-text-muted'
                )}>
                  {isDone ? '✓' : p.phase}
                </div>
                <div>
                  <div className={clsx('text-xs font-bold', isActive ? 'text-cyan' : isDone ? 'text-green' : 'text-text-primary')}>
                    {p.title}
                  </div>
                  <div className="text-[10px] text-text-muted mt-0.5">{p.description}</div>
                  <div className="text-[9px] text-text-muted mt-0.5">
                    Expected severity: {p.expectedScore} · Status: {p.status}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Individual scenarios */}
      <div className="card">
        <div className="label-sm mb-4">INDIVIDUAL SCENARIOS</div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {SCENARIOS.map(sc => (
            <div key={sc.id} className={clsx(
              'p-4 rounded-xl border cursor-pointer transition-all hover:border-opacity-60',
              isSimulating && simScenario === sc.id ? 'bg-bg-surface border-opacity-100' : 'border-border hover:bg-bg-hover'
            )}
            style={{ borderColor: isSimulating && simScenario === sc.id ? sc.color : undefined }}>
              <div className="flex items-center justify-between mb-2">
                <div className="text-xs font-bold" style={{ color: sc.color }}>{sc.label}</div>
                {isSimulating && simScenario === sc.id && (
                  <span className="text-[9px] font-bold animate-pulse" style={{ color: sc.color }}>● RUNNING</span>
                )}
              </div>
              <div className="text-[10px] text-text-muted mb-3">{sc.desc}</div>
              <button
                onClick={() => isSimulating && simScenario === sc.id ? stop() : startScenario(sc.id)}
                className={clsx('text-[10px] font-bold px-3 py-1.5 rounded-lg border transition-all w-full', {
                  'border-red/40 text-red bg-red/10': isSimulating && simScenario === sc.id,
                  'border-border text-text-secondary hover:text-text-primary': !(isSimulating && simScenario === sc.id),
                })}
              >
                {isSimulating && simScenario === sc.id ? '■ STOP' : '▶ START'}
              </button>
            </div>
          ))}
        </div>
      </div>

      {/* Speed control */}
      <div className="card">
        <div className="label-sm mb-3">SIMULATION SPEED</div>
        <div className="flex items-center gap-4">
          <span className="text-xs text-text-muted w-20 text-right">Slower</span>
          <input
            type="range" min={100} max={2000} step={100} value={speed}
            onChange={e => { setSpeed(Number(e.target.value)); if (isSimulating) setSimSpeed(Number(e.target.value)); }}
            className="flex-1 accent-cyan"
          />
          <span className="text-xs text-text-muted w-20">Faster</span>
          <span className="font-mono text-xs text-cyan w-20">{speed}ms / sample</span>
        </div>
      </div>
    </div>
  );
}
