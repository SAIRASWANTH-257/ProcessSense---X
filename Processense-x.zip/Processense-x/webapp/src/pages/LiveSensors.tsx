import React, { useState } from 'react';
import { useProcessStore } from '../store/processStore';
import {
  LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip,
  ResponsiveContainer, ReferenceLine, Brush,
} from 'recharts';
import { Thermometer, Gauge, Zap, TrendingDown, TrendingUp, Minus } from 'lucide-react';
import clsx from 'clsx';

type TimeRange = '1min' | '5min' | '15min' | '1hr';

const TIME_RANGE_SAMPLES: Record<TimeRange, number> = {
  '1min': 120, '5min': 360, '15min': 360, '1hr': 360,
};

const SENSORS = [
  {
    id: 'temperature' as const,
    label: 'TEMPERATURE',
    sensor: 'DS18B20',
    unit: '°C',
    color: '#00d4ff',
    normalMin: 70,
    normalMax: 75,
    icon: <Thermometer size={18} />,
  },
  {
    id: 'pressure' as const,
    label: 'PRESSURE',
    sensor: 'BMP280',
    unit: 'kPa',
    color: '#ff6b35',
    normalMin: 100,
    normalMax: 103,
    icon: <Gauge size={18} />,
  },
  {
    id: 'current' as const,
    label: 'ELECTRICAL CURRENT',
    sensor: 'ACS712',
    unit: 'A',
    color: '#ffd060',
    normalMin: 1.5,
    normalMax: 2.0,
    icon: <Zap size={18} />,
  },
];

function SensorCard({
  sensor,
  value,
  history,
  analysis,
}: {
  sensor: typeof SENSORS[0];
  value: number | null;
  history: number[];
  analysis: ReturnType<typeof useProcessStore>['analysis'];
}) {
  const { fingerprint } = useProcessStore();
  const fp = fingerprint[sensor.id];

  const min = history.length ? Math.min(...history) : null;
  const max = history.length ? Math.max(...history) : null;
  const avg = history.length ? history.reduce((s, v) => s + v, 0) / history.length : null;
  const deviation = value !== null && fp ? ((value - fp.mean) / fp.mean * 100) : null;

  const chartData = history.slice(-120).map((v, i) => ({ i, value: v }));

  const TrendIcon = deviation === null ? Minus
    : deviation > 1.5 ? TrendingUp
    : deviation < -1.5 ? TrendingDown
    : Minus;
  const trendColor = deviation === null ? 'text-text-muted'
    : Math.abs(deviation) > 3 ? 'text-red'
    : Math.abs(deviation) > 1 ? 'text-yellow'
    : 'text-green';

  return (
    <div className="card space-y-4">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="w-9 h-9 rounded-lg bg-bg-surface flex items-center justify-center" style={{ color: sensor.color }}>
            {sensor.icon}
          </div>
          <div>
            <div className="label-sm">{sensor.label}</div>
            <div className="text-[10px] text-text-muted font-mono">{sensor.sensor}</div>
          </div>
        </div>
        <div className={clsx('flex items-center gap-1', trendColor)}>
          <TrendIcon size={13} />
          <span className="text-[10px] font-mono">{deviation !== null ? `${deviation > 0 ? '+' : ''}${deviation.toFixed(1)}%` : '--'}</span>
        </div>
      </div>

      {/* Main value */}
      <div className="flex items-end gap-3">
        <div className="font-mono font-bold text-5xl" style={{ color: sensor.color }}>
          {value?.toFixed(sensor.id === 'pressure' ? 2 : 1) ?? '--'}
        </div>
        <div className="text-text-muted text-lg mb-1">{sensor.unit}</div>
      </div>

      {/* Stats row */}
      <div className="grid grid-cols-4 gap-2">
        {[
          { label: 'MIN',  val: min?.toFixed(1) ?? '--' },
          { label: 'MAX',  val: max?.toFixed(1) ?? '--' },
          { label: 'AVG',  val: avg?.toFixed(1) ?? '--' },
          { label: 'NORM', val: `${fp?.min}–${fp?.max}` },
        ].map(s => (
          <div key={s.label} className="bg-bg-surface rounded-lg p-2 text-center">
            <div className="label-xs">{s.label}</div>
            <div className="font-mono text-xs font-bold text-text-primary mt-0.5">{s.val}</div>
          </div>
        ))}
      </div>

      {/* Chart */}
      <div>
        <div className="label-xs mb-2">LIVE GRAPH</div>
        <ResponsiveContainer width="100%" height={120}>
          <LineChart data={chartData} margin={{ top: 4, right: 4, bottom: 4, left: 0 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="rgba(0,212,255,0.06)" />
            <XAxis dataKey="i" hide />
            <YAxis hide domain={['auto', 'auto']} />
            <Tooltip
              contentStyle={{ background: '#0a1c30', border: '1px solid rgba(0,212,255,0.2)', borderRadius: 8, fontSize: 11 }}
            />
            <ReferenceLine y={fp?.min} stroke="rgba(0,212,255,0.25)" strokeDasharray="4 4" label={{ value: 'MIN', position: 'right', fill: 'rgba(0,212,255,0.4)', fontSize: 9 }} />
            <ReferenceLine y={fp?.max} stroke="rgba(0,212,255,0.25)" strokeDasharray="4 4" label={{ value: 'MAX', position: 'right', fill: 'rgba(0,212,255,0.4)', fontSize: 9 }} />
            <Line
              type="monotone" dataKey="value" stroke={sensor.color}
              strokeWidth={2} dot={false} activeDot={{ r: 3 }}
              isAnimationActive={false}
            />
          </LineChart>
        </ResponsiveContainer>
      </div>

      {/* Deviation bar */}
      <div>
        <div className="flex items-center justify-between mb-1">
          <span className="label-xs">DEVIATION FROM BASELINE</span>
          <span className={clsx('font-mono text-[10px]', trendColor)}>
            {analysis?.featureDeviations[sensor.id]?.toFixed(2) ?? '0.00'}%
          </span>
        </div>
        <div className="h-1.5 bg-bg-surface rounded-full overflow-hidden">
          <div
            className="h-full rounded-full transition-all duration-500"
            style={{
              width: `${Math.min(100, (analysis?.featureDeviations[sensor.id] ?? 0) * 5)}%`,
              backgroundColor: sensor.color,
            }}
          />
        </div>
      </div>
    </div>
  );
}

export default function LiveSensors() {
  const { readings, latestReading, fingerprint, analysis } = useProcessStore();
  const [timeRange, setTimeRange] = useState<TimeRange>('5min');

  const n = TIME_RANGE_SAMPLES[timeRange];
  const sliced = readings.slice(-n);

  return (
    <div className="p-6 space-y-5 animate-fade-in">

      {/* Time range picker */}
      <div className="flex items-center justify-between">
        <div>
          <div className="label-sm">LIVE SENSOR MONITORING</div>
          <div className="text-xs text-text-muted mt-0.5">DS18B20 · BMP280 · ACS712 — real-time acquisition</div>
        </div>
        <div className="flex items-center gap-1 bg-bg-secondary rounded-lg p-1 border border-border">
          {(['1min', '5min', '15min', '1hr'] as TimeRange[]).map(r => (
            <button
              key={r}
              onClick={() => setTimeRange(r)}
              className={clsx(
                'px-3 py-1.5 rounded-md text-xs font-semibold transition-all',
                timeRange === r ? 'bg-cyan text-bg-primary' : 'text-text-muted hover:text-text-secondary'
              )}
            >
              {r.toUpperCase()}
            </button>
          ))}
        </div>
      </div>

      {/* Sensor Cards */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
        {SENSORS.map(s => (
          <SensorCard
            key={s.id}
            sensor={s}
            value={latestReading?.[s.id] ?? null}
            history={sliced.map(r => r[s.id])}
            analysis={analysis}
          />
        ))}
      </div>

      {/* MPU6500 future sensor placeholder */}
      <div className="card border-dashed border-text-muted/20 opacity-50">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-lg bg-bg-surface flex items-center justify-center text-text-muted">
            <Gauge size={18} />
          </div>
          <div>
            <div className="label-sm text-text-muted">VIBRATION · MPU6500</div>
            <div className="text-[10px] text-text-muted font-mono mt-0.5">
              ⚪ NOT INSTALLED — FUTURE / OPTIONAL SENSOR
            </div>
            <div className="text-[10px] text-text-muted mt-0.5">
              COMING SOON: Vibration Intelligence — X/Y/Z acceleration · RMS · Frequency analysis
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
