import React from 'react';
import { useProcessStore } from '../store/processStore';
import { GaugeChart } from '../components/common/GaugeChart';
import { SensorSparkline } from '../components/common/SensorSparkline';
import {
  LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip,
  ResponsiveContainer, ReferenceLine, Legend,
} from 'recharts';
import { Thermometer, Gauge, Zap, AlertCircle, TrendingUp, Brain, Play } from 'lucide-react';
import clsx from 'clsx';
import type { PageId } from '../types';

const STATUS_LABELS = {
  NORMAL:   { color: 'text-green', bg: 'bg-green/10', border: 'border-green/30', dot: 'bg-green' },
  WARNING:  { color: 'text-yellow', bg: 'bg-yellow/10', border: 'border-yellow/30', dot: 'bg-yellow' },
  CRITICAL: { color: 'text-red',   bg: 'bg-red/10',   border: 'border-red/40',   dot: 'bg-red' },
};

interface OverviewProps {
  onNavigate: (page: PageId) => void;
}

function SensorMiniCard({
  label, value, unit, color, field, deviation,
}: { label: string; value: number | null; unit: string; color: string; field: 'temperature' | 'pressure' | 'current'; deviation?: number }) {
  const { readings } = useProcessStore();
  return (
    <div className="card flex flex-col gap-2">
      <div className="flex items-center justify-between">
        <span className="label-sm">{label}</span>
        {deviation !== undefined && (
          <span className={clsx('font-mono text-[10px]', deviation > 3 ? 'text-red' : deviation > 1 ? 'text-yellow' : 'text-text-muted')}>
            {deviation > 0 ? '+' : ''}{deviation.toFixed(1)}%
          </span>
        )}
      </div>
      <div className="flex items-end gap-2">
        <span className="font-mono font-bold text-2xl" style={{ color }}>{value?.toFixed(1) ?? '--'}</span>
        <span className="text-text-muted text-sm mb-0.5">{unit}</span>
      </div>
      <SensorSparkline data={readings} field={field} color={color} height={56} />
    </div>
  );
}

export default function Overview({ onNavigate }: OverviewProps) {
  const { analysis, latestReading, readings, fingerprint, alerts, isSimulating } = useProcessStore();
  const status = analysis?.status ?? 'NORMAL';
  const sc = STATUS_LABELS[status];
  const unacknowledged = alerts.filter(a => !a.acknowledged);

  const chartData = readings.slice(-60).map((r, i) => ({
    i,
    temperature: r.temperature,
    pressure:    r.pressure,
    current:     r.current,
  }));

  return (
    <div className="p-6 space-y-5 animate-fade-in">

      {/* ── No data notice ─────────────────────────────────────────── */}
      {!isSimulating && !latestReading && (
        <div className="card border-cyan/30 flex items-center gap-4">
          <div className="w-10 h-10 rounded-xl bg-cyan/10 flex items-center justify-center flex-shrink-0">
            <Play size={18} className="text-cyan" />
          </div>
          <div className="flex-1">
            <div className="text-sm font-bold text-cyan mb-0.5">No Data — Start Simulation</div>
            <div className="text-xs text-text-secondary">
              Click <strong>Simulation</strong> in the sidebar and press <strong>START DEMO</strong> to see live AI analysis.
            </div>
          </div>
          <button onClick={() => onNavigate('simulation')} className="btn-primary text-xs py-2 px-4">
            <Play size={13} /> Start Demo
          </button>
        </div>
      )}

      {/* ── Row 1: Process Health Hero + Sensor Cards ─────────────── */}
      <div className="grid grid-cols-1 xl:grid-cols-4 gap-5">

        {/* PROCESS HEALTH HERO */}
        <div className={clsx(
          'card xl:col-span-1 flex flex-col items-center gap-4 py-6',
          sc.bg, sc.border
        )}>
          <div className="label-sm text-center">PROCESS HEALTH</div>

          <GaugeChart
            value={analysis ? 100 - analysis.severityScore : 100}
            size={160}
            label={status}
            sublabel="/ 100"
            status={status}
          />

          <div className={clsx('pill text-sm font-black tracking-widest', {
            'pill-normal':   status === 'NORMAL',
            'pill-warning':  status === 'WARNING',
            'pill-critical': status === 'CRITICAL',
          })}>
            {status === 'NORMAL' ? '🟢' : status === 'WARNING' ? '🟡' : '🔴'} {status}
          </div>

          <div className="w-full space-y-2 mt-1">
            {[
              { label: 'Anomaly Score',  value: analysis?.anomalyScore.toFixed(3) ?? '--', color: 'text-cyan' },
              { label: 'Drift Score',    value: analysis?.driftScore.toFixed(3)   ?? '--', color: 'text-blue' },
              { label: 'Yield Risk',     value: analysis ? `${analysis.yieldRisk}%` : '--', color: status === 'NORMAL' ? 'text-green' : status === 'WARNING' ? 'text-yellow' : 'text-red' },
              { label: 'AI Confidence', value: analysis ? `${analysis.confidence}%` : '--', color: 'text-text-secondary' },
            ].map(m => (
              <div key={m.label} className="flex items-center justify-between px-2">
                <span className="label-xs">{m.label}</span>
                <span className={clsx('font-mono text-xs font-bold', m.color)}>{m.value}</span>
              </div>
            ))}
          </div>
        </div>

        {/* SENSOR MINI CARDS */}
        <div className="xl:col-span-3 grid grid-cols-1 md:grid-cols-3 gap-4">
          <SensorMiniCard
            label="TEMPERATURE · DS18B20"
            field="temperature"
            value={latestReading?.temperature ?? null}
            unit="°C"
            color="#00d4ff"
            deviation={analysis?.featureDeviations.temperature}
          />
          <SensorMiniCard
            label="PRESSURE · BMP280"
            field="pressure"
            value={latestReading?.pressure ?? null}
            unit="kPa"
            color="#ff6b35"
            deviation={analysis?.featureDeviations.pressure}
          />
          <SensorMiniCard
            label="CURRENT · ACS712"
            field="current"
            value={latestReading?.current ?? null}
            unit="A"
            color="#ffd060"
            deviation={analysis?.featureDeviations.current}
          />
        </div>
      </div>

      {/* ── Row 2: Process Signature Chart + Alerts ───────────────── */}
      <div className="grid grid-cols-1 xl:grid-cols-3 gap-5">

        {/* PROCESS SIGNATURE */}
        <div className="card xl:col-span-2">
          <div className="flex items-center justify-between mb-4">
            <div>
              <div className="label-sm">PROCESS SIGNATURE</div>
              <div className="text-xs text-text-muted mt-0.5">Temperature · Pressure · Current — last 60 readings</div>
            </div>
            <button onClick={() => onNavigate('live-sensors')} className="text-[10px] text-cyan hover:underline">
              Full View →
            </button>
          </div>
          <ResponsiveContainer width="100%" height={200}>
            <LineChart data={chartData} margin={{ top: 4, right: 8, bottom: 4, left: 0 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(0,212,255,0.06)" />
              <XAxis dataKey="i" hide />
              <YAxis yAxisId="temp" hide domain={['auto', 'auto']} />
              <YAxis yAxisId="press" hide domain={['auto', 'auto']} />
              <YAxis yAxisId="curr" hide domain={['auto', 'auto']} />
              <Tooltip
                contentStyle={{ background: '#0a1c30', border: '1px solid rgba(0,212,255,0.2)', borderRadius: 8, fontSize: 11 }}
                labelStyle={{ color: '#7aa0c0' }}
              />
              <Legend wrapperStyle={{ fontSize: 11, color: '#7aa0c0' }} />
              <Line yAxisId="temp"  type="monotone" dataKey="temperature" stroke="#00d4ff" strokeWidth={1.5} dot={false} name="Temp °C" isAnimationActive={false} />
              <Line yAxisId="press" type="monotone" dataKey="pressure"    stroke="#ff6b35" strokeWidth={1.5} dot={false} name="Press kPa" isAnimationActive={false} />
              <Line yAxisId="curr"  type="monotone" dataKey="current"     stroke="#ffd060" strokeWidth={1.5} dot={false} name="Current A" isAnimationActive={false} />
              {fingerprint && <ReferenceLine yAxisId="temp" y={fingerprint.temperature.max} stroke="rgba(0,212,255,0.2)" strokeDasharray="4 4" />}
              {fingerprint && <ReferenceLine yAxisId="temp" y={fingerprint.temperature.min} stroke="rgba(0,212,255,0.2)" strokeDasharray="4 4" />}
            </LineChart>
          </ResponsiveContainer>
        </div>

        {/* ALERTS */}
        <div className="card">
          <div className="flex items-center justify-between mb-4">
            <div className="label-sm">PROCESS ALERT CENTER</div>
            <span className="text-[10px] text-text-muted font-mono">{unacknowledged.length} active</span>
          </div>
          {unacknowledged.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-8 text-center">
              <div className="w-10 h-10 rounded-xl bg-green/10 flex items-center justify-center mb-3">
                <span className="text-green text-xl">✓</span>
              </div>
              <div className="text-sm font-semibold text-green">No Active Alerts</div>
              <div className="text-xs text-text-muted mt-1">All parameters within normal envelope</div>
            </div>
          ) : (
            <div className="space-y-2">
              {unacknowledged.slice(0, 4).map(alert => (
                <div key={alert.id} className={clsx(
                  'p-3 rounded-lg border',
                  alert.level === 'CRITICAL' ? 'bg-red/5 border-red/30' : 'bg-yellow/5 border-yellow/30'
                )}>
                  <div className="flex items-center gap-2 mb-1">
                    <AlertCircle size={12} className={alert.level === 'CRITICAL' ? 'text-red' : 'text-yellow'} />
                    <span className={clsx('text-xs font-bold', alert.level === 'CRITICAL' ? 'text-red' : 'text-yellow')}>
                      {alert.level}
                    </span>
                    <span className="text-[9px] text-text-muted font-mono ml-auto">
                      {new Date(alert.timestamp).toLocaleTimeString('en-US', { hour12: false })}
                    </span>
                  </div>
                  <div className="text-xs text-text-primary font-medium">{alert.message}</div>
                  {alert.sensors.length > 0 && (
                    <div className="text-[10px] text-text-muted mt-0.5">{alert.sensors.join(' · ')}</div>
                  )}
                </div>
              ))}
              <button
                onClick={() => onNavigate('drift-monitor')}
                className="text-xs text-cyan hover:underline w-full text-center pt-1"
              >
                View All Alerts →
              </button>
            </div>
          )}
        </div>
      </div>

      {/* ── Row 3: AI Interpretation ──────────────────────────────── */}
      {analysis && (
        <div className="card">
          <div className="flex items-center gap-3 mb-3">
            <Brain size={16} className="text-cyan" />
            <div className="label-sm">AI PROCESS INTERPRETATION</div>
            <span className="font-mono text-[10px] text-text-muted ml-auto">
              Confidence: {analysis.confidence}%
            </span>
          </div>
          <p className="text-sm text-text-secondary leading-relaxed">{analysis.interpretation}</p>
          {analysis.status !== 'NORMAL' && (
            <div className="mt-3 grid grid-cols-3 gap-3">
              {Object.entries(analysis.contributors).map(([sensor, pct]) => (
                <div key={sensor} className="bg-bg-surface rounded-lg p-2 text-center">
                  <div className="font-mono text-sm font-bold text-cyan">{pct}%</div>
                  <div className="label-xs capitalize mt-0.5">{sensor}</div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
}
