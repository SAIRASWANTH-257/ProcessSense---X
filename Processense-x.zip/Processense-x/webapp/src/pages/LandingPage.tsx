import React from 'react';
import { ArrowRight, Play, Zap, Shield, TrendingUp, Eye, Brain, AlertTriangle } from 'lucide-react';
import type { PageId } from '../types';

interface LandingPageProps {
  onEnter: (page: PageId) => void;
}

const PIPELINE_STEPS = [
  { icon: <Eye size={18} />,   label: 'SENSE',   desc: 'Continuous sensor acquisition' },
  { icon: <Brain size={18} />, label: 'LEARN',   desc: 'Build process fingerprint' },
  { icon: <Zap size={18} />,   label: 'DETECT',  desc: 'Real-time anomaly detection' },
  { icon: <TrendingUp size={18} />, label: 'PREDICT', desc: 'Yield-risk estimation' },
  { icon: <Shield size={18} />,label: 'PROTECT', desc: 'Early warning generation' },
];

const FEATURES = [
  { title: 'Edge-AI Processing', desc: 'AI runs on the ESP32 edge node — no cloud latency, real-time response.' },
  { title: 'Process Fingerprinting', desc: 'Learns the normal operating signature of your semiconductor process.' },
  { title: 'Drift Detection', desc: 'Detects micro-deviations before they become yield-impacting failures.' },
  { title: 'Yield-Risk Estimation', desc: 'Quantifies process risk in real-time, enabling proactive intervention.' },
];

export default function LandingPage({ onEnter }: LandingPageProps) {
  return (
    <div className="min-h-screen bg-bg-primary text-text-primary overflow-x-hidden">

      {/* ── Animated Background ──────────────────────────────────────── */}
      <div
        className="fixed inset-0 grid-bg pointer-events-none opacity-100"
        style={{ zIndex: 0 }}
      />
      <div
        className="fixed inset-0 pointer-events-none"
        style={{
          background: 'radial-gradient(ellipse 80% 50% at 50% -20%, rgba(0,212,255,0.08) 0%, transparent 60%)',
          zIndex: 0,
        }}
      />

      <div className="relative z-10">

        {/* ── Top Nav ─────────────────────────────────────────────────── */}
        <nav className="flex items-center justify-between px-8 py-5 border-b border-border backdrop-blur-sm">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-cyan flex items-center justify-center">
              <Zap size={15} className="text-bg-primary" />
            </div>
            <div>
              <span className="text-[11px] font-black tracking-[3px] text-cyan uppercase">ProcessSense</span>
              <span className="text-[11px] font-black tracking-[3px] text-text-muted uppercase"> —X—</span>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <button
              onClick={() => onEnter('simulation')}
              className="btn-outline text-xs py-2 px-4"
            >
              <Play size={13} /> Run AI Simulation
            </button>
            <button
              onClick={() => onEnter('overview')}
              className="btn-primary text-xs py-2 px-4"
            >
              Open Live Monitor <ArrowRight size={13} />
            </button>
          </div>
        </nav>

        {/* ── Hero ────────────────────────────────────────────────────── */}
        <section className="flex flex-col items-center text-center pt-24 pb-20 px-6">
          <div className="pill-active mb-6 text-[10px]">
            <span className="animate-pulse">●</span>
            PROTOTYPE · EDGE-AI · SEMICONDUCTOR PROCESS INTELLIGENCE
          </div>

          <h1
            className="font-black tracking-[-1px] leading-none mb-6"
            style={{ fontSize: 'clamp(3rem, 8vw, 7rem)' }}
          >
            <span className="text-transparent bg-clip-text"
              style={{ backgroundImage: 'linear-gradient(135deg, #00d4ff 0%, #0080ff 50%, #00d4ff 100%)' }}>
              PROCESSSENSE
            </span>
            <span className="text-text-muted">-X</span>
          </h1>

          <p className="text-base font-semibold tracking-[2px] uppercase text-text-secondary mb-4">
            Predictive Edge-AI for Semiconductor Process Intelligence
          </p>

          <blockquote
            className="text-lg italic text-text-secondary max-w-2xl mb-10 leading-relaxed border-l-2 border-cyan pl-4 text-left"
          >
            "Sense the fabrication process, learn its normal fingerprint, detect microscopic drift,
            and estimate potential yield risk before conventional inspection."
          </blockquote>

          <div className="flex items-center gap-4 flex-wrap justify-center">
            <button
              onClick={() => onEnter('overview')}
              className="btn-primary"
            >
              <Eye size={16} /> OPEN LIVE MONITOR
            </button>
            <button
              onClick={() => onEnter('simulation')}
              className="btn-outline"
            >
              <Play size={16} /> RUN AI SIMULATION
            </button>
          </div>

          {/* Sensor badges */}
          <div className="flex items-center gap-3 mt-10 flex-wrap justify-center">
            {['DS18B20 · Temperature', 'BMP280 · Pressure', 'ACS712 · Current'].map(s => (
              <div key={s} className="pill-active text-[10px]">{s}</div>
            ))}
            <div className="text-[10px] text-text-muted border border-border rounded-full px-3 py-1">
              MPU6500 · Vibration ·  COMING SOON
            </div>
          </div>
        </section>

        {/* ── Pipeline ─────────────────────────────────────────────────── */}
        <section className="py-16 px-6 border-t border-border">
          <div className="max-w-5xl mx-auto">
            <div className="label-sm text-center mb-10">Core AI Pipeline</div>
            <div className="flex items-center justify-center gap-2 flex-wrap">
              {PIPELINE_STEPS.map((step, i) => (
                <React.Fragment key={step.label}>
                  <div className="flex flex-col items-center gap-2 w-28">
                    <div className="w-12 h-12 rounded-xl bg-cyan/10 border border-cyan/30 flex items-center justify-center text-cyan">
                      {step.icon}
                    </div>
                    <div className="font-black text-xs tracking-widest text-cyan">{step.label}</div>
                    <div className="text-[10px] text-text-muted text-center">{step.desc}</div>
                  </div>
                  {i < PIPELINE_STEPS.length - 1 && (
                    <ArrowRight size={16} className="text-text-muted flex-shrink-0 mb-6" />
                  )}
                </React.Fragment>
              ))}
            </div>
          </div>
        </section>

        {/* ── Comparison ───────────────────────────────────────────────── */}
        <section className="py-16 px-6 border-t border-border">
          <div className="max-w-5xl mx-auto">
            <div className="label-sm text-center mb-12">Why ProcessSense-X?</div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">

              {/* Conventional */}
              <div className="card opacity-70">
                <div className="label-sm text-text-muted mb-6 text-center">CONVENTIONAL APPROACH</div>
                <div className="flex flex-col items-center gap-3">
                  {['Wafer', 'Inspection', 'Image', 'CNN', 'Defect Detection'].map((step, i) => (
                    <React.Fragment key={step}>
                      <div className="px-6 py-2 rounded-lg border border-text-muted/20 text-text-muted text-sm font-semibold w-48 text-center">
                        {step}
                      </div>
                      {i < 4 && <div className="text-text-muted text-xs">↓</div>}
                    </React.Fragment>
                  ))}
                  <div className="mt-4 text-xs text-text-muted italic text-center">
                    Detects defects <em>after</em> they occur
                  </div>
                </div>
              </div>

              {/* ProcessSense-X */}
              <div className="card border-cyan/30" style={{ boxShadow: '0 0 30px rgba(0,212,255,0.05)' }}>
                <div className="label-sm text-cyan mb-6 text-center">PROCESSSENSE-X</div>
                <div className="flex flex-col items-center gap-3">
                  {['Process', 'Sensor Fingerprint', 'Edge AI', 'Drift Detection', 'Risk Prediction', 'Early Intervention'].map((step, i) => (
                    <React.Fragment key={step}>
                      <div className="px-6 py-2 rounded-lg border border-cyan/30 bg-cyan/5 text-cyan text-sm font-semibold w-48 text-center">
                        {step}
                      </div>
                      {i < 5 && <div className="text-cyan text-xs">↓</div>}
                    </React.Fragment>
                  ))}
                  <div className="mt-4 text-xs text-cyan italic text-center font-semibold">
                    Intervenes <em>before</em> the defect is created
                  </div>
                </div>
              </div>
            </div>

            <blockquote className="mt-12 text-center text-lg italic text-cyan font-medium max-w-2xl mx-auto">
              "Don't just detect the defect. Detect the process drift that can create the defect."
            </blockquote>
          </div>
        </section>

        {/* ── Features ─────────────────────────────────────────────────── */}
        <section className="py-16 px-6 border-t border-border">
          <div className="max-w-5xl mx-auto">
            <div className="label-sm text-center mb-10">Key Capabilities</div>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              {FEATURES.map(f => (
                <div key={f.title} className="card">
                  <div className="text-sm font-bold text-cyan mb-2">{f.title}</div>
                  <div className="text-xs text-text-secondary leading-relaxed">{f.desc}</div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* ── CTA ──────────────────────────────────────────────────────── */}
        <section className="py-20 px-6 border-t border-border text-center">
          <div className="max-w-xl mx-auto">
            <AlertTriangle size={32} className="text-yellow mx-auto mb-4" />
            <div className="label-sm mb-4">AI ESTIMATE · PROTOTYPE</div>
            <p className="text-text-muted text-sm mb-8 leading-relaxed">
              ProcessSense-X is a prototype demonstrating the concept of Edge-AI process intelligence
              for semiconductor fabrication. Yield-risk estimates are heuristic models, not production-validated predictions.
            </p>
            <button onClick={() => onEnter('overview')} className="btn-primary">
              OPEN PROCESS INTELLIGENCE CENTER <ArrowRight size={16} />
            </button>
          </div>
        </section>

        {/* Footer */}
        <footer className="py-6 px-8 border-t border-border text-center">
          <div className="text-[10px] text-text-muted font-mono">
            ProcessSense-X v1.0 · Edge-AI for Semiconductor Process Intelligence · Prototype
          </div>
        </footer>
      </div>
    </div>
  );
}
