import React from 'react';
import { useProcessStore } from '../store/processStore';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { Shield, AlertTriangle, TrendingUp } from 'lucide-react';
import clsx from 'clsx';

export default function YieldRisk() {
  const { analysis, driftEvents } = useProcessStore();

  const riskHistory = driftEvents.slice(-60).reverse().map((e, i) => ({
    i,
    risk: Math.round(e.anomalyScore * 35 + e.driftScore * 25),
  }));

  const yieldRisk = analysis?.yieldRisk ?? 0;
  const confidence = analysis?.confidence ?? 0;
  const status = analysis?.status ?? 'NORMAL';

  const riskColor = status === 'CRITICAL' ? '#ff3860' : status === 'WARNING' ? '#ffd060' : '#00ff88';

  return (
    <div className="p-6 space-y-5 animate-fade-in">

      {/* Header */}
      <div>
        <div className="label-sm">PREDICTIVE YIELD PROTECTION</div>
        <div className="text-xs text-text-muted mt-0.5">
          AI ESTIMATE · PROTOTYPE — Heuristic model, not production-validated
        </div>
      </div>

      {/* Hero risk number */}
      <div className="grid grid-cols-1 xl:grid-cols-3 gap-5">

        <div className={clsx(
          'card xl:col-span-1 flex flex-col items-center justify-center py-10 text-center',
          status === 'CRITICAL' ? 'border-red/40 bg-red/5' :
          status === 'WARNING'  ? 'border-yellow/30 bg-yellow/5' :
                                  'border-green/30 bg-green/5'
        )}>
          <div className="label-sm mb-4">ESTIMATED YIELD RISK</div>
          <div
            className="font-mono font-black leading-none mb-2"
            style={{ fontSize: 80, color: riskColor, textShadow: `0 0 40px ${riskColor}50` }}
          >
            {yieldRisk.toFixed(1)}
          </div>
          <div className="text-lg font-semibold text-text-muted">%</div>
          <div className="mt-4 flex items-center gap-2">
            <div className={clsx('pill', {
              'pill-normal':   status === 'NORMAL',
              'pill-warning':  status === 'WARNING',
              'pill-critical': status === 'CRITICAL',
            })}>
              {status === 'NORMAL' ? '🟢' : status === 'WARNING' ? '🟡' : '🔴'} {status}
            </div>
          </div>
          <div className="mt-4 text-xs text-text-muted">AI Confidence: {confidence}%</div>
          <div className="mt-2 px-4">
            <div className="h-1.5 bg-bg-surface rounded-full overflow-hidden">
              <div className="h-full bg-cyan rounded-full" style={{ width: `${confidence}%` }} />
            </div>
          </div>
          <div className="mt-6 px-4 py-3 bg-bg-surface rounded-lg w-full">
            <div className="label-xs text-yellow mb-1">AI ESTIMATE · PROTOTYPE</div>
            <div className="text-[10px] text-text-muted text-center leading-relaxed">
              Yield-risk estimates are heuristic prototype models. Not production-validated for semiconductor fab use.
            </div>
          </div>
        </div>

        {/* Risk breakdown + trend */}
        <div className="xl:col-span-2 space-y-4">

          {/* Contributing factors */}
          <div className="card">
            <div className="label-sm mb-4">CONTRIBUTING RISK FACTORS</div>
            {analysis && analysis.status !== 'NORMAL' ? (
              <div className="space-y-3">
                {[
                  { label: 'Temperature Drift',     pct: analysis.contributors.temperature, color: '#00d4ff', desc: `${analysis.featureDeviations.temperature.toFixed(1)}% deviation from baseline` },
                  { label: 'Current Instability',   pct: analysis.contributors.current,     color: '#ffd060', desc: `${analysis.featureDeviations.current.toFixed(1)}% deviation from baseline` },
                  { label: 'Pressure Variation',    pct: analysis.contributors.pressure,    color: '#ff6b35', desc: `${analysis.featureDeviations.pressure.toFixed(1)}% deviation from baseline` },
                ].map(f => (
                  <div key={f.label}>
                    <div className="flex items-center justify-between mb-1.5">
                      <span className="text-sm font-medium" style={{ color: f.color }}>{f.label}</span>
                      <span className="font-mono text-xs font-bold text-text-primary">{f.pct}%</span>
                    </div>
                    <div className="h-2 bg-bg-surface rounded-full overflow-hidden">
                      <div className="h-full rounded-full" style={{ width: `${f.pct}%`, backgroundColor: f.color, opacity: 0.75 }} />
                    </div>
                    <div className="text-[10px] text-text-muted mt-1">{f.desc}</div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="flex flex-col items-center py-8 text-center">
                <Shield size={32} className="text-green mb-3" />
                <div className="text-sm font-bold text-green">Low Risk — Process Stable</div>
                <div className="text-xs text-text-muted mt-1">No significant contributing factors detected</div>
              </div>
            )}
          </div>

          {/* Metrics row */}
          <div className="grid grid-cols-3 gap-3">
            {[
              { label: 'Severity Score', value: `${analysis?.severityScore ?? 0} / 100`, color: riskColor },
              { label: 'Anomaly Score',  value: analysis?.anomalyScore.toFixed(3) ?? '--', color: '#00d4ff' },
              { label: 'Drift Score',    value: analysis?.driftScore.toFixed(3) ?? '--',   color: '#b060ff' },
            ].map(m => (
              <div key={m.label} className="card text-center py-4">
                <div className="label-xs mb-2">{m.label}</div>
                <div className="font-mono font-bold text-lg" style={{ color: m.color }}>{m.value}</div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Risk trend chart */}
      <div className="card">
        <div className="label-sm mb-4">YIELD-RISK TREND</div>
        <ResponsiveContainer width="100%" height={160}>
          <AreaChart data={riskHistory} margin={{ top: 4, right: 8, bottom: 4, left: 0 }}>
            <defs>
              <linearGradient id="riskGrad" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%"  stopColor={riskColor} stopOpacity={0.3} />
                <stop offset="95%" stopColor={riskColor} stopOpacity={0} />
              </linearGradient>
            </defs>
            <CartesianGrid strokeDasharray="3 3" stroke="rgba(0,212,255,0.06)" />
            <XAxis dataKey="i" hide />
            <YAxis domain={[0, 100]} tick={{ fill: '#3a5a78', fontSize: 9 }} />
            <Tooltip contentStyle={{ background: '#0a1c30', border: '1px solid rgba(0,212,255,0.2)', borderRadius: 8, fontSize: 11 }} />
            <Area type="monotone" dataKey="risk" stroke={riskColor} fill="url(#riskGrad)" strokeWidth={2} isAnimationActive={false} name="Risk %" />
          </AreaChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}
