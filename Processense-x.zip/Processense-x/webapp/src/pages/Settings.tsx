import React, { useState } from 'react';
import { useProcessStore } from '../store/processStore';
import { Save, Wifi } from 'lucide-react';
import { DEFAULT_FINGERPRINT } from '../types';
import clsx from 'clsx';

export default function Settings() {
  const { wsUrl, setWsUrl, fingerprint, learnFingerprint, readings, resetHistory } = useProcessStore();
  const [localUrl, setLocalUrl] = useState(wsUrl);
  const [saved, setSaved] = useState(false);

  function save() {
    setWsUrl(localUrl);
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  }

  return (
    <div className="p-6 space-y-5 animate-fade-in max-w-2xl">
      <div>
        <div className="label-sm">SYSTEM SETTINGS</div>
        <div className="text-xs text-text-muted mt-0.5">ProcessSense-X configuration</div>
      </div>

      {/* Connection */}
      <div className="card">
        <div className="flex items-center gap-2 mb-4">
          <Wifi size={14} className="text-cyan" />
          <div className="label-sm">ESP32 DEVICE CONNECTION</div>
        </div>
        <div className="space-y-3">
          <div>
            <label className="label-xs block mb-1.5">WebSocket URL</label>
            <input
              type="text" value={localUrl}
              onChange={e => setLocalUrl(e.target.value)}
              className="w-full bg-bg-surface border border-border rounded-lg px-3 py-2 font-mono text-sm text-text-primary focus:outline-none focus:border-border-active transition-colors"
              placeholder="ws://192.168.x.x:81/"
            />
            <div className="text-[10px] text-text-muted mt-1">
              Connect to your ESP32 WebSocket server. The ESP32 sends JSON packets containing temperature, pressure, and current readings.
            </div>
          </div>
          <div>
            <label className="label-xs block mb-1.5">Expected JSON format from ESP32</label>
            <pre className="bg-bg-surface border border-border rounded-lg px-3 py-2.5 text-[10px] font-mono text-cyan overflow-auto">
{`{
  "device_id": "ESP32-PSX-001",
  "timestamp": 1727000000,
  "temperature": 72.4,
  "pressure": 101.32,
  "current": 1.84
}`}
            </pre>
          </div>
          <button onClick={save} className={clsx('btn-primary text-xs py-2 px-4', saved && 'opacity-60')}>
            <Save size={13} /> {saved ? 'Saved!' : 'Save Settings'}
          </button>
        </div>
      </div>

      {/* Normal Fingerprint */}
      <div className="card">
        <div className="label-sm mb-4">PROCESS FINGERPRINT</div>
        <div className="space-y-3">
          <div className="grid grid-cols-3 gap-3">
            {[
              { label: 'TEMPERATURE (DS18B20)', unit: '°C',  fp: fingerprint.temperature },
              { label: 'PRESSURE (BMP280)',     unit: 'kPa', fp: fingerprint.pressure },
              { label: 'CURRENT (ACS712)',      unit: 'A',   fp: fingerprint.current },
            ].map(s => (
              <div key={s.label} className="bg-bg-surface rounded-lg p-3">
                <div className="label-xs mb-2">{s.label}</div>
                <div className="space-y-1 font-mono text-[10px]">
                  <div className="flex justify-between"><span className="text-text-muted">Normal:</span><span className="text-cyan">{s.fp.min}–{s.fp.max} {s.unit}</span></div>
                  <div className="flex justify-between"><span className="text-text-muted">Mean:</span><span className="text-text-primary">{s.fp.mean.toFixed(2)}</span></div>
                  <div className="flex justify-between"><span className="text-text-muted">σ:</span><span className="text-text-primary">{s.fp.std.toFixed(3)}</span></div>
                </div>
              </div>
            ))}
          </div>
          <div className="flex items-center gap-3">
            <button
              onClick={learnFingerprint}
              disabled={readings.length < 20}
              className={clsx('btn-outline text-xs py-2 px-4', readings.length < 20 && 'opacity-40 cursor-not-allowed')}
            >
              Re-learn from Current Data {readings.length < 20 ? `(need ${20 - readings.length} more)` : ''}
            </button>
          </div>
          <div className="text-[10px] text-text-muted">
            Fingerprint was learned from {fingerprint.sampleCount} samples at {new Date(fingerprint.learnedAt).toLocaleTimeString()}.
          </div>
        </div>
      </div>

      {/* Data management */}
      <div className="card">
        <div className="label-sm mb-4">DATA MANAGEMENT</div>
        <div className="flex items-center gap-3">
          <button onClick={resetHistory} className="btn-danger text-xs py-2 px-4">
            Clear All Data
          </button>
          <span className="text-xs text-text-muted">{readings.length} readings in buffer</span>
        </div>
      </div>

      {/* About */}
      <div className="card">
        <div className="label-sm mb-3">ABOUT PROCESSSENSE-X</div>
        <div className="space-y-1 text-[10px] text-text-muted font-mono">
          <div>Version: v1.0.0</div>
          <div>Platform: Edge-AI · ESP32 DevKit</div>
          <div>Sensors: DS18B20 · BMP280 · ACS712</div>
          <div>Future: MPU6500 Vibration Intelligence</div>
          <div className="mt-2 text-text-muted/60">
            AI ESTIMATE · PROTOTYPE — Yield-risk predictions are heuristic models, not production-validated for semiconductor fab use.
          </div>
        </div>
      </div>
    </div>
  );
}
