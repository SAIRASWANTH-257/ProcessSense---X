import React from 'react';
import { useProcessStore } from '../store/processStore';
import { Wifi, Cpu, HardDrive, Clock, Signal, Radio, Zap } from 'lucide-react';
import clsx from 'clsx';
import type { SensorStatus } from '../types';

const SENSOR_STATUS_MAP: Record<SensorStatus, { label: string; color: string; dot: string }> = {
  ONLINE:        { label: '🟢 ONLINE',         color: 'text-green',       dot: 'bg-green' },
  OFFLINE:       { label: '🔴 OFFLINE',         color: 'text-red',         dot: 'bg-red' },
  ERROR:         { label: '🟠 ERROR',           color: 'text-yellow',      dot: 'bg-yellow' },
  NOT_INSTALLED: { label: '⚪ NOT INSTALLED',   color: 'text-text-muted',  dot: 'bg-text-muted' },
};

function formatUptime(sec: number): string {
  const h = Math.floor(sec / 3600);
  const m = Math.floor((sec % 3600) / 60);
  const s = sec % 60;
  return `${String(h).padStart(2,'0')}h ${String(m).padStart(2,'0')}m ${String(s).padStart(2,'0')}s`;
}

function MetricBar({ label, value, color = '#00d4ff' }: { label: string; value: number; color?: string }) {
  return (
    <div>
      <div className="flex items-center justify-between mb-1">
        <span className="label-xs">{label}</span>
        <span className="font-mono text-xs font-bold text-text-primary">{value}%</span>
      </div>
      <div className="h-1.5 bg-bg-surface rounded-full overflow-hidden">
        <div className="h-full rounded-full transition-all duration-500"
          style={{ width: `${value}%`, backgroundColor: color }} />
      </div>
    </div>
  );
}

export default function DeviceHealth() {
  const { deviceHealth } = useProcessStore();
  const dh = deviceHealth;

  return (
    <div className="p-6 space-y-5 animate-fade-in">

      {/* Header */}
      <div>
        <div className="label-sm">EDGE DEVICE HEALTH</div>
        <div className="text-xs text-text-muted mt-0.5">ESP32 DevKit — ProcessSense-X Sensor Node</div>
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-3 gap-5">

        {/* Device Identity Card */}
        <div className={clsx(
          'card flex flex-col items-center py-8 text-center',
          dh.online ? 'border-green/30' : 'border-text-muted/20'
        )}>
          <div className={clsx(
            'w-16 h-16 rounded-2xl flex items-center justify-center mb-4',
            dh.online ? 'bg-green/10' : 'bg-text-muted/10'
          )}>
            <Cpu size={28} className={dh.online ? 'text-green' : 'text-text-muted'} />
          </div>
          <div className="font-mono font-bold text-lg text-text-primary">{dh.deviceId}</div>
          <div className={clsx('pill mt-3', dh.online ? 'pill-normal' : 'pill-offline')}>
            {dh.online ? '🟢 EDGE DEVICE ONLINE' : '⚫ OFFLINE'}
          </div>
          <div className="mt-6 w-full space-y-2 text-left px-4">
            {[
              { label: 'Firmware',   value: dh.firmwareVersion, icon: <Zap size={11} /> },
              { label: 'Uptime',     value: formatUptime(dh.uptimeSeconds), icon: <Clock size={11} /> },
              { label: 'Packet Rate', value: `${dh.packetRate.toFixed(1)} Hz`, icon: <Radio size={11} /> },
            ].map(item => (
              <div key={item.label} className="flex items-center justify-between">
                <div className="flex items-center gap-1.5 text-text-muted">
                  {item.icon}
                  <span className="label-xs">{item.label}</span>
                </div>
                <span className="font-mono text-xs text-text-primary">{item.value}</span>
              </div>
            ))}
          </div>
        </div>

        {/* System metrics */}
        <div className="space-y-4">
          <div className="card">
            <div className="label-sm mb-4">SYSTEM METRICS</div>
            <div className="space-y-3">
              <MetricBar label="CPU USAGE" value={dh.cpuUsage} color="#00d4ff" />
              <MetricBar label="MEMORY USAGE" value={dh.memoryUsage} color="#b060ff" />
            </div>
          </div>

          <div className="card">
            <div className="label-sm mb-4">NETWORK STATUS</div>
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2 text-text-muted">
                  <Wifi size={13} />
                  <span className="label-xs">Wi-Fi</span>
                </div>
                <span className={clsx('text-xs font-bold', dh.wifiConnected ? 'text-green' : 'text-red')}>
                  {dh.wifiConnected ? 'CONNECTED' : 'DISCONNECTED'}
                </span>
              </div>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2 text-text-muted">
                  <Signal size={13} />
                  <span className="label-xs">RSSI</span>
                </div>
                <span className="font-mono text-xs text-cyan">{dh.rssi} dBm</span>
              </div>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2 text-text-muted">
                  <Clock size={13} />
                  <span className="label-xs">Last Seen</span>
                </div>
                <span className="font-mono text-xs text-text-secondary">
                  {new Date(dh.lastCommunication).toLocaleTimeString('en-US', { hour12: false })}
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Sensor connectivity */}
        <div className="card">
          <div className="label-sm mb-4">SENSOR STATUS</div>
          <div className="space-y-3">
            {[
              { name: 'DS18B20', label: 'Temperature Sensor',       status: dh.sensors.ds18b20 },
              { name: 'BMP280',  label: 'Pressure / Temp Sensor',   status: dh.sensors.bmp280  },
              { name: 'ACS712',  label: 'Current Sensor',           status: dh.sensors.acs712  },
            ].map(s => {
              const cfg = SENSOR_STATUS_MAP[s.status];
              return (
                <div key={s.name} className="flex items-center justify-between p-3 bg-bg-surface rounded-lg">
                  <div>
                    <div className="text-sm font-bold text-text-primary">{s.name}</div>
                    <div className="text-[10px] text-text-muted">{s.label}</div>
                  </div>
                  <span className={clsx('text-xs font-bold', cfg.color)}>{cfg.label}</span>
                </div>
              );
            })}

            {/* MPU6500 — FUTURE */}
            <div className="flex items-center justify-between p-3 bg-bg-surface rounded-lg border border-dashed border-text-muted/20 opacity-50">
              <div>
                <div className="text-sm font-bold text-text-muted">MPU6500</div>
                <div className="text-[10px] text-text-muted">Vibration / IMU Sensor</div>
                <div className="text-[9px] text-text-muted mt-0.5">FUTURE / OPTIONAL SENSOR</div>
              </div>
              <span className="text-xs font-bold text-text-muted">⚪ NOT INSTALLED</span>
            </div>
          </div>

          {/* Coming soon notice */}
          <div className="mt-4 p-3 bg-bg-surface rounded-lg border border-dashed border-cyan/20">
            <div className="text-[10px] text-cyan font-semibold mb-1">COMING SOON</div>
            <div className="text-[10px] text-text-muted">
              VIBRATION INTELLIGENCE — MPU6500 accelerometer support for process vibration analysis,
              RMS computation, and frequency domain monitoring.
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
