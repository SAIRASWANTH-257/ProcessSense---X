import React from 'react';
import {
  LayoutDashboard, Activity, Cpu, Fingerprint,
  TrendingUp, AlertTriangle, Heart, Database,
  Play, Settings, ChevronRight, Zap,
} from 'lucide-react';
import type { PageId } from '../../types';
import { useProcessStore } from '../../store/processStore';
import clsx from 'clsx';

interface NavItem {
  id: PageId;
  label: string;
  icon: React.ReactNode;
  badge?: string;
}

const NAV_ITEMS: NavItem[] = [
  { id: 'overview',      label: 'Overview',           icon: <LayoutDashboard size={16} /> },
  { id: 'live-sensors',  label: 'Live Sensors',        icon: <Activity size={16} /> },
  { id: 'ai-analysis',   label: 'AI Analysis',         icon: <Cpu size={16} /> },
  { id: 'fingerprint',   label: 'Process Fingerprint', icon: <Fingerprint size={16} /> },
  { id: 'drift-monitor', label: 'Drift Monitor',       icon: <TrendingUp size={16} /> },
  { id: 'yield-risk',    label: 'Yield Risk',          icon: <AlertTriangle size={16} /> },
  { id: 'device-health', label: 'Device Health',       icon: <Heart size={16} /> },
  { id: 'data-explorer', label: 'Data Explorer',       icon: <Database size={16} /> },
  { id: 'simulation',    label: 'Simulation',          icon: <Play size={16} /> },
  { id: 'settings',      label: 'Settings',            icon: <Settings size={16} /> },
];

interface SidebarProps {
  activePage: PageId;
  onNavigate: (page: PageId) => void;
  collapsed?: boolean;
}

export function Sidebar({ activePage, onNavigate, collapsed = false }: SidebarProps) {
  const { isSimulating, alerts, analysis } = useProcessStore();
  const unresolvedAlerts = alerts.filter(a => !a.acknowledged).length;

  return (
    <aside
      className={clsx(
        'h-screen flex flex-col bg-bg-secondary border-r border-border transition-all duration-300 flex-shrink-0',
        collapsed ? 'w-16' : 'w-60'
      )}
    >
      {/* Logo */}
      <div className="flex items-center gap-3 px-4 py-5 border-b border-border">
        <div className="relative flex-shrink-0">
          <div className="w-8 h-8 rounded-lg bg-cyan flex items-center justify-center">
            <Zap size={16} className="text-bg-primary" />
          </div>
          {isSimulating && (
            <span className="absolute -top-1 -right-1 w-2.5 h-2.5 rounded-full bg-green border-2 border-bg-secondary animate-pulse" />
          )}
        </div>
        {!collapsed && (
          <div>
            <div className="text-xs font-bold tracking-widest text-cyan uppercase">ProcessSense</div>
            <div className="text-[9px] font-semibold tracking-[2px] text-text-muted uppercase">— X —</div>
          </div>
        )}
      </div>

      {/* Status strip */}
      {!collapsed && (
        <div className="px-4 py-2.5 border-b border-border">
          <div className="flex items-center justify-between">
            <span className="label-xs">AI Engine</span>
            <span className={clsx(
              'text-[10px] font-bold tracking-wide',
              isSimulating ? 'text-cyan' : 'text-text-muted'
            )}>
              {isSimulating ? '● ACTIVE' : '○ STANDBY'}
            </span>
          </div>
          {analysis && (
            <div className="flex items-center justify-between mt-1">
              <span className="label-xs">Severity</span>
              <span className={clsx('text-[10px] font-mono font-bold', {
                'text-green':  analysis.status === 'NORMAL',
                'text-yellow': analysis.status === 'WARNING',
                'text-red':    analysis.status === 'CRITICAL',
              })}>
                {analysis.severityScore} / 100
              </span>
            </div>
          )}
        </div>
      )}

      {/* Navigation */}
      <nav className="flex-1 px-2 py-3 space-y-0.5 overflow-y-auto">
        {NAV_ITEMS.map(item => {
          const isActive = activePage === item.id;
          const hasBadge =
            (item.id === 'drift-monitor' || item.id === 'yield-risk') && unresolvedAlerts > 0;

          return (
            <button
              key={item.id}
              onClick={() => onNavigate(item.id)}
              className={clsx('nav-item', { active: isActive })}
              title={collapsed ? item.label : undefined}
            >
              <span className={clsx('flex-shrink-0', isActive ? 'text-cyan' : '')}>
                {item.icon}
              </span>
              {!collapsed && (
                <>
                  <span className="flex-1 text-left">{item.label}</span>
                  {hasBadge && (
                    <span className="w-4 h-4 rounded-full bg-red text-bg-primary text-[9px] font-bold flex items-center justify-center">
                      {unresolvedAlerts}
                    </span>
                  )}
                  {isActive && <ChevronRight size={12} className="text-cyan opacity-60" />}
                </>
              )}
            </button>
          );
        })}
      </nav>

      {/* Footer */}
      {!collapsed && (
        <div className="px-4 py-3 border-t border-border">
          <div className="text-[9px] text-text-muted font-mono text-center">
            ProcessSense-X v1.0 · Edge-AI Platform
          </div>
        </div>
      )}
    </aside>
  );
}
