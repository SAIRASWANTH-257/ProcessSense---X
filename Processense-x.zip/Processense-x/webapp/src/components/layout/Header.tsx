import React from 'react';
import { Wifi, WifiOff, Bell, RefreshCw, Clock, Signal } from 'lucide-react';
import { useProcessStore } from '../../store/processStore';
import clsx from 'clsx';
import type { PageId } from '../../types';

const PAGE_TITLES: Record<PageId, string> = {
  'overview':      'Process Intelligence Center',
  'live-sensors':  'Live Sensor Monitoring',
  'ai-analysis':   'ProcessSense-X AI Engine',
  'fingerprint':   'Normal Process Fingerprint',
  'drift-monitor': 'Anomaly & Drift Monitor',
  'yield-risk':    'Predictive Yield Protection',
  'device-health': 'Edge Device Health',
  'data-explorer': 'Process Data Explorer',
  'simulation':    'Demo Simulation',
  'settings':      'System Settings',
};

interface HeaderProps {
  activePage: PageId;
}

function formatUptime(seconds: number): string {
  const h = Math.floor(seconds / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  const s = seconds % 60;
  if (h > 0) return `${h}h ${m}m`;
  if (m > 0) return `${m}m ${s}s`;
  return `${s}s`;
}

export function Header({ activePage }: HeaderProps) {
  const { isConnected, isSimulating, deviceHealth, analysis, alerts } = useProcessStore();
  const unacknowledged = alerts.filter(a => !a.acknowledged).length;
  const connected = isConnected || isSimulating;
  const now = new Date().toLocaleTimeString('en-US', { hour12: false });

  return (
    <header className="h-14 flex items-center justify-between px-6 bg-bg-secondary border-b border-border flex-shrink-0">
      {/* Left — page title */}
      <div>
        <h2 className="text-sm font-bold text-text-primary tracking-wide">
          {PAGE_TITLES[activePage]}
        </h2>
        <div className="flex items-center gap-3 mt-0.5">
          <span className="label-xs">ProcessSense-X</span>
          <span className="text-text-muted">·</span>
          <span className="label-xs">Semiconductor Process Intelligence</span>
        </div>
      </div>

      {/* Right — status cluster */}
      <div className="flex items-center gap-4">
        {/* Last update */}
        <div className="hidden md:flex items-center gap-1.5 text-text-muted">
          <Clock size={11} />
          <span className="font-mono text-[10px]">Last update: {now}</span>
        </div>

        {/* Uptime */}
        {connected && (
          <div className="hidden md:flex items-center gap-1.5 text-text-muted">
            <RefreshCw size={11} />
            <span className="font-mono text-[10px]">
              UP {formatUptime(deviceHealth.uptimeSeconds)}
            </span>
          </div>
        )}

        {/* Signal quality */}
        {connected && (
          <div className="hidden lg:flex items-center gap-1.5">
            <Signal size={11} className="text-cyan" />
            <span className="font-mono text-[10px] text-cyan">{deviceHealth.rssi} dBm</span>
          </div>
        )}

        {/* Alerts bell */}
        <button className="relative p-1.5 rounded-lg hover:bg-bg-hover transition-colors">
          <Bell size={15} className={unacknowledged > 0 ? 'text-yellow' : 'text-text-muted'} />
          {unacknowledged > 0 && (
            <span className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-red text-[9px] font-bold text-bg-primary flex items-center justify-center">
              {unacknowledged}
            </span>
          )}
        </button>

        {/* Device status */}
        <div className={clsx(
          'flex items-center gap-2 px-3 py-1.5 rounded-lg border text-xs font-semibold',
          connected
            ? 'bg-green/10 border-green/30 text-green'
            : 'bg-text-muted/10 border-text-muted/20 text-text-muted'
        )}>
          {connected ? <Wifi size={13} /> : <WifiOff size={13} />}
          <div>
            <div className="text-[10px] font-mono">{deviceHealth.deviceId}</div>
            <div className="text-[9px] font-bold tracking-wide uppercase">
              {connected ? '🟢 EDGE DEVICE ONLINE' : '⚫ OFFLINE'}
            </div>
          </div>
        </div>

        {/* AI status */}
        {analysis && (
          <div className={clsx(
            'hidden xl:flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg border text-[10px] font-bold tracking-wide',
            {
              'bg-green/10 border-green/30 text-green':   analysis.status === 'NORMAL',
              'bg-yellow/10 border-yellow/30 text-yellow': analysis.status === 'WARNING',
              'bg-red/10 border-red/40 text-red':          analysis.status === 'CRITICAL',
            }
          )}>
            <span className="animate-pulse">●</span>
            AI: {analysis.status}
          </div>
        )}
      </div>
    </header>
  );
}
