import React from 'react';
import clsx from 'clsx';

interface GaugeChartProps {
  value: number;     // 0–100
  size?: number;     // px
  label?: string;
  sublabel?: string;
  status?: 'NORMAL' | 'WARNING' | 'CRITICAL';
  showValue?: boolean;
}

const STATUS_COLORS = {
  NORMAL:   { stroke: '#00ff88', glow: 'rgba(0,255,136,0.4)', text: '#00ff88' },
  WARNING:  { stroke: '#ffd060', glow: 'rgba(255,208,96,0.4)', text: '#ffd060' },
  CRITICAL: { stroke: '#ff3860', glow: 'rgba(255,56,96,0.4)',  text: '#ff3860' },
};

export function GaugeChart({
  value,
  size = 180,
  label,
  sublabel,
  status = 'NORMAL',
  showValue = true,
}: GaugeChartProps) {
  const colors = STATUS_COLORS[status];
  const cx = size / 2;
  const cy = size / 2;
  const r = (size / 2) - 16;
  const strokeWidth = 10;
  const dashArray = 2 * Math.PI * r;
  // Gauge is a 270° arc (starts at -225° / bottom-left, sweeps clockwise)
  const arcLength = dashArray * 0.75;
  const filled = arcLength * (Math.min(100, Math.max(0, value)) / 100);
  const gap = dashArray - arcLength;

  return (
    <div className="relative flex items-center justify-center" style={{ width: size, height: size }}>
      <svg width={size} height={size} style={{ transform: 'rotate(-225deg)' }}>
        {/* Background track */}
        <circle
          cx={cx} cy={cy} r={r}
          fill="none"
          stroke="rgba(0,212,255,0.08)"
          strokeWidth={strokeWidth}
          strokeLinecap="round"
          strokeDasharray={`${arcLength} ${gap + 0.01}`}
        />
        {/* Value arc */}
        <circle
          cx={cx} cy={cy} r={r}
          fill="none"
          stroke={colors.stroke}
          strokeWidth={strokeWidth}
          strokeLinecap="round"
          strokeDasharray={`${filled} ${dashArray}`}
          style={{
            filter: `drop-shadow(0 0 6px ${colors.glow})`,
            transition: 'stroke-dasharray 0.6s ease',
          }}
        />
      </svg>

      {/* Center content */}
      <div className="absolute inset-0 flex flex-col items-center justify-center">
        {showValue && (
          <div
            className="font-mono font-bold leading-none"
            style={{
              fontSize: size * 0.22,
              color: colors.text,
              textShadow: `0 0 20px ${colors.glow}`,
            }}
          >
            {Math.round(value)}
          </div>
        )}
        {label && (
          <div
            className="font-semibold tracking-widest uppercase text-center mt-1"
            style={{ fontSize: size * 0.065, color: colors.text, opacity: 0.8 }}
          >
            {label}
          </div>
        )}
        {sublabel && (
          <div
            className="text-text-muted text-center font-mono mt-0.5"
            style={{ fontSize: size * 0.055 }}
          >
            {sublabel}
          </div>
        )}
      </div>
    </div>
  );
}

// ── Mini arc for small displays ────────────────────────────────────
interface MiniGaugeProps {
  value: number;   // 0–100
  color?: string;
  size?: number;
}

export function MiniGauge({ value, color = '#00d4ff', size = 60 }: MiniGaugeProps) {
  const cx = size / 2, cy = size / 2, r = size / 2 - 6;
  const dashArray = 2 * Math.PI * r;
  const arcLength = dashArray * 0.75;
  const filled = arcLength * (Math.min(100, Math.max(0, value)) / 100);
  return (
    <svg width={size} height={size} style={{ transform: 'rotate(-225deg)' }}>
      <circle cx={cx} cy={cy} r={r} fill="none" stroke="rgba(0,212,255,0.08)"
        strokeWidth={5} strokeLinecap="round" strokeDasharray={`${arcLength} ${dashArray}`} />
      <circle cx={cx} cy={cy} r={r} fill="none" stroke={color}
        strokeWidth={5} strokeLinecap="round" strokeDasharray={`${filled} ${dashArray}`}
        style={{ transition: 'stroke-dasharray 0.5s ease' }} />
    </svg>
  );
}
