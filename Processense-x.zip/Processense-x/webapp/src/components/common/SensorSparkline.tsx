import React from 'react';
import { LineChart, Line, ResponsiveContainer, Tooltip, ReferenceLine } from 'recharts';
import type { SensorReading } from '../../types';

interface SensorSparklineProps {
  data: SensorReading[];
  field: 'temperature' | 'pressure' | 'current';
  color: string;
  height?: number;
  normalMin?: number;
  normalMax?: number;
}

interface TooltipProps {
  active?: boolean;
  payload?: Array<{ value: number; name: string }>;
  label?: string;
}

function CustomTooltip({ active, payload }: TooltipProps) {
  if (!active || !payload || payload.length === 0) return null;
  return (
    <div className="bg-bg-card border border-border rounded-lg px-2 py-1.5">
      <span className="font-mono text-xs text-text-primary">
        {payload[0].value.toFixed(2)}
      </span>
    </div>
  );
}

export function SensorSparkline({
  data,
  field,
  color,
  height = 80,
  normalMin,
  normalMax,
}: SensorSparklineProps) {
  const chartData = data.slice(-60).map((r, i) => ({ i, value: r[field] }));

  return (
    <ResponsiveContainer width="100%" height={height}>
      <LineChart data={chartData} margin={{ top: 4, right: 4, bottom: 4, left: 4 }}>
        {normalMin !== undefined && (
          <ReferenceLine y={normalMin} stroke="rgba(0,212,255,0.2)" strokeDasharray="3 3" />
        )}
        {normalMax !== undefined && (
          <ReferenceLine y={normalMax} stroke="rgba(0,212,255,0.2)" strokeDasharray="3 3" />
        )}
        <Line
          type="monotone"
          dataKey="value"
          stroke={color}
          strokeWidth={1.5}
          dot={false}
          activeDot={{ r: 3, fill: color }}
          isAnimationActive={false}
        />
        <Tooltip content={<CustomTooltip />} />
      </LineChart>
    </ResponsiveContainer>
  );
}
