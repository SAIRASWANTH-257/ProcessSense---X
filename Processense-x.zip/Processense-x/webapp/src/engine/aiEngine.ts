// ╔══════════════════════════════════════════════════════════════════╗
// ║   ProcessSense-X — AI Engine                                    ║
// ║   Pipeline: Calibration → Filtering → Feature Extraction →      ║
// ║             Anomaly Detection → Drift Detection →               ║
// ║             Severity Score → Yield-Risk Estimate                ║
// ╚══════════════════════════════════════════════════════════════════╝

import type {
  ProcessFingerprint,
  ProcessFeatures,
  SensorStats,
  AIAnalysisResult,
  ProcessStatus,
} from '../types';

// ── Calibration Offsets ──────────────────────────────────────────────
// These correct for known sensor biases. Adjust to match real hardware.
const CALIBRATION = {
  temperature: 0.0,   // DS18B20 offset  (°C)
  pressure:    0.0,   // BMP280 offset   (kPa)
  current:     0.0,   // ACS712 offset   (A)
};

const MA_WINDOW    = 8;   // Moving-average window (samples)
const NOISE_SIGMA  = 3.5; // Reject values beyond N·σ from moving average
const DRIFT_WINDOW = 30;  // Samples used for drift slope calculation

// ── Helper maths ─────────────────────────────────────────────────────
function mean(arr: number[]): number {
  if (arr.length === 0) return 0;
  return arr.reduce((s, v) => s + v, 0) / arr.length;
}

function stdDev(arr: number[]): number {
  if (arr.length < 2) return 0;
  const m = mean(arr);
  return Math.sqrt(arr.reduce((s, v) => s + (v - m) ** 2, 0) / (arr.length - 1));
}

function clamp(v: number, lo: number, hi: number): number {
  return Math.max(lo, Math.min(hi, v));
}

// ── Processing Pipeline Steps ─────────────────────────────────────────

/** Step 1 — Calibration: apply fixed offset corrections */
export function calibrate(value: number, sensor: 'temperature' | 'pressure' | 'current'): number {
  return value + CALIBRATION[sensor];
}

/** Step 2 — Moving Average */
export function movingAverage(values: number[], window = MA_WINDOW): number {
  const slice = values.slice(-window);
  return mean(slice);
}

/** Step 3 — Noise Filter: reject outliers > NOISE_SIGMA from MA */
export function filterNoise(values: number[]): number[] {
  if (values.length < 4) return values;
  const ma = movingAverage(values);
  const sd = stdDev(values.slice(-20));
  const threshold = NOISE_SIGMA * (sd || 0.1);
  return values.filter(v => Math.abs(v - ma) <= threshold);
}

/** Step 4 — Normalization: 0–1 relative to fingerprint range */
export function normalize(value: number, fp: { min: number; max: number }): number {
  const range = fp.max - fp.min;
  if (range === 0) return 0.5;
  return clamp((value - fp.min) / range, 0, 1);
}

/** Step 5 — Feature Extraction */
function extractSensorStats(
  history: number[],
  fp: { mean: number; std: number; min: number; max: number }
): SensorStats {
  const values = history.slice(-30);
  const m = mean(values);
  const s = stdDev(values);
  const ma = movingAverage(history);

  // Rate of change over last 5 samples
  const recent = values.slice(-5);
  const roc = recent.length >= 2
    ? (recent[recent.length - 1] - recent[0]) / (recent.length - 1)
    : 0;

  // Stability: 1 = perfectly stable, 0 = highly variable
  const cv = s / (Math.abs(m) || 1);
  const stability = clamp(1 - cv * 8, 0, 1);

  // Deviation from baseline in sigma units
  const sigma = (m - fp.mean) / (fp.std || 0.01);
  // Deviation in %
  const pct = fp.mean !== 0 ? ((m - fp.mean) / fp.mean) * 100 : 0;

  return {
    mean: m,
    std: s,
    min: Math.min(...values),
    max: Math.max(...values),
    rateOfChange: roc,
    movingAverage: ma,
    deviationFromBaseline: sigma,
    deviationPercent: pct,
    stability,
  };
}

function pearsonCorrelation(a: number[], b: number[]): number {
  const n = Math.min(a.length, b.length, 20);
  if (n < 3) return 0;
  const as = a.slice(-n), bs = b.slice(-n);
  const ma = mean(as), mb = mean(bs);
  const num = as.reduce((s, v, i) => s + (v - ma) * (bs[i] - mb), 0);
  const da = Math.sqrt(as.reduce((s, v) => s + (v - ma) ** 2, 0));
  const db = Math.sqrt(bs.reduce((s, v) => s + (v - mb) ** 2, 0));
  if (da === 0 || db === 0) return 0;
  return clamp(num / (da * db), -1, 1);
}

function extractFeatures(
  tempH: number[],
  pressH: number[],
  currH: number[],
  fp: ProcessFingerprint
): ProcessFeatures {
  return {
    temperature: extractSensorStats(tempH, fp.temperature),
    pressure:    extractSensorStats(pressH, fp.pressure),
    current:     extractSensorStats(currH, fp.current),
    crossCorrelation: {
      tempPressure:   pearsonCorrelation(tempH, pressH),
      tempCurrent:    pearsonCorrelation(tempH, currH),
      pressureCurrent: pearsonCorrelation(pressH, currH),
    },
  };
}

// ── AI Engine Analysis ─────────────────────────────────────────────────────
// Sensor importance weights for semiconductor fab processes
const WEIGHTS = { temperature: 0.45, pressure: 0.30, current: 0.25 };

export function analyze(
  tempHistory: number[],
  pressHistory: number[],
  currHistory: number[],
  fp: ProcessFingerprint
): AIAnalysisResult {
  // Extract features
  const features = extractFeatures(tempHistory, pressHistory, currHistory, fp);

  // ── Anomaly Score (sigma deviation) ───────────────────────────────────────
  const tempAnomaly  = Math.abs(features.temperature.deviationFromBaseline);
  const pressAnomaly = Math.abs(features.pressure.deviationFromBaseline);
  const currAnomaly  = Math.abs(features.current.deviationFromBaseline);

  const rawAnomaly =
    WEIGHTS.temperature * tempAnomaly +
    WEIGHTS.pressure    * pressAnomaly +
    WEIGHTS.current     * currAnomaly;

  const anomalyScore = clamp(rawAnomaly / 4, 0, 1);

  // ── Drift Score (rate of change relative to baseline σ) ──────────────────
  const tempDrift  = Math.abs(features.temperature.rateOfChange) / (fp.temperature.std || 0.01);
  const pressDrift = Math.abs(features.pressure.rateOfChange)    / (fp.pressure.std    || 0.01);
  const currDrift  = Math.abs(features.current.rateOfChange)     / (fp.current.std     || 0.01);

  const driftScore = clamp(
    (WEIGHTS.temperature * tempDrift + WEIGHTS.pressure * pressDrift + WEIGHTS.current * currDrift) / 3,
    0, 1
  );

  // ── Severity Score 0–100 ──────────────────────────────────────────────────
  const severityScore = Math.round(
    clamp(anomalyScore * 65 + driftScore * 35, 0, 1) * 100
  );

  // ── Yield-Risk Estimate ───────────────────────────────────────────────────
  // Non-linear heuristic: low severity → small risk, high severity → large risk
  let yieldRisk: number;
  if (severityScore < 30) {
    yieldRisk = severityScore * 0.15;
  } else if (severityScore < 70) {
    yieldRisk = 4.5 + (severityScore - 30) * 0.45;
  } else {
    yieldRisk = 22.5 + (severityScore - 70) * 0.85;
  }
  yieldRisk = Math.round(yieldRisk * 10) / 10;

  // ── Confidence ────────────────────────────────────────────────────────────
  const histLen = Math.min(tempHistory.length, pressHistory.length, currHistory.length);
  const confidence = Math.round(clamp(60 + histLen * 0.4, 60, 98));

  // ── Status ────────────────────────────────────────────────────────────────
  let status: ProcessStatus = 'NORMAL';
  if (severityScore >= 71) status = 'CRITICAL';
  else if (severityScore >= 31) status = 'WARNING';

  // ── Contributors (% of total anomaly) ─────────────────────────────────────
  const total = tempAnomaly + pressAnomaly + currAnomaly || 1;
  const tPct  = Math.round((tempAnomaly  / total) * 100);
  const pPct  = Math.round((pressAnomaly / total) * 100);
  const cPct  = 100 - tPct - pPct;

  // ── Feature deviations (%) ────────────────────────────────────────────────
  const featureDeviations = {
    temperature: Math.round(Math.abs(features.temperature.deviationPercent) * 10) / 10,
    pressure:    Math.round(Math.abs(features.pressure.deviationPercent) * 10) / 10,
    current:     Math.round(Math.abs(features.current.deviationPercent) * 10) / 10,
  };

  // ── Natural-language interpretation ──────────────────────────────────────
  let interpretation = 'Process fingerprint nominal. All parameters within the established normal operating envelope. No corrective action required.';

  if (status === 'WARNING') {
    const leading: string[] = [];
    if (tempAnomaly  >= pressAnomaly && tempAnomaly  >= currAnomaly)  leading.push('thermal');
    if (pressAnomaly >= tempAnomaly  && pressAnomaly >= currAnomaly)  leading.push('pressure');
    if (currAnomaly  >= tempAnomaly  && currAnomaly  >= pressAnomaly) leading.push('electrical');
    interpretation = `Process drift detected — primary deviation in ${leading.join(' and ')} parameters. Multi-sigma excursion from normal fingerprint. Monitor closely for further escalation.`;
  } else if (status === 'CRITICAL') {
    interpretation = 'Multi-parameter deviation significantly exceeds the normal operating envelope. Potential process yield impact detected. Immediate inspection of thermal, pressure-control, and electrical systems is recommended.';
  }

  return {
    anomalyScore:    Math.round(anomalyScore  * 1000) / 1000,
    driftScore:      Math.round(driftScore    * 1000) / 1000,
    severityScore,
    yieldRisk,
    confidence,
    status,
    contributors:    { temperature: tPct, pressure: pPct, current: cPct },
    featureDeviations,
    interpretation,
    features,
    timestamp: Date.now(),
  };
}

/** Learn fingerprint from a window of normal readings */
export function learnFingerprint(
  tempH: number[],
  pressH: number[],
  currH: number[]
): ProcessFingerprint {
  const stats = (arr: number[]) => ({
    mean: mean(arr),
    std:  stdDev(arr),
    min:  Math.min(...arr),
    max:  Math.max(...arr),
  });
  return {
    temperature: stats(tempH),
    pressure:    stats(pressH),
    current:     stats(currH),
    sampleCount: tempH.length,
    learnedAt:   Date.now(),
  };
}
