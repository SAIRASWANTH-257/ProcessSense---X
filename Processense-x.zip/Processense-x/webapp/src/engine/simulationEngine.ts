// ╔══════════════════════════════════════════════════════════════════╗
// ║   ProcessSense-X — Simulation Engine                            ║
// ║   Generates realistic sensor data for 4 fault scenarios +       ║
// ║   the 5-phase hackathon demo story                              ║
// ╚══════════════════════════════════════════════════════════════════╝

import type { SensorReading, SimScenario, DemoPhase } from '../types';

// ── Normal operating ranges ────────────────────────────────────────
const NORMAL = {
  temp:    { base: 72.5, noise: 0.25 },
  press:   { base: 101.5, noise: 0.15 },
  current: { base: 1.75,  noise: 0.04 },
};

function noise(amplitude: number): number {
  return (Math.random() - 0.5) * 2 * amplitude;
}

function sinWave(step: number, period: number, amplitude: number): number {
  return Math.sin((step * 2 * Math.PI) / period) * amplitude;
}

function round2(n: number): number { return Math.round(n * 100) / 100; }
function round1(n: number): number { return Math.round(n * 10)  / 10;  }

// ─────────────────────────────────────────────────────────────────────
interface SimState {
  scenario: SimScenario;
  step: number;
  demoPhase: DemoPhase;
  baseTemp:    number;
  basePress:   number;
  baseCurrent: number;
}

const initialState = (): SimState => ({
  scenario:   'normal',
  step:       0,
  demoPhase:  1,
  baseTemp:    NORMAL.temp.base,
  basePress:   NORMAL.press.base,
  baseCurrent: NORMAL.current.base,
});

let state: SimState = initialState();

export function resetSimulation(): void {
  state = initialState();
}

export function setScenario(scenario: SimScenario): void {
  state = initialState();
  state.scenario = scenario;
}

export function setDemoPhase(phase: DemoPhase): void {
  state.demoPhase = phase;
}

export function getDemoPhase(): DemoPhase { return state.demoPhase; }
export function getStep(): number         { return state.step; }

// ── Auto-advance demo phase based on step count ────────────────────
function updateDemoPhase(): void {
  if (state.scenario !== 'combined-drift') return;
  const s = state.step;
  if      (s < 15)  state.demoPhase = 1;
  else if (s < 30)  state.demoPhase = 2;
  else if (s < 50)  state.demoPhase = 3;
  else if (s < 70)  state.demoPhase = 4;
  else              state.demoPhase = 5;
}

// ── Core reading generator ─────────────────────────────────────────
export function nextReading(): SensorReading {
  const { step } = state;
  state.step++;

  let temp    = state.baseTemp;
  let press   = state.basePress;
  let current = state.baseCurrent;

  switch (state.scenario) {

    // ── 1. NORMAL: gentle random fluctuations ───────────────────────
    case 'normal':
      temp    += noise(NORMAL.temp.noise);
      press   += noise(NORMAL.press.noise);
      current += noise(NORMAL.current.noise);
      break;

    // ── 2. THERMAL DRIFT: temperature climbs steadily ───────────────
    case 'thermal-drift': {
      state.baseTemp = Math.min(88, state.baseTemp + 0.12);
      temp    = state.baseTemp + noise(0.3);
      press   += noise(NORMAL.press.noise);
      // Slight current increase as device runs hotter
      state.baseCurrent = Math.min(2.2, state.baseCurrent + 0.005);
      current = state.baseCurrent + noise(0.05);
      break;
    }

    // ── 3. PRESSURE INSTABILITY: oscillating pressure ───────────────
    case 'pressure-instability': {
      temp += noise(NORMAL.temp.noise);
      // Amplitude grows with step count — slow onset of instability
      const amplitude = Math.min(2.5, 0.5 + step * 0.04);
      press = state.basePress + sinWave(step, 12, amplitude) + noise(0.2);
      current += noise(NORMAL.current.noise);
      break;
    }

    // ── 4. ELECTRICAL LOAD INCREASE: current ramps up ───────────────
    case 'electrical-load': {
      state.baseCurrent = Math.min(3.8, state.baseCurrent + 0.06);
      // Extra current → slight Joule heating
      state.baseTemp = Math.min(80, state.baseTemp + 0.02);
      temp    = state.baseTemp + noise(0.3);
      press   += noise(NORMAL.press.noise);
      current = state.baseCurrent + noise(0.08);
      break;
    }

    // ── 5. COMBINED DRIFT: all three degrading simultaneously ────────
    case 'combined-drift': {
      updateDemoPhase();
      // Temperature climbs
      state.baseTemp    = Math.min(90, state.baseTemp    + 0.14);
      // Current ramps
      state.baseCurrent = Math.min(4.0, state.baseCurrent + 0.065);
      // Pressure oscillates with growing amplitude
      const amp = Math.min(3.0, 0.3 + step * 0.05);
      temp    = state.baseTemp    + noise(0.4);
      press   = state.basePress   + sinWave(step, 10, amp) + noise(0.3);
      current = state.baseCurrent + noise(0.10);
      break;
    }
  }

  return {
    timestamp:   Date.now(),
    temperature: round1(Math.max(20, temp)),
    pressure:    round2(Math.max(90, press)),
    current:     round2(Math.max(0,  current)),
  };
}

// ── Demo story script (for the presentation narrative) ─────────────
export const DEMO_PHASES = [
  {
    phase: 1 as DemoPhase,
    title: 'Phase 1 — Normal Process',
    description: 'Stable temperature, pressure, and current. AI fingerprint matched.',
    status: 'NORMAL',
    expectedScore: '8–15',
  },
  {
    phase: 2 as DemoPhase,
    title: 'Phase 2 — Thermal Onset',
    description: 'Temperature begins drifting above the normal envelope. Drift score rising.',
    status: 'WARNING',
    expectedScore: '30–45',
  },
  {
    phase: 3 as DemoPhase,
    title: 'Phase 3 — Multi-Sensor Drift',
    description: 'Current instability added. Pressure fluctuations detected. Multi-parameter deviation.',
    status: 'WARNING',
    expectedScore: '45–65',
  },
  {
    phase: 4 as DemoPhase,
    title: 'Phase 4 — Critical Drift',
    description: 'All three parameters outside normal operating envelope. Yield-risk estimate rising rapidly.',
    status: 'CRITICAL',
    expectedScore: '71–85',
  },
  {
    phase: 5 as DemoPhase,
    title: 'Phase 5 — Early Warning Generated',
    description: 'ProcessSense-X has generated an early process warning before conventional inspection would detect the issue.',
    status: 'CRITICAL',
    expectedScore: '85–95',
  },
];
