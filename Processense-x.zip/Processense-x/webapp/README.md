# ProcessSense-X
### Predictive Edge-AI for Semiconductor Process Intelligence

> *"Sense the process. Learn its normal fingerprint. Detect the drift. Predict the risk."*

---

## Quick Start (After installing Node.js)

```bash
cd webapp
npm install
npm run dev
```

Open `http://localhost:3000` — click **OPEN LIVE MONITOR** or **RUN AI SIMULATION**.

---

## Hackathon Demo (2–3 min presentation)

1. Open the app → click **OPEN LIVE MONITOR**
2. Click **Simulation** in the sidebar
3. Press **START DEMO** → watch the 5-phase story:
   - Phase 1: 🟢 NORMAL process
   - Phase 2: 🟡 Thermal drift begins
   - Phase 3: 🟡 Multi-sensor drift
   - Phase 4: 🔴 CRITICAL — yield risk rising
   - Phase 5: 🔴 EARLY WARNING generated
4. Click **Overview** to watch the gauge turn red in real-time
5. Click **AI Analysis** to show the full pipeline and features
6. Click **Yield Risk** to show the predicted risk %

---

## Project Structure

```
Processense-x/
├── webapp/                     ← React + TypeScript + Tailwind frontend
│   ├── src/
│   │   ├── engine/
│   │   │   ├── aiEngine.ts     ← Full AI pipeline (calibration→yield risk)
│   │   │   └── simulationEngine.ts  ← 5 fault scenarios + demo story
│   │   ├── store/
│   │   │   └── processStore.ts ← Zustand global state
│   │   ├── hooks/
│   │   │   └── useSimulation.ts ← Drives simulation timer
│   │   ├── pages/
│   │   │   ├── LandingPage.tsx
│   │   │   ├── Overview.tsx         ← Process Intelligence Center
│   │   │   ├── LiveSensors.tsx      ← DS18B20 · BMP280 · ACS712
│   │   │   ├── AIAnalysis.tsx       ← Full pipeline + features
│   │   │   ├── ProcessFingerprint.tsx ← Radar chart + comparison
│   │   │   ├── DriftMonitor.tsx     ← Timeline + alerts
│   │   │   ├── YieldRisk.tsx        ← Risk prediction
│   │   │   ├── DeviceHealth.tsx     ← ESP32 metrics
│   │   │   ├── DataExplorer.tsx     ← Raw data + export
│   │   │   ├── Simulation.tsx       ← Demo control
│   │   │   └── Settings.tsx
│   │   └── types/index.ts
│   └── package.json
│
├── backend/
│   ├── main.py                 ← FastAPI: /api/sensor-data · /ws
│   └── requirements.txt
│
└── src/                        ← ESP32 firmware (PlatformIO)
    └── main.cpp
```

---

## AI Pipeline

```
Sensor Data
    ↓ Calibration (offset correction)
    ↓ Noise Filtering (3.5σ rejection)
    ↓ Moving Average (8-sample window)
    ↓ Normalization
    ↓ Feature Extraction
       • Mean · Std · Min · Max
       • Rate of Change
       • Stability (0–1)
       • Sigma Deviation from Fingerprint
       • Cross-sensor Pearson Correlation
    ↓ Anomaly Score (weighted sigma deviation)
    ↓ Drift Score (rate-of-change relative to σ)
    ↓ Severity Score (0–100)
    ↓ Yield-Risk Estimate (heuristic %)
```

---

## Sensors

| Sensor | Measurement | Pin (ESP32) |
|--------|-------------|-------------|
| DS18B20 | Temperature (°C) | GPIO 4 |
| BMP280  | Pressure (kPa)   | I2C (21/22) |
| ACS712  | Current (A)      | GPIO 34 |
| MPU6050 | **FUTURE — Vibration** | — |

> **Note:** MPU6050 is marked as FUTURE/OPTIONAL throughout the software. No flow sensor (YF-S201) is included anywhere.

---

## Optional Backend (for real ESP32 data)

```bash
cd backend
pip install -r requirements.txt
uvicorn main:app --host 0.0.0.0 --port 8000
```

ESP32 sends to: `POST http://<your-pc-ip>:8000/api/sensor-data`

```json
{
  "device_id": "ESP32-PSX-001",
  "timestamp": 1727000000,
  "temperature": 72.4,
  "pressure": 101.32,
  "current": 1.84
}
```

---

*AI ESTIMATE · PROTOTYPE — Yield-risk predictions are heuristic models, not production-validated for semiconductor fab use.*
