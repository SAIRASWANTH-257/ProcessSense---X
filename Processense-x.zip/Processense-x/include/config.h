#pragma once
// ╔══════════════════════════════════════════════════════════════════════╗
// ║       ProcessSense-X — Hardware Configuration & Thresholds          ║
// ║       Display: ST7735 1.8" TFT (128×160, SPI)                       ║
// ║       Edit this file to match your setup                            ║
// ╚══════════════════════════════════════════════════════════════════════╝

// ─── WiFi Credentials ────────────────────────────────────────────────────────
#define WIFI_SSID       "RASH"
#define WIFI_PASSWORD   "sai12345"

// ─── I2C Bus (shared by MPU6500 + BMP280) ────────────────────────────────────
// Standard ESP32 I2C pins  — OLED removed, I2C now only for MPU6500 & BMP280
#define PIN_SDA         21
#define PIN_SCL         22

// ─── DS18B20 OneWire Temperature ─────────────────────────────────────────────
// MOVED from GPIO 4 → GPIO 5 (GPIO 4 is now used for TFT_RST)
// Requires a 4.7kΩ pullup resistor between DATA and 3.3V
#define PIN_DS18B20     5

// ─── ACS712 Current Sensor (Analog) ──────────────────────────────────────────
// GPIO 34 = ADC1_CH6, input-only, safe for analog reads
// Using ACS712-5A:  185 mV/A,  zero-current output ≈ 2500 mV (VCC/2)
// Using ACS712-20A: 100 mV/A
// Using ACS712-30A:  66 mV/A
#define PIN_ACS712          34
#define ACS712_SENSITIVITY  0.185f      // V/A  → change to 0.1 for 20A model
#define ACS712_ZERO_MV      2500        // mV at zero current (ideally 2500)
#define ACS712_OVERSAMPLE   64          // ADC oversampling count for noise reduction

// ─── L298N Motor Driver ───────────────────────────────────────────────────────
// ENA  → PWM speed via analogWrite (0‑255)
// IN1/IN2 control direction (HIGH/LOW → Forward, LOW/HIGH → Reverse)
#define PIN_MOTOR_ENA   25
#define PIN_MOTOR_IN1   26
#define PIN_MOTOR_IN2   27

// ─── I2C Device Addresses ─────────────────────────────────────────────────────
#define BMP280_ADDR     0x76    // SDO → GND = 0x76,  SDO → VCC = 0x77
// MPU6500 default I2C address is 0x68 (AD0 pin → GND) — same wiring as MPU6050
// NOTE: MPU6500 WHO_AM_I register returns 0x70 (not 0x68 like MPU6050)
#define MPU6500_ADDR    0x68    // AD0 → GND = 0x68,  AD0 → VCC = 0x69

// ─── ST7735 TFT Display (SPI) ────────────────────────────────────────────────
// 1.8" ST7735 TFT — 128×160 pixels, SPI interface
//
// Wiring:
//   TFT VCC  → 3.3V
//   TFT GND  → GND
//   TFT SCK  → GPIO 18  (Hardware SPI SCLK)
//   TFT SDA  → GPIO 23  (Hardware SPI MOSI)
//   TFT CS   → GPIO 15  (Chip Select)
//   TFT DC   → GPIO  2  (Data/Command)
//   TFT RST  → GPIO  4  (Reset)
//   TFT BL   → 3.3V or GPIO + 33Ω (backlight, leave floating = always on)
//
// NOTE: DS18B20 DATA pin moved from GPIO 4 → GPIO 5 (TFT_RST needs GPIO 4)

#define TFT_CS          15   // SPI Chip Select
#define TFT_DC           2   // Data / Command (register select)
#define TFT_RST          4   // Hardware reset (active LOW)
// Hardware SPI on ESP32: SCLK=18, MOSI=23 — no defines needed, used automatically

// ST7735 initialisation variant — INITR_BLACKTAB for standard 1.8" black-tab modules
// If colours look wrong, try INITR_GREENTAB or INITR_REDTAB
#define TFT_TAB_COLOR   INITR_BLACKTAB

// Display resolution
#define TFT_WIDTH       128
#define TFT_HEIGHT      160

// RGB-565 colour palette
#define TFT_BG          0x0000   // Black background
#define TFT_HEADER      0x07FF   // Cyan  — header / labels
#define TFT_WHITE       0xFFFF   // White — primary values
#define TFT_YELLOW      0xFFE0   // Yellow — warnings
#define TFT_RED         0xF800   // Red   — critical alarms
#define TFT_GREEN       0x07E0   // Green — normal / OK
#define TFT_GRAY        0x4208   // Dark gray — secondary text
#define TFT_ORANGE      0xFBE0   // Orange — motor / power

// ─── Process Alarm Thresholds ─────────────────────────────────────────────────
#define TEMP_WARN_C         85.0f   // °C  — DS18B20 high temperature warning
#define TEMP_CRIT_C         95.0f   // °C  — DS18B20 critical temperature
#define CURRENT_WARN_A       3.0f   // A   — Motor current warning
#define CURRENT_CRIT_A       4.5f   // A   — Motor current critical / overcurrent
#define VIBRATION_WARN_G     1.0f   // g   — RMS vibration magnitude warning
#define VIBRATION_CRIT_G     2.0f   // g   — RMS vibration magnitude critical
#define PRESSURE_LOW_HPA   950.0f   // hPa — Chamber pressure lower bound
#define PRESSURE_HIGH_HPA 1050.0f   // hPa — Chamber pressure upper bound

// ─── Timing Intervals ────────────────────────────────────────────────────────
#define SENSOR_INTERVAL_MS  500     // Sensor read + WebSocket broadcast period
#define TFT_INTERVAL_MS    1000     // TFT display refresh period
