#pragma once
// ╔══════════════════════════════════════════════════════════════════════╗
// ║   ProcessSense-X — AI Dashboard HTML (served from ESP32 flash)      ║
// ║   Stored as a C++ raw string literal, served over HTTP on port 80   ║
// ╚══════════════════════════════════════════════════════════════════════╝

const char DASHBOARD_HTML[] PROGMEM = R"HTML(
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>ProcessSense-X | AI Semiconductor Monitor</title>
<meta name="description" content="AI-powered real-time semiconductor fabrication process monitoring dashboard with predictive analytics.">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&family=JetBrains+Mono:wght@400;500;600&display=swap" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
<style>
:root{
  --bg:#030b18;--card:rgba(10,22,40,0.9);--border:rgba(0,212,255,0.12);
  --cyan:#00d4ff;--cyan10:rgba(0,212,255,0.1);--orange:#ff6b35;
  --green:#00ff88;--red:#ff3860;--yellow:#ffd060;--purple:#bf8fff;
  --text:#ddeeff;--muted:#5a7a99;--mono:'JetBrains Mono',monospace;
}
*{margin:0;padding:0;box-sizing:border-box}
html{scroll-behavior:smooth}
body{font-family:'Inter',sans-serif;background:var(--bg);color:var(--text);min-height:100vh;
  background-image:radial-gradient(ellipse 80% 50% at 10% 0%,rgba(0,212,255,0.05) 0%,transparent 60%),
  radial-gradient(ellipse 60% 40% at 90% 100%,rgba(255,107,53,0.04) 0%,transparent 60%)}

/* ── Scrollbar ─────────────────────────────────────── */
::-webkit-scrollbar{width:5px;height:5px}
::-webkit-scrollbar-track{background:transparent}
::-webkit-scrollbar-thumb{background:var(--border);border-radius:3px}

/* ── Header ────────────────────────────────────────── */
header{display:flex;align-items:center;justify-content:space-between;
  padding:.85rem 2rem;border-bottom:1px solid var(--border);
  background:rgba(3,11,24,.97);backdrop-filter:blur(20px);
  position:sticky;top:0;z-index:100}
.logo{display:flex;align-items:center;gap:.75rem}
.logo-icon{width:38px;height:38px;background:linear-gradient(135deg,#006fff,var(--cyan));
  border-radius:10px;display:flex;align-items:center;justify-content:center;
  font-size:20px;box-shadow:0 0 20px rgba(0,111,255,.35);flex-shrink:0}
.logo-text h1{font-size:1.05rem;font-weight:700;letter-spacing:-.3px}
.logo-text p{font-size:.6rem;color:var(--muted);text-transform:uppercase;letter-spacing:1.2px}
.hdr-right{display:flex;align-items:center;gap:1.2rem}
.uptime-lbl{font-family:var(--mono);font-size:.7rem;color:var(--muted)}
.rssi-lbl{font-family:var(--mono);font-size:.7rem;color:var(--cyan)}
.conn-pill{display:flex;align-items:center;gap:.45rem;background:var(--cyan10);
  border:1px solid var(--border);border-radius:20px;padding:.28rem .75rem;font-size:.72rem}
.dot{width:8px;height:8px;border-radius:50%;background:var(--muted);transition:.3s}
.dot.live{background:var(--green);box-shadow:0 0 8px var(--green);animation:blink 2s infinite}
@keyframes blink{0%,100%{opacity:1}50%{opacity:.45}}

/* ── Layout ────────────────────────────────────────── */
main{padding:1.4rem 2rem;display:flex;flex-direction:column;gap:1.2rem}

/* ── Card ──────────────────────────────────────────── */
.card{background:var(--card);border:1px solid var(--border);border-radius:16px;
  padding:1.2rem;backdrop-filter:blur(20px);position:relative;overflow:hidden;
  transition:border-color .3s,box-shadow .3s}
.card::before{content:'';position:absolute;top:0;left:0;right:0;height:1px;
  background:linear-gradient(90deg,transparent,var(--cyan),transparent);opacity:.25}
.card:hover{border-color:rgba(0,212,255,.28);box-shadow:0 0 30px rgba(0,212,255,.05)}
.card.warn{border-color:rgba(255,208,96,.45)!important;box-shadow:0 0 20px rgba(255,208,96,.08)!important}
.card.crit{border-color:rgba(255,56,96,.5)!important;box-shadow:0 0 20px rgba(255,56,96,.1)!important}
.ctitle{font-size:.65rem;text-transform:uppercase;letter-spacing:1.5px;color:var(--muted);
  margin-bottom:.9rem;font-weight:600}

/* ── Alerts Bar ────────────────────────────────────── */
.alerts-bar{display:flex;flex-wrap:wrap;gap:.45rem;align-items:center;padding:.6rem 1.2rem}
.apill{display:flex;align-items:center;gap:.35rem;padding:.25rem .65rem;
  border-radius:20px;font-size:.68rem;font-weight:600;animation:fadein .3s ease}
@keyframes fadein{from{opacity:0;transform:translateY(-3px)}to{opacity:1;transform:none}}
.apill.ok{background:rgba(0,255,136,.08);border:1px solid rgba(0,255,136,.3);color:var(--green)}
.apill.warn{background:rgba(255,208,96,.08);border:1px solid rgba(255,208,96,.3);color:var(--yellow)}
.apill.crit{background:rgba(255,56,96,.1);border:1px solid rgba(255,56,96,.4);color:var(--red)}

/* ── Gauge Grid ────────────────────────────────────── */
.gauge-grid{display:grid;grid-template-columns:repeat(4,1fr);gap:1rem}
.g-card{display:flex;flex-direction:column;align-items:center}
.gauge-svg{width:130px;height:85px}
.g-name{font-size:.62rem;text-transform:uppercase;letter-spacing:1.2px;color:var(--muted);margin-top:.4rem}
.g-sub{font-family:var(--mono);font-size:.6rem;color:var(--muted);margin-top:.2rem}

/* ── Charts ────────────────────────────────────────── */
.charts-grid{display:grid;grid-template-columns:1fr 1fr;gap:1rem}
.chart-box{height:185px}

/* ── Bottom Row ────────────────────────────────────── */
.bottom-grid{display:grid;grid-template-columns:1fr 1.65fr;gap:1rem}

/* ── Motor Control ─────────────────────────────────── */
.mtr-top{display:flex;align-items:center;justify-content:space-between;margin-bottom:.9rem}
.mtr-ind{display:flex;align-items:center;gap:.45rem}
.mtr-dot{width:10px;height:10px;border-radius:50%;background:var(--muted);transition:.3s}
.mtr-dot.on{background:var(--green);box-shadow:0 0 10px var(--green);animation:blink 1s infinite}
.mtr-pct{font-family:var(--mono);font-size:2rem;font-weight:700;color:var(--cyan);line-height:1}
.mtr-pct span{font-size:.78rem;color:var(--muted)}
.slider{width:100%;-webkit-appearance:none;height:6px;border-radius:3px;outline:none;
  cursor:pointer;margin:.8rem 0;
  background:linear-gradient(to right,var(--cyan) 0%,var(--cyan) var(--pct,0%),#0d2035 var(--pct,0%))}
.slider::-webkit-slider-thumb{-webkit-appearance:none;width:18px;height:18px;border-radius:50%;
  background:var(--cyan);cursor:pointer;box-shadow:0 0 12px var(--cyan)}
.dir-row{display:grid;grid-template-columns:1fr 1fr 1fr;gap:.5rem;margin-top:.2rem}
.btn{background:rgba(0,212,255,.07);border:1px solid var(--border);color:var(--text);
  border-radius:9px;padding:.48rem;cursor:pointer;font-size:.78rem;font-family:'Inter',sans-serif;
  font-weight:500;transition:.2s;letter-spacing:.2px}
.btn:hover{background:rgba(0,212,255,.15);border-color:var(--cyan)}
.btn.active{background:rgba(0,212,255,.18);border-color:var(--cyan);color:var(--cyan)}
.btn.stop{background:rgba(255,56,96,.08);border-color:rgba(255,56,96,.3);color:var(--red)}
.btn.stop:hover{background:rgba(255,56,96,.18)}
.mtr-params{display:grid;grid-template-columns:1fr 1fr;gap:.5rem;margin-top:.75rem}
.pchip{background:rgba(255,255,255,.025);border:1px solid rgba(255,255,255,.055);
  border-radius:9px;padding:.55rem;text-align:center}
.pchip .v{font-family:var(--mono);font-size:.92rem;color:var(--cyan);font-weight:600}
.pchip .l{font-size:.58rem;color:var(--muted);text-transform:uppercase;letter-spacing:1px}

/* ── AI Panel ───────────────────────────────────────── */
.ai-hdr{display:flex;align-items:center;gap:.6rem;margin-bottom:.9rem;flex-wrap:wrap}
.ai-badge{background:linear-gradient(135deg,rgba(0,212,255,.15),rgba(128,0,255,.15));
  border:1px solid rgba(128,0,255,.35);border-radius:20px;padding:.18rem .6rem;
  font-size:.62rem;color:var(--purple);font-weight:700;text-transform:uppercase;letter-spacing:.8px}
.key-row{display:flex;gap:.5rem;margin-bottom:.75rem}
.key-inp{flex:1;background:rgba(0,0,0,.35);border:1px solid var(--border);border-radius:8px;
  padding:.42rem .7rem;color:var(--text);font-family:var(--mono);font-size:.68rem;outline:none}
.key-inp:focus{border-color:var(--cyan)}
.ai-btn{background:linear-gradient(135deg,#006fff,var(--cyan));border:none;border-radius:8px;
  color:#fff;font-weight:700;font-size:.78rem;font-family:'Inter',sans-serif;
  padding:.42rem 1rem;cursor:pointer;white-space:nowrap;transition:.2s;
  box-shadow:0 0 15px rgba(0,111,255,.3)}
.ai-btn:hover{transform:translateY(-1px);box-shadow:0 4px 20px rgba(0,111,255,.4)}
.ai-btn:disabled{opacity:.45;cursor:wait;transform:none}
.health-row{display:flex;gap:1rem;align-items:flex-start;margin-bottom:.7rem}
.hscore{text-align:center;flex:0 0 70px}
.hnum{font-size:2.4rem;font-weight:800;line-height:1;
  background:linear-gradient(135deg,var(--cyan),var(--green));
  -webkit-background-clip:text;-webkit-text-fill-color:transparent;background-clip:text}
.hlbl{font-size:.58rem;color:var(--muted);text-transform:uppercase;letter-spacing:1.2px}
.ai-tags{display:flex;flex-wrap:wrap;gap:.35rem;flex:1}
.atag{padding:.2rem .5rem;border-radius:12px;font-size:.62rem;font-weight:700;
  text-transform:uppercase;letter-spacing:.5px}
.atag.ok{background:rgba(0,255,136,.08);color:var(--green);border:1px solid rgba(0,255,136,.3)}
.atag.warn{background:rgba(255,208,96,.08);color:var(--yellow);border:1px solid rgba(255,208,96,.3)}
.atag.crit{background:rgba(255,56,96,.1);color:var(--red);border:1px solid rgba(255,56,96,.35)}
.ai-out{background:rgba(0,0,0,.3);border:1px solid rgba(255,255,255,.05);border-radius:10px;
  padding:.7rem;min-height:80px;max-height:130px;overflow-y:auto;
  font-size:.72rem;line-height:1.7;color:#90b8cc;white-space:pre-wrap}

/* ── Raw Data ───────────────────────────────────────── */
.raw-grid{display:grid;grid-template-columns:1fr 1fr;gap:1rem}
.dtable{width:100%;border-collapse:collapse;font-size:.73rem}
.dtable td{padding:.3rem .45rem;border-bottom:1px solid rgba(255,255,255,.04)}
.dtable td:first-child{color:var(--muted)}
.dtable td:last-child{font-family:var(--mono);color:var(--cyan);text-align:right}

/* ── Responsive ─────────────────────────────────────── */
@media(max-width:960px){
  .gauge-grid{grid-template-columns:repeat(2,1fr)}
  .charts-grid,.bottom-grid,.raw-grid{grid-template-columns:1fr}
}
@media(max-width:540px){
  main{padding:1rem}
  header{padding:.7rem 1rem}
  .hdr-right .uptime-lbl,.hdr-right .rssi-lbl{display:none}
}
</style>
</head>
<body>

<!-- ═══ HEADER ═══════════════════════════════════════════════════════ -->
<header>
  <div class="logo">
    <div class="logo-icon">⚙</div>
    <div class="logo-text">
      <h1>ProcessSense-X</h1>
      <p>AI Semiconductor Fabrication Monitor</p>
    </div>
  </div>
  <div class="hdr-right">
    <span class="uptime-lbl" id="uptime-lbl">UP: --:--:--</span>
    <span class="rssi-lbl" id="rssi-lbl">WiFi: -- dBm</span>
    <div class="conn-pill">
      <div class="dot" id="conn-dot"></div>
      <span id="conn-txt">Connecting…</span>
    </div>
  </div>
</header>

<main>
  <!-- ── Alerts ──────────────────────────────────────────────── -->
  <div class="card" style="padding:0">
    <div class="alerts-bar" id="alerts-bar">
      <div class="apill ok">⬤ Initializing ProcessSense-X…</div>
    </div>
  </div>

  <!-- ── Gauges ─────────────────────────────────────────────── -->
  <div class="gauge-grid">
    <!-- Temperature -->
    <div class="card g-card" id="crd-temp">
      <div class="ctitle">Process Temperature</div>
      <svg class="gauge-svg" viewBox="0 0 130 85">
        <path d="M15 70 A50 50 0 1 1 115 70" fill="none" stroke="#0a1e38" stroke-width="11" stroke-linecap="round"/>
        <path id="arc-temp" d="M15 70 A50 50 0 1 1 115 70" fill="none" stroke="#00d4ff" stroke-width="11" stroke-linecap="round"
              stroke-dasharray="236" stroke-dashoffset="236" style="transition:stroke-dashoffset .6s ease"/>
        <text x="65" y="62" text-anchor="middle" fill="#ddeeff" font-size="18" font-weight="700" font-family="JetBrains Mono,monospace" id="val-temp">--</text>
        <text x="65" y="74" text-anchor="middle" fill="#5a7a99" font-size="8.5" font-family="Inter,sans-serif">°C  DS18B20</text>
      </svg>
      <div class="g-sub" id="sub-temp">BMP280: -- °C</div>
    </div>
    <!-- Pressure -->
    <div class="card g-card" id="crd-press">
      <div class="ctitle">Chamber Pressure</div>
      <svg class="gauge-svg" viewBox="0 0 130 85">
        <path d="M15 70 A50 50 0 1 1 115 70" fill="none" stroke="#0a1e38" stroke-width="11" stroke-linecap="round"/>
        <path id="arc-press" d="M15 70 A50 50 0 1 1 115 70" fill="none" stroke="#ff6b35" stroke-width="11" stroke-linecap="round"
              stroke-dasharray="236" stroke-dashoffset="236" style="transition:stroke-dashoffset .6s ease"/>
        <text x="65" y="59" text-anchor="middle" fill="#ddeeff" font-size="16" font-weight="700" font-family="JetBrains Mono,monospace" id="val-press">----</text>
        <text x="65" y="74" text-anchor="middle" fill="#5a7a99" font-size="8.5" font-family="Inter,sans-serif">hPa  BMP280</text>
      </svg>
      <div class="g-sub" id="sub-press">Altitude: -- m</div>
    </div>
    <!-- Vibration -->
    <div class="card g-card" id="crd-vib">
      <div class="ctitle">Vibration Level</div>
      <svg class="gauge-svg" viewBox="0 0 130 85">
        <path d="M15 70 A50 50 0 1 1 115 70" fill="none" stroke="#0a1e38" stroke-width="11" stroke-linecap="round"/>
        <path id="arc-vib" d="M15 70 A50 50 0 1 1 115 70" fill="none" stroke="#00ff88" stroke-width="11" stroke-linecap="round"
              stroke-dasharray="236" stroke-dashoffset="236" style="transition:stroke-dashoffset .6s ease"/>
        <text x="65" y="62" text-anchor="middle" fill="#ddeeff" font-size="17" font-weight="700" font-family="JetBrains Mono,monospace" id="val-vib">---</text>
        <text x="65" y="74" text-anchor="middle" fill="#5a7a99" font-size="8.5" font-family="Inter,sans-serif">g RMS  MPU6500</text>
      </svg>
      <div class="g-sub" id="sub-vib">AX:-- AY:-- AZ:--</div>
    </div>
    <!-- Current -->
    <div class="card g-card" id="crd-curr">
      <div class="ctitle">Motor Current</div>
      <svg class="gauge-svg" viewBox="0 0 130 85">
        <path d="M15 70 A50 50 0 1 1 115 70" fill="none" stroke="#0a1e38" stroke-width="11" stroke-linecap="round"/>
        <path id="arc-curr" d="M15 70 A50 50 0 1 1 115 70" fill="none" stroke="#ffd060" stroke-width="11" stroke-linecap="round"
              stroke-dasharray="236" stroke-dashoffset="236" style="transition:stroke-dashoffset .6s ease"/>
        <text x="65" y="62" text-anchor="middle" fill="#ddeeff" font-size="18" font-weight="700" font-family="JetBrains Mono,monospace" id="val-curr">--</text>
        <text x="65" y="74" text-anchor="middle" fill="#5a7a99" font-size="8.5" font-family="Inter,sans-serif">A  ACS712</text>
      </svg>
      <div class="g-sub" id="sub-curr">Power: -- W</div>
    </div>
  </div>

  <!-- ── Charts ─────────────────────────────────────────────── -->
  <div class="charts-grid">
    <div class="card">
      <div class="ctitle">Temperature History (°C — last 60 readings)</div>
      <div class="chart-box"><canvas id="ch-temp"></canvas></div>
    </div>
    <div class="card">
      <div class="ctitle">Current (A) &amp; Vibration (g) History</div>
      <div class="chart-box"><canvas id="ch-cv"></canvas></div>
    </div>
  </div>

  <!-- ── Motor + AI ─────────────────────────────────────────── -->
  <div class="bottom-grid">
    <!-- Motor Control -->
    <div class="card">
      <div class="ctitle">Motor Control — L298N Driver</div>
      <div class="mtr-top">
        <div class="mtr-ind">
          <div class="mtr-dot" id="mtr-dot"></div>
          <span id="mtr-status" style="font-size:.8rem">Stopped</span>
        </div>
        <div class="mtr-pct" id="mtr-pct">0<span>%</span></div>
      </div>
      <input id="spd-slider" type="range" class="slider" min="0" max="100" value="0"
             oninput="onSlider(this.value)">
      <div class="dir-row">
        <button class="btn active" id="btn-fwd" onclick="setDir(true)">▶ Forward</button>
        <button class="btn stop" onclick="eStop()">⛔ E-STOP</button>
        <button class="btn" id="btn-rev" onclick="setDir(false)">◀ Reverse</button>
      </div>
      <div class="mtr-params">
        <div class="pchip"><div class="v" id="m-curr">0.00</div><div class="l">Current A</div></div>
        <div class="pchip"><div class="v" id="m-power">0.0</div><div class="l">Power W</div></div>
      </div>
    </div>

    <!-- AI Analysis -->
    <div class="card">
      <div class="ctitle">
        <div class="ai-hdr">
          <span>AI Process Analysis</span>
          <div class="ai-badge">✦ Gemini 2.0 Flash</div>
        </div>
      </div>
      <div class="key-row">
        <input id="gkey" type="password" class="key-inp" placeholder="Paste Gemini API key (AIza…)">
        <button id="ai-btn" class="ai-btn" onclick="runAI()">⚡ Analyze</button>
      </div>
      <div class="health-row">
        <div class="hscore">
          <div class="hnum" id="h-score">--</div>
          <div class="hlbl">Health</div>
        </div>
        <div class="ai-tags" id="ai-tags">
          <div class="atag ok">Awaiting analysis</div>
        </div>
      </div>
      <div class="ai-out" id="ai-out">Enter your Gemini API key and click Analyze to receive AI-powered process health scoring, anomaly detection, and predictive maintenance recommendations tailored to semiconductor fabrication.</div>
    </div>
  </div>

  <!-- ── Raw Data Tables ────────────────────────────────────── -->
  <div class="raw-grid">
    <div class="card">
      <div class="ctitle">IMU Data — MPU6500</div>
      <table class="dtable">
        <tr><td>Accel X</td><td id="r-ax">-- g</td></tr>
        <tr><td>Accel Y</td><td id="r-ay">-- g</td></tr>
        <tr><td>Accel Z</td><td id="r-az">-- g</td></tr>
        <tr><td>Gyro X</td><td id="r-gx">-- °/s</td></tr>
        <tr><td>Gyro Y</td><td id="r-gy">-- °/s</td></tr>
        <tr><td>Gyro Z</td><td id="r-gz">-- °/s</td></tr>
      </table>
    </div>
    <div class="card">
      <div class="ctitle">System Status</div>
      <table class="dtable">
        <tr><td>WiFi RSSI</td><td id="s-rssi">-- dBm</td></tr>
        <tr><td>Uptime</td><td id="s-uptime">--</td></tr>
        <tr><td>BMP280 Temp</td><td id="s-btemp">-- °C</td></tr>
        <tr><td>Altitude</td><td id="s-alt">-- m</td></tr>
        <tr><td>Motor PWM</td><td id="s-pwm">-- / 255</td></tr>
        <tr><td>Motor Dir</td><td id="s-dir">--</td></tr>
      </table>
    </div>
  </div>
</main>

<script>
// ── Config ───────────────────────────────────────────────────────────────────
const WS_PORT = 81;
let ws, connected = false, isForward = true, spdVal = 0, lastD = {};

// ── Charts ───────────────────────────────────────────────────────────────────
const N = 60, lbl = Array(N).fill('');
const ds18 = Array(N).fill(null), bmpT = Array(N).fill(null);
const curr = Array(N).fill(null), vib = Array(N).fill(null);
const chCfg = {
  responsive:true, maintainAspectRatio:false,
  animation:{duration:200},
  plugins:{legend:{labels:{color:'#5a7a99',font:{size:10},boxWidth:12}}},
  scales:{
    x:{display:false},
    y:{ticks:{color:'#5a7a99',font:{size:10}},grid:{color:'rgba(255,255,255,.04)'}}
  }
};
const ctxT = document.getElementById('ch-temp').getContext('2d');
const chTemp = new Chart(ctxT,{type:'line',data:{labels:lbl,datasets:[
  {label:'DS18B20',data:ds18,borderColor:'#00d4ff',backgroundColor:'rgba(0,212,255,.06)',borderWidth:2,pointRadius:0,fill:true,tension:.4},
  {label:'BMP280', data:bmpT,borderColor:'#ff6b35',backgroundColor:'rgba(255,107,53,.06)',borderWidth:2,pointRadius:0,fill:true,tension:.4}
]},options:{...chCfg}});

const ctxCV = document.getElementById('ch-cv').getContext('2d');
const chCV = new Chart(ctxCV,{type:'line',data:{labels:lbl,datasets:[
  {label:'Current A',data:curr,borderColor:'#ffd060',backgroundColor:'rgba(255,208,96,.05)',borderWidth:2,pointRadius:0,fill:true,tension:.4,yAxisID:'y'},
  {label:'Vibration g',data:vib, borderColor:'#00ff88',backgroundColor:'rgba(0,255,136,.05)',borderWidth:2,pointRadius:0,fill:true,tension:.4,yAxisID:'y1'}
]},options:{...chCfg,scales:{
  x:{display:false},
  y :{position:'left', ticks:{color:'#ffd060',font:{size:10}},grid:{color:'rgba(255,255,255,.04)'}},
  y1:{position:'right',ticks:{color:'#00ff88',font:{size:10}},grid:{display:false}}
}}});

// ── Gauge helper ─────────────────────────────────────────────────────────────
function arc(id,v,mn,mx,dec=1){
  const p=Math.max(0,Math.min(1,(v-mn)/(mx-mn)));
  document.getElementById(id).style.strokeDashoffset=236*(1-p);
  document.getElementById(id.replace('arc','val')).textContent=v.toFixed(dec);
}

// ── Alert system ─────────────────────────────────────────────────────────────
function updateAlerts(d){
  const a=[];
  if(d.temp_ds>95)      a.push({t:'crit',m:'⚠ CRITICAL TEMP '+d.temp_ds.toFixed(1)+'°C'});
  else if(d.temp_ds>85) a.push({t:'warn',m:'⚡ High Temp '+d.temp_ds.toFixed(1)+'°C'});
  else                  a.push({t:'ok',  m:'✓ Temp Normal'});
  if(d.current>4.5)     a.push({t:'crit',m:'⚠ OVERCURRENT '+d.current.toFixed(2)+'A'});
  else if(d.current>3)  a.push({t:'warn',m:'⚡ High Current '+d.current.toFixed(2)+'A'});
  else                  a.push({t:'ok',  m:'✓ Current OK'});
  if(d.vibration>2)     a.push({t:'crit',m:'⚠ CRITICAL VIB '+d.vibration.toFixed(3)+'g'});
  else if(d.vibration>1)a.push({t:'warn',m:'⚡ High Vibration '+d.vibration.toFixed(3)+'g'});
  else                  a.push({t:'ok',  m:'✓ Vibration OK'});
  if(d.pressure<950||d.pressure>1050) a.push({t:'warn',m:'⚡ Press out of range'});
  else                  a.push({t:'ok',  m:'✓ Pressure OK'});
  document.getElementById('alerts-bar').innerHTML=
    a.map(x=>`<div class="apill ${x.t}">${x.m}</div>`).join('');
}

// ── Main data handler ────────────────────────────────────────────────────────
function onData(d){
  lastD=d;
  // Gauges
  arc('arc-temp', d.temp_ds,  0,  120, 1);
  arc('arc-press',d.pressure, 900,1100,0);
  arc('arc-vib',  d.vibration,0,  3,   3);
  arc('arc-curr', Math.abs(d.current),0,5,2);
  // Sub-labels
  document.getElementById('sub-temp').textContent='BMP280: '+d.temp_bmp.toFixed(1)+' °C';
  document.getElementById('sub-press').textContent='Altitude: '+d.altitude.toFixed(1)+' m';
  document.getElementById('sub-vib').textContent='AX:'+d.ax.toFixed(2)+' AY:'+d.ay.toFixed(2)+' AZ:'+d.az.toFixed(2);
  document.getElementById('sub-curr').textContent='Power: '+d.power.toFixed(1)+' W';
  // Charts
  [ds18,bmpT,curr,vib].forEach(a=>a.shift());
  ds18.push(d.temp_ds); bmpT.push(d.temp_bmp);
  curr.push(Math.abs(d.current)); vib.push(d.vibration);
  chTemp.update('none'); chCV.update('none');
  // Motor
  const pct=Math.round(d.motor_spd/2.55);
  document.getElementById('mtr-pct').innerHTML=pct+'<span>%</span>';
  document.getElementById('m-curr').textContent=Math.abs(d.current).toFixed(2);
  document.getElementById('m-power').textContent=d.power.toFixed(1);
  const md=document.getElementById('mtr-dot');
  md.className='mtr-dot'+(d.motor_spd>0?' on':'');
  document.getElementById('mtr-status').textContent=d.motor_spd>0?(d.motor_fwd?'Running Forward':'Running Reverse'):'Stopped';
  // Raw table
  document.getElementById('r-ax').textContent=d.ax.toFixed(3)+' g';
  document.getElementById('r-ay').textContent=d.ay.toFixed(3)+' g';
  document.getElementById('r-az').textContent=d.az.toFixed(3)+' g';
  document.getElementById('r-gx').textContent=d.gx.toFixed(1)+' °/s';
  document.getElementById('r-gy').textContent=d.gy.toFixed(1)+' °/s';
  document.getElementById('r-gz').textContent=d.gz.toFixed(1)+' °/s';
  // System
  document.getElementById('s-rssi').textContent=d.wifi_rssi+' dBm';
  document.getElementById('s-btemp').textContent=d.temp_bmp.toFixed(1)+' °C';
  document.getElementById('s-alt').textContent=d.altitude.toFixed(1)+' m';
  document.getElementById('s-pwm').textContent=d.motor_spd+' / 255';
  document.getElementById('s-dir').textContent=d.motor_fwd?'FORWARD':'REVERSE';
  // Uptime
  const sec=Math.floor(d.ts/1000);
  const h=String(Math.floor(sec/3600)).padStart(2,'0');
  const m=String(Math.floor((sec%3600)/60)).padStart(2,'0');
  const s=String(sec%60).padStart(2,'0');
  const ut=h+':'+m+':'+s;
  document.getElementById('uptime-lbl').textContent='UP: '+ut;
  document.getElementById('s-uptime').textContent=ut;
  document.getElementById('rssi-lbl').textContent='WiFi: '+d.wifi_rssi+' dBm';
  updateAlerts(d);
}

// ── WebSocket ─────────────────────────────────────────────────────────────────
function connect(){
  ws=new WebSocket('ws://'+location.hostname+':'+WS_PORT+'/');
  ws.onopen=()=>{
    connected=true;
    document.getElementById('conn-dot').className='dot live';
    document.getElementById('conn-txt').textContent='Live';
  };
  ws.onclose=()=>{
    connected=false;
    document.getElementById('conn-dot').className='dot';
    document.getElementById('conn-txt').textContent='Reconnecting…';
    setTimeout(connect,2000);
  };
  ws.onerror=()=>ws.close();
  ws.onmessage=e=>{try{onData(JSON.parse(e.data));}catch(_){}};
}
connect();

// ── Motor ─────────────────────────────────────────────────────────────────────
function sendMotor(spd255,fwd){if(connected)ws.send(JSON.stringify({type:'motor',speed:spd255,forward:fwd}));}
function onSlider(v){
  spdVal=+v;
  document.getElementById('mtr-pct').innerHTML=v+'<span>%</span>';
  document.getElementById('spd-slider').style.setProperty('--pct',v+'%');
  sendMotor(Math.round(v*2.55),isForward);
}
function setDir(fwd){
  isForward=fwd;
  document.getElementById('btn-fwd').className='btn'+(fwd?' active':'');
  document.getElementById('btn-rev').className='btn'+(!fwd?' active':'');
  sendMotor(Math.round(spdVal*2.55),fwd);
}
function eStop(){
  spdVal=0;
  document.getElementById('spd-slider').value=0;
  document.getElementById('spd-slider').style.setProperty('--pct','0%');
  sendMotor(0,true);
}

// ── Gemini AI ─────────────────────────────────────────────────────────────────
async function runAI(){
  const key=document.getElementById('gkey').value.trim();
  if(!key){alert('Please enter your Gemini API key.');return;}
  const btn=document.getElementById('ai-btn');
  btn.disabled=true; btn.textContent='⏳ Analyzing…';
  document.getElementById('ai-out').textContent='Sending live sensor data to Gemini AI…';
  const d=lastD;
  const prompt=`You are an expert AI process engineer for semiconductor fabrication. Analyze these real-time sensor readings from the ProcessSense-X monitoring system.

LIVE SENSOR DATA:
• Process Temp (DS18B20): ${(d.temp_ds||0).toFixed(1)}°C
• Ambient Temp (BMP280): ${(d.temp_bmp||0).toFixed(1)}°C
• Chamber Pressure: ${(d.pressure||0).toFixed(1)} hPa
• Altitude: ${(d.altitude||0).toFixed(1)} m
• Motor Current (ACS712): ${Math.abs(d.current||0).toFixed(2)} A
• Power Consumption: ${(d.power||0).toFixed(1)} W
• Vibration RMS: ${(d.vibration||0).toFixed(3)} g
• Accel X/Y/Z: ${(d.ax||0).toFixed(3)}/${(d.ay||0).toFixed(3)}/${(d.az||0).toFixed(3)} g
• Gyro X/Y/Z: ${(d.gx||0).toFixed(1)}/${(d.gy||0).toFixed(1)}/${(d.gz||0).toFixed(1)} °/s
• Motor Speed: ${Math.round((d.motor_spd||0)/2.55)}% ${d.motor_fwd?'(Forward)':'(Reverse)'}

ALARM THRESHOLDS:
• Temp critical >95°C, warning >85°C
• Current critical >4.5A, warning >3.0A
• Vibration critical >2.0g, warning >1.0g
• Pressure normal range: 950-1050 hPa

Respond in EXACTLY this structured format:
HEALTH_SCORE: [0-100]
STATUS: [OPTIMAL/WARNING/CRITICAL]
ANOMALIES: [list anomalies or "None detected"]
MAINTENANCE: [predictive items or "None required"]
RECOMMENDATIONS:
[3 concise actionable optimization recommendations for semiconductor fab process quality]`;

  try{
    const r=await fetch('https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key='+key,
      {method:'POST',headers:{'Content-Type':'application/json'},
       body:JSON.stringify({contents:[{parts:[{text:prompt}]}],
         generationConfig:{temperature:.25,maxOutputTokens:512}})});
    const j=await r.json();
    if(j.error)throw new Error(j.error.message);
    parseAI(j.candidates[0].content.parts[0].text);
  }catch(err){
    document.getElementById('ai-out').textContent='❌ Error: '+err.message;
  }finally{
    btn.disabled=false; btn.textContent='⚡ Analyze';
  }
}

function parseAI(txt){
  document.getElementById('ai-out').textContent=txt;
  const sm=txt.match(/HEALTH_SCORE:\s*(\d+)/);
  if(sm){
    const sc=+sm[1], el=document.getElementById('h-score');
    el.textContent=sc;
    el.style.background=sc>=80?'linear-gradient(135deg,#00ff88,#00d4ff)':
      sc>=60?'linear-gradient(135deg,#ffd060,#ff9030)':'linear-gradient(135deg,#ff3860,#ff9030)';
    el.style.webkitBackgroundClip='text'; el.style.backgroundClip='text';
    el.style.webkitTextFillColor='transparent';
  }
  const tags=[];
  const st=txt.match(/STATUS:\s*(\w+)/);
  if(st){const s=st[1];tags.push(`<div class="atag ${s==='OPTIMAL'?'ok':s==='WARNING'?'warn':'crit'}">${s==='OPTIMAL'?'✓':'⚡'} ${s}</div>`);}
  const an=txt.match(/ANOMALIES:\s*(.+?)(?:\n|$)/);
  tags.push(an&&!/none/i.test(an[1])?'<div class="atag warn">⚡ Anomaly Detected</div>':'<div class="atag ok">✓ No Anomalies</div>');
  const mn=txt.match(/MAINTENANCE:\s*(.+?)(?:\n|$)/);
  tags.push(mn&&!/none/i.test(mn[1])?'<div class="atag warn">🔧 Maintenance Alert</div>':'<div class="atag ok">✓ Maintenance OK</div>');
  document.getElementById('ai-tags').innerHTML=tags.join('');
}
</script>
</body>
</html>
)HTML";
