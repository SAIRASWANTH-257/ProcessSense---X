// ╔══════════════════════════════════════════════════════════════════════════╗
// ║          ProcessSense-X — ESP32 Firmware                               ║
// ║  AI-Powered Real-Time Semiconductor Fabrication Monitor                ║
// ║                                                                        ║
// ║  Sensors  : MPU6500 (IMU), DS18B20 (Temp), BMP280 (Pressure/Temp),    ║
// ║             ACS712 (Current)                                           ║
// ║  Display  : ST7735 1.8" TFT  128×160, SPI — replaces SSD1306 OLED    ║
// ║  Actuators: L298N + DC Motor                                           ║
// ║  Network  : WiFi → HTTP (port 80) dashboard + WebSocket (port 81)     ║
// ╚══════════════════════════════════════════════════════════════════════════╝

#include <Arduino.h>
#include <WiFi.h>
#include <WebServer.h>
#include <WebSocketsServer.h>
#include <Wire.h>
#include <MPU6050.h>               // electroniccats/MPU6050 -- register-compatible with MPU6500
#include <OneWire.h>
#include <DallasTemperature.h>
#include <Adafruit_BMP280.h>
#include <Adafruit_GFX.h>
#include <Adafruit_ST7735.h>          // ← ST7735 TFT (replaces SSD1306)
#include <SPI.h>
#include <ArduinoJson.h>
#include "config.h"
#include "dashboard_html.h"

// ─────────────────────────────────────────────────────────────────────────────
//  Objects
// ─────────────────────────────────────────────────────────────────────────────
WebServer          httpServer(80);
WebSocketsServer   wsServer(81);

MPU6050            mpu;                          // MPU6500 is register-compatible
OneWire            oneWire(PIN_DS18B20);         // DS18B20 on GPIO 5
DallasTemperature  ds18b20(&oneWire);
Adafruit_BMP280    bmp;

// ST7735 on hardware SPI — SCLK=18, MOSI=23 (ESP32 default VSPI)
Adafruit_ST7735    tft(TFT_CS, TFT_DC, TFT_RST);



// ─────────────────────────────────────────────────────────────────────────────
//  Sensor data structure
// ─────────────────────────────────────────────────────────────────────────────
struct SensorFrame {
  float temp_ds   = 0.0f;   // DS18B20 temperature (°C)
  float temp_bmp  = 0.0f;   // BMP280  temperature (°C)
  float pressure  = 0.0f;   // BMP280  pressure    (hPa)
  float altitude  = 0.0f;   // BMP280  altitude    (m)
  float ax        = 0.0f;   // MPU6500 accel X     (g)
  float ay        = 0.0f;   // MPU6500 accel Y     (g)
  float az        = 0.0f;   // MPU6500 accel Z     (g)
  float gx        = 0.0f;   // MPU6500 gyro  X     (°/s)
  float gy        = 0.0f;   // MPU6500 gyro  Y     (°/s)
  float gz        = 0.0f;   // MPU6500 gyro  Z     (°/s)
  float vibration = 0.0f;   // RMS deviation from 1g (g)
  float current   = 0.0f;   // ACS712 current      (A)
  float power     = 0.0f;   // Estimated power     (W)
  int   motorPWM  = 0;      // L298N PWM value     (0-255)
  bool  motorFwd  = true;   // Motor direction
} frame;

// ─────────────────────────────────────────────────────────────────────────────
//  Motor state
// ─────────────────────────────────────────────────────────────────────────────
static int  g_motorPWM = 0;
static bool g_motorFwd = true;

// ─────────────────────────────────────────────────────────────────────────────
//  Timing
// ─────────────────────────────────────────────────────────────────────────────
static unsigned long lastSensor  = 0;
static unsigned long lastTFT     = 0;
static uint8_t       tftPage     = 0;

// ─────────────────────────────────────────────────────────────────────────────
//  Forward declarations
// ─────────────────────────────────────────────────────────────────────────────
void readSensors();
void setMotor(int pwm, bool forward);
void updateTFT();
void broadcastJSON();
String buildJSON();
void wsEventHandler(uint8_t num, WStype_t type, uint8_t *payload, size_t length);
void tftBoot(const char *msg, uint16_t color = TFT_HEADER);
void tftDrawHeader(const char *title);
void tftDrawRow(uint16_t y, const char *label, const char *value,
                uint16_t labelColor, uint16_t valueColor);
uint16_t alarmColor(float value, float warnThresh, float critThresh);

// ─────────────────────────────────────────────────────────────────────────────
//  setup()
// ─────────────────────────────────────────────────────────────────────────────
void setup() {
  Serial.begin(115200);
  delay(100);
  Serial.println("\n\n=== ProcessSense-X Booting ===");

  // ── TFT ST7735 ────────────────────────────────────────────────────────────
  tft.initR(TFT_TAB_COLOR);           // init ST7735 with correct tab variant
  tft.setRotation(0);                 // portrait: 128 wide × 160 tall
  tft.fillScreen(TFT_BG);
  tft.setTextWrap(false);
  Serial.println("[OK] ST7735 TFT initialised (128×160)");
  tftBoot("ProcessSense-X", TFT_HEADER);

  // ── I2C ──────────────────────────────────────────────────────────────────
  Wire.begin(PIN_SDA, PIN_SCL);

  // ── MPU6050 ──────────────────────────────────────────────────────────────
  // MPU6500 uses same registers as MPU6050; Roberto library auto-accepts WHO_AM_I=0x70
  tftBoot("Init MPU6500...");
  mpu.initialize();
  mpu.setFullScaleAccelRange(MPU6050_ACCEL_FS_4);    // +-4g -> 8192 LSB/g
  mpu.setFullScaleGyroRange(MPU6050_GYRO_FS_500);    // +-500 deg/s -> 65.5 LSB/(deg/s)
  mpu.setDLPFMode(MPU6050_DLPF_BW_20);               // 20 Hz low-pass filter
  // MPU6500 WHO_AM_I=0x70 (not 0x68) so testConnection() returns false -- bypass it
  // The register map is identical; getMotion6() works perfectly on MPU6500
  uint8_t whoAmI = mpu.getDeviceID();   // reads register 0x75 bits [6:1]
  if (whoAmI == 0x34 || whoAmI == 0x38) {  // 0x34 = MPU6500, 0x38 = MPU6000/6050
    Serial.printf("[OK] MPU6500 detected  WHO_AM_I=0x%02X\n", whoAmI);
  } else {
    Serial.printf("[WARN] IMU WHO_AM_I=0x%02X -- data reads still attempted\n", whoAmI);
  }

  // ── BMP280 ───────────────────────────────────────────────────────────────
  tftBoot("Init BMP280...");
  if (!bmp.begin(BMP280_ADDR)) {
    Serial.println("[WARN] BMP280 not found — check I2C address/wiring");
  } else {
    Serial.println("[OK] BMP280 connected");
    bmp.setSampling(
      Adafruit_BMP280::MODE_NORMAL,
      Adafruit_BMP280::SAMPLING_X2,
      Adafruit_BMP280::SAMPLING_X16,
      Adafruit_BMP280::FILTER_X16,
      Adafruit_BMP280::STANDBY_MS_500
    );
  }

  // ── DS18B20 ──────────────────────────────────────────────────────────────
  tftBoot("Init DS18B20...");
  ds18b20.begin();
  ds18b20.setResolution(12);
  Serial.printf("[OK] DS18B20: %d device(s) on GPIO %d\n",
                ds18b20.getDeviceCount(), PIN_DS18B20);

  // ── ACS712 ADC ───────────────────────────────────────────────────────────
  analogSetAttenuation(ADC_11db);
  analogSetWidth(12);
  Serial.println("[OK] ACS712 ADC configured on GPIO " + String(PIN_ACS712));

  // ── L298N Motor Driver ────────────────────────────────────────────────────
  pinMode(PIN_MOTOR_IN1, OUTPUT);
  pinMode(PIN_MOTOR_IN2, OUTPUT);
  pinMode(PIN_MOTOR_ENA, OUTPUT);
  setMotor(0, true);
  Serial.println("[OK] L298N motor driver initialised");

  // ── WiFi ─────────────────────────────────────────────────────────────────
  tftBoot("Connecting WiFi...");
  WiFi.mode(WIFI_STA);
  WiFi.begin(WIFI_SSID, WIFI_PASSWORD);
  Serial.printf("[INFO] Connecting to '%s'", WIFI_SSID);

  uint8_t tries = 0;
  while (WiFi.status() != WL_CONNECTED && tries < 40) {
    delay(500);
    Serial.print(".");
    tries++;
  }
  Serial.println();

  if (WiFi.status() == WL_CONNECTED) {
    Serial.printf("[OK] WiFi Connected!  IP: %s  RSSI: %d dBm\n",
                  WiFi.localIP().toString().c_str(), WiFi.RSSI());

    // ── TFT WiFi success screen ───────────────────────────────────────────
    tft.fillScreen(TFT_BG);
    tftDrawHeader("PROCESSSENSE-X");
    tft.setTextColor(TFT_GREEN);
    tft.setTextSize(1);
    tft.setCursor(4, 22);
    tft.println("WiFi Connected!");
    tft.setTextColor(TFT_WHITE);
    tft.setCursor(4, 34);
    tft.println(WiFi.localIP().toString());
    tft.setTextColor(TFT_GRAY);
    tft.setCursor(4, 46);
    tft.println("Open browser at:");
    tft.setTextColor(TFT_HEADER);
    tft.setCursor(4, 58);
    tft.println("http://");
    tft.setCursor(4, 70);
    tft.println(WiFi.localIP().toString());
    delay(3000);
  } else {
    Serial.println("[WARN] WiFi connection failed — running offline");
    tftBoot("WiFi FAILED", TFT_RED);
    delay(1500);
  }

  // ── HTTP Server ───────────────────────────────────────────────────────────
  httpServer.on("/", HTTP_GET, []() {
    httpServer.send_P(200, "text/html", DASHBOARD_HTML);
  });
  httpServer.on("/health", HTTP_GET, []() {
    httpServer.send(200, "application/json", buildJSON());
  });
  httpServer.begin();
  Serial.println("[OK] HTTP server started on port 80");

  // ── WebSocket Server ──────────────────────────────────────────────────────
  wsServer.begin();
  wsServer.onEvent(wsEventHandler);
  Serial.println("[OK] WebSocket server started on port 81");

  Serial.println("[OK] ProcessSense-X ready! Dashboard: http://" + WiFi.localIP().toString());
}

// ─────────────────────────────────────────────────────────────────────────────
//  loop()
// ─────────────────────────────────────────────────────────────────────────────
void loop() {
  httpServer.handleClient();
  wsServer.loop();

  const unsigned long now = millis();

  // ── Sensor read + WebSocket broadcast (every SENSOR_INTERVAL_MS) ─────────
  if (now - lastSensor >= SENSOR_INTERVAL_MS) {
    lastSensor = now;
    readSensors();
    broadcastJSON();
  }

  // ── TFT refresh (every TFT_INTERVAL_MS) ──────────────────────────────────
  if (now - lastTFT >= TFT_INTERVAL_MS) {
    lastTFT = now;
    updateTFT();
  }
}

// ─────────────────────────────────────────────────────────────────────────────
//  Sensor Reading
// ─────────────────────────────────────────────────────────────────────────────
void readSensors() {
  // ── DS18B20 ───────────────────────────────────────────────────────────────
  ds18b20.requestTemperatures();
  float t = ds18b20.getTempCByIndex(0);
  if (t != DEVICE_DISCONNECTED_C && t > -55.0f && t < 125.0f) {
    frame.temp_ds = t;
  }

  // ── BMP280 ────────────────────────────────────────────────────────────────
  frame.temp_bmp = bmp.readTemperature();
  frame.pressure = bmp.readPressure() / 100.0f;   // Pa → hPa
  frame.altitude = bmp.readAltitude(1013.25f);

  // ── MPU6050 ───────────────────────────────────────────────────────────────
  int16_t ax16, ay16, az16, gx16, gy16, gz16;
  mpu.getMotion6(&ax16, &ay16, &az16, &gx16, &gy16, &gz16);
  frame.ax = ax16 / 8192.0f;
  frame.ay = ay16 / 8192.0f;
  frame.az = az16 / 8192.0f;
  frame.gx = gx16 / 65.5f;
  frame.gy = gy16 / 65.5f;
  frame.gz = gz16 / 65.5f;
  float mag = sqrtf(frame.ax*frame.ax + frame.ay*frame.ay + frame.az*frame.az);
  frame.vibration = fabsf(mag - 1.0f);

  // ── ACS712 ────────────────────────────────────────────────────────────────
  long adcSum = 0;
  for (int i = 0; i < ACS712_OVERSAMPLE; i++) adcSum += analogRead(PIN_ACS712);
  float voltMv  = ((float)adcSum / ACS712_OVERSAMPLE / 4095.0f) * 3300.0f;
  float rawCurr = (voltMv - ACS712_ZERO_MV) / (ACS712_SENSITIVITY * 1000.0f);
  frame.current = (fabsf(rawCurr) < 0.05f) ? 0.0f : rawCurr;
  frame.power   = fabsf(frame.current) * 12.0f;

  frame.motorPWM = g_motorPWM;
  frame.motorFwd = g_motorFwd;

  Serial.printf("[DATA] T_DS:%.1f P:%.1f Vib:%.3f I:%.2fA Mtr:%d%%\n",
    frame.temp_ds, frame.pressure, frame.vibration,
    frame.current, (int)(g_motorPWM / 2.55f));
}

// ─────────────────────────────────────────────────────────────────────────────
//  Motor Control
// ─────────────────────────────────────────────────────────────────────────────
void setMotor(int pwm, bool forward) {
  g_motorPWM = constrain(pwm, 0, 255);
  g_motorFwd = forward;
  if (g_motorPWM == 0) {
    digitalWrite(PIN_MOTOR_IN1, LOW);
    digitalWrite(PIN_MOTOR_IN2, LOW);
    analogWrite(PIN_MOTOR_ENA, 0);
  } else {
    digitalWrite(PIN_MOTOR_IN1, forward ? HIGH : LOW);
    digitalWrite(PIN_MOTOR_IN2, forward ? LOW  : HIGH);
    analogWrite(PIN_MOTOR_ENA, g_motorPWM);
  }
}

// ─────────────────────────────────────────────────────────────────────────────
//  Build JSON payload
// ─────────────────────────────────────────────────────────────────────────────
String buildJSON() {
  JsonDocument doc;
  doc["ts"]        = millis();
  doc["temp_ds"]   = roundf(frame.temp_ds   * 10.0f) / 10.0f;
  doc["temp_bmp"]  = roundf(frame.temp_bmp  * 10.0f) / 10.0f;
  doc["pressure"]  = roundf(frame.pressure  * 10.0f) / 10.0f;
  doc["altitude"]  = roundf(frame.altitude  * 10.0f) / 10.0f;
  doc["ax"]        = roundf(frame.ax        * 1000.0f) / 1000.0f;
  doc["ay"]        = roundf(frame.ay        * 1000.0f) / 1000.0f;
  doc["az"]        = roundf(frame.az        * 1000.0f) / 1000.0f;
  doc["gx"]        = roundf(frame.gx        * 100.0f) / 100.0f;
  doc["gy"]        = roundf(frame.gy        * 100.0f) / 100.0f;
  doc["gz"]        = roundf(frame.gz        * 100.0f) / 100.0f;
  doc["vibration"] = roundf(frame.vibration * 1000.0f) / 1000.0f;
  doc["current"]   = roundf(frame.current   * 100.0f) / 100.0f;
  doc["power"]     = roundf(frame.power     * 10.0f) / 10.0f;
  doc["motor_spd"] = g_motorPWM;
  doc["motor_fwd"] = g_motorFwd;
  doc["wifi_rssi"] = WiFi.RSSI();
  String out;
  serializeJson(doc, out);
  return out;
}

// ─────────────────────────────────────────────────────────────────────────────
//  WebSocket broadcast
// ─────────────────────────────────────────────────────────────────────────────
void broadcastJSON() {
  String payload = buildJSON();
  wsServer.broadcastTXT(payload);
}

// ─────────────────────────────────────────────────────────────────────────────
//  WebSocket Event Handler
// ─────────────────────────────────────────────────────────────────────────────
void wsEventHandler(uint8_t num, WStype_t type, uint8_t *payload, size_t length) {
  switch (type) {
    case WStype_CONNECTED: {
      Serial.printf("[WS] Client #%u connected from %s\n", num,
                    wsServer.remoteIP(num).toString().c_str());
      String snap = buildJSON();
      wsServer.sendTXT(num, snap);
      break;
    }
    case WStype_DISCONNECTED:
      Serial.printf("[WS] Client #%u disconnected\n", num);
      break;

    case WStype_TEXT: {
      JsonDocument cmd;
      DeserializationError err = deserializeJson(cmd, payload, length);
      if (err) break;
      if (cmd["type"] == "motor") {
        int  spd = cmd["speed"].as<int>();
        bool fwd = cmd["forward"].as<bool>();
        setMotor(constrain(spd, 0, 255), fwd);
        Serial.printf("[Motor] CMD speed=%d fwd=%d  → PWM=%d\n", spd, fwd, g_motorPWM);
      }
      break;
    }
    default: break;
  }
}

// ─────────────────────────────────────────────────────────────────────────────
//  TFT Helper — Draw header bar
// ─────────────────────────────────────────────────────────────────────────────
void tftDrawHeader(const char *title) {
  tft.fillRect(0, 0, TFT_WIDTH, 16, TFT_HEADER);
  tft.setTextColor(TFT_BG);
  tft.setTextSize(1);
  tft.setCursor(4, 4);
  tft.print(title);
}

// ─────────────────────────────────────────────────────────────────────────────
//  TFT Helper — Draw a key:value row
//  y        = top pixel of the row
//  label    = left-side text (label color)
//  value    = right-side text (value color)
// ─────────────────────────────────────────────────────────────────────────────
void tftDrawRow(uint16_t y, const char *label, const char *value,
                uint16_t labelColor, uint16_t valueColor) {
  // Clear the row
  tft.fillRect(0, y, TFT_WIDTH, 14, TFT_BG);
  // Label (left-aligned)
  tft.setTextColor(labelColor);
  tft.setTextSize(1);
  tft.setCursor(4, y + 3);
  tft.print(label);
  // Value (right-aligned: calculate from right edge)
  int16_t  x1, y1;
  uint16_t w, h;
  tft.getTextBounds(value, 0, y + 3, &x1, &y1, &w, &h);
  tft.setTextColor(valueColor);
  tft.setCursor(TFT_WIDTH - w - 4, y + 3);
  tft.print(value);
  // Thin separator line
  tft.drawFastHLine(0, y + 13, TFT_WIDTH, 0x2104);  // very dark gray
}

// ─────────────────────────────────────────────────────────────────────────────
//  TFT Helper — Pick colour based on alarm thresholds
// ─────────────────────────────────────────────────────────────────────────────
uint16_t alarmColor(float value, float warnThresh, float critThresh) {
  if (fabsf(value) >= critThresh) return TFT_RED;
  if (fabsf(value) >= warnThresh) return TFT_YELLOW;
  return TFT_GREEN;
}

// ─────────────────────────────────────────────────────────────────────────────
//  TFT Update — 4 rotating pages
//
//  Page 0: Temperature & Pressure   (primary process sensors)
//  Page 1: Current & Power          (electrical status)
//  Page 2: Vibration / IMU          (MPU6500)
//  Page 3: Motor & Network          (system status)
// ─────────────────────────────────────────────────────────────────────────────
void updateTFT() {
  char valBuf[24];
  char labelBuf[20];
  const uint8_t page = tftPage % 4;

  tft.fillScreen(TFT_BG);

  switch (page) {

    // ── Page 0: Temperature & Pressure ──────────────────────────────────────
    case 0: {
      tftDrawHeader("  PROCESS SENSORS");
      uint16_t y = 18;

      // DS18B20 temperature
      uint16_t tColor = alarmColor(frame.temp_ds, TEMP_WARN_C, TEMP_CRIT_C);
      snprintf(valBuf, sizeof(valBuf), "%.1f C", frame.temp_ds);
      tftDrawRow(y, "DS18B20 Temp", valBuf, TFT_GRAY, tColor);   y += 14;

      // BMP280 temperature
      snprintf(valBuf, sizeof(valBuf), "%.1f C", frame.temp_bmp);
      tftDrawRow(y, "BMP280 Temp", valBuf, TFT_GRAY, TFT_WHITE); y += 14;

      // Pressure
      snprintf(valBuf, sizeof(valBuf), "%.1f hPa", frame.pressure);
      uint16_t pColor = (frame.pressure < PRESSURE_LOW_HPA || frame.pressure > PRESSURE_HIGH_HPA)
                        ? TFT_RED : TFT_GREEN;
      tftDrawRow(y, "Pressure", valBuf, TFT_GRAY, pColor);        y += 14;

      // Altitude
      snprintf(valBuf, sizeof(valBuf), "%.1f m", frame.altitude);
      tftDrawRow(y, "Altitude", valBuf, TFT_GRAY, TFT_WHITE);     y += 14;

      // Temp alarm bar
      y += 4;
      tft.setTextSize(1);
      if (frame.temp_ds >= TEMP_CRIT_C) {
        tft.fillRect(2, y, TFT_WIDTH - 4, 12, TFT_RED);
        tft.setTextColor(TFT_BG);
        tft.setCursor(14, y + 2); tft.print("!! TEMP CRITICAL !!");
      } else if (frame.temp_ds >= TEMP_WARN_C) {
        tft.fillRect(2, y, TFT_WIDTH - 4, 12, TFT_YELLOW);
        tft.setTextColor(TFT_BG);
        tft.setCursor(18, y + 2); tft.print("! TEMP WARNING !");
      }
      break;
    }

    // ── Page 1: Current & Power ──────────────────────────────────────────────
    case 1: {
      tftDrawHeader("  ELECTRICAL");
      uint16_t y = 18;

      // Current
      uint16_t cColor = alarmColor(frame.current, CURRENT_WARN_A, CURRENT_CRIT_A);
      snprintf(valBuf, sizeof(valBuf), "%.2f A", frame.current);
      tftDrawRow(y, "Current (ACS712)", valBuf, TFT_GRAY, cColor); y += 14;

      // Power
      snprintf(valBuf, sizeof(valBuf), "%.1f W", frame.power);
      tftDrawRow(y, "Power (est.)", valBuf, TFT_GRAY, TFT_ORANGE); y += 14;

      // Motor PWM %
      snprintf(valBuf, sizeof(valBuf), "%d%%  %s",
               (int)(g_motorPWM / 2.55f), g_motorFwd ? "FWD" : "REV");
      tftDrawRow(y, "Motor", valBuf, TFT_GRAY, TFT_HEADER);        y += 14;

      // Motor PWM bar
      y += 6;
      tft.drawRect(4, y, TFT_WIDTH - 8, 10, TFT_GRAY);
      int barW = (int)((TFT_WIDTH - 10) * g_motorPWM / 255.0f);
      if (barW > 0) tft.fillRect(5, y + 1, barW, 8, TFT_ORANGE);
      y += 16;

      // Current alarm bar
      if (frame.current >= CURRENT_CRIT_A) {
        tft.fillRect(2, y, TFT_WIDTH - 4, 12, TFT_RED);
        tft.setTextColor(TFT_BG); tft.setTextSize(1);
        tft.setCursor(10, y + 2); tft.print("!! OVERCURRENT !!");
      } else if (frame.current >= CURRENT_WARN_A) {
        tft.fillRect(2, y, TFT_WIDTH - 4, 12, TFT_YELLOW);
        tft.setTextColor(TFT_BG); tft.setTextSize(1);
        tft.setCursor(12, y + 2); tft.print("! CURRENT HIGH !");
      }
      break;
    }

    // ── Page 2: Vibration / IMU ──────────────────────────────────────────────
    case 2: {
      tftDrawHeader("  VIBRATION / IMU");
      uint16_t y = 18;

      // Vibration RMS
      uint16_t vColor = alarmColor(frame.vibration, VIBRATION_WARN_G, VIBRATION_CRIT_G);
      snprintf(valBuf, sizeof(valBuf), "%.3f g", frame.vibration);
      tftDrawRow(y, "Vibration RMS", valBuf, TFT_GRAY, vColor);    y += 14;

      // Accelerometer axes
      snprintf(valBuf, sizeof(valBuf), "%.3f g", frame.ax);
      tftDrawRow(y, "Accel X", valBuf, TFT_GRAY, TFT_WHITE);       y += 14;
      snprintf(valBuf, sizeof(valBuf), "%.3f g", frame.ay);
      tftDrawRow(y, "Accel Y", valBuf, TFT_GRAY, TFT_WHITE);       y += 14;
      snprintf(valBuf, sizeof(valBuf), "%.3f g", frame.az);
      tftDrawRow(y, "Accel Z", valBuf, TFT_GRAY, TFT_WHITE);       y += 14;

      // Gyroscope axes (compact)
      snprintf(valBuf, sizeof(valBuf), "%.1f/%.1f/%.1f", frame.gx, frame.gy, frame.gz);
      tftDrawRow(y, "Gyro X/Y/Z", valBuf, TFT_GRAY, TFT_HEADER);  y += 14;

      // Vibration alarm
      y += 4;
      if (frame.vibration >= VIBRATION_CRIT_G) {
        tft.fillRect(2, y, TFT_WIDTH - 4, 12, TFT_RED);
        tft.setTextColor(TFT_BG); tft.setTextSize(1);
        tft.setCursor(10, y + 2); tft.print("!! VIB CRITICAL !!");
      } else if (frame.vibration >= VIBRATION_WARN_G) {
        tft.fillRect(2, y, TFT_WIDTH - 4, 12, TFT_YELLOW);
        tft.setTextColor(TFT_BG); tft.setTextSize(1);
        tft.setCursor(14, y + 2); tft.print("! VIB WARNING !");
      }
      break;
    }

    // ── Page 3: Motor & Network ──────────────────────────────────────────────
    case 3: {
      tftDrawHeader("  SYSTEM STATUS");
      uint16_t y = 18;

      // WiFi
      bool wifiOk = (WiFi.status() == WL_CONNECTED);
      tftDrawRow(y, "WiFi", wifiOk ? "OK" : "OFFLINE",
                 TFT_GRAY, wifiOk ? TFT_GREEN : TFT_RED);           y += 14;

      if (wifiOk) {
        // IP address
        tftDrawRow(y, "IP", WiFi.localIP().toString().c_str(),
                   TFT_GRAY, TFT_HEADER);                           y += 14;

        // RSSI
        snprintf(valBuf, sizeof(valBuf), "%d dBm", WiFi.RSSI());
        tftDrawRow(y, "RSSI", valBuf, TFT_GRAY,
                   WiFi.RSSI() > -70 ? TFT_GREEN : TFT_YELLOW);    y += 14;
      } else {
        tftDrawRow(y, "IP", "No connection", TFT_GRAY, TFT_RED);   y += 14;
        y += 14;
      }

      // Uptime
      unsigned long upMs = millis();
      unsigned long upS  = upMs / 1000;
      snprintf(valBuf, sizeof(valBuf), "%02luh%02lum%02lus",
               upS/3600, (upS%3600)/60, upS%60);
      tftDrawRow(y, "Uptime", valBuf, TFT_GRAY, TFT_WHITE);        y += 14;

      // Motor
      snprintf(valBuf, sizeof(valBuf), "%d%%  %s",
               (int)(g_motorPWM / 2.55f), g_motorFwd ? "FWD" : "REV");
      tftDrawRow(y, "Motor", valBuf, TFT_GRAY, TFT_ORANGE);        y += 14;
      break;
    }
  }

  // ── Page indicator dots at bottom ─────────────────────────────────────────
  const uint16_t dotY   = TFT_HEIGHT - 9;
  const uint16_t dotGap = 12;
  const uint16_t dotX0  = (TFT_WIDTH - 4 * dotGap) / 2 + 4;
  for (int i = 0; i < 4; i++) {
    uint16_t cx = dotX0 + i * dotGap;
    if (i == page) tft.fillCircle(cx, dotY, 4, TFT_HEADER);
    else           tft.drawCircle(cx, dotY, 3, TFT_GRAY);
  }

  tftPage++;
}

// ─────────────────────────────────────────────────────────────────────────────
//  TFT Boot message helper (full-screen boot splash)
// ─────────────────────────────────────────────────────────────────────────────
void tftBoot(const char *msg, uint16_t color) {
  tft.fillScreen(TFT_BG);
  tftDrawHeader("  PROCESSENSE-X");

  // Large title in middle
  tft.setTextColor(TFT_HEADER);
  tft.setTextSize(2);
  tft.setCursor(8, 36);
  tft.println("PSX-001");

  // Message
  tft.setTextColor(color);
  tft.setTextSize(1);
  tft.setCursor(4, 74);
  tft.println(msg);

  // Progress bar animation (just a static fill proportional to init stage)
  static uint8_t bootStage = 0;
  bootStage++;
  tft.drawRect(4, 100, TFT_WIDTH - 8, 8, TFT_GRAY);
  int prog = constrain((int)((bootStage * (TFT_WIDTH - 10)) / 6), 0, TFT_WIDTH - 10);
  tft.fillRect(5, 101, prog, 6, TFT_HEADER);

  delay(300);
}